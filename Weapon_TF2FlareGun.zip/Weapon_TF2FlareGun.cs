//TF2FlareGun - extrude

datablock AudioProfile(click)
{
	filename = "./click.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(flarehit)
{
	filename = "./flarehit.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(TF2FlareGunFire)
{
	filename = "./TF2FlareGun.wav";
	description = AudioClose3d;
	preload = true;
};

datablock ParticleData(trail1)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 805;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "0.2 0.2 1 0.4";
	colors[1]     = "0 0 1 0.5";
   colors[2]     = "0.2 0.2 0.2 0.3";
   colors[3]     = "0.0 0.0 0.0 0.0";

	sizes[0]      = 0.25;
	sizes[1]      = 0.85;
   sizes[2]      = 0.35;
 	sizes[3]      = 0.05;

   times[0] = 0.0;
   times[1] = 0.05;
   times[2] = 0.3;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(trailEmitter1)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "trail1";

   uiName = "Flare Trail, Blu";
};

datablock ParticleData(explosionflash)
{
dragCoefficient=0;
gravityCoefficient=5;
inheritedVelFactor=0.2;
constantAcceleration=0;
lifetimeMS=1000;
lifetimeVarianceMS=500;
textureName="base/data/particles/chunk";
spinSpeed=10;
spinRandomMin=-50;
spinRandomMax=50;
colors[0]="0.15 0.15 0.15 1";
colors[1]="0.15 0.15 0.15 0";
sizes[0]=0.2;
sizes[1]=0.2;
useInvAlpha=true;
};

datablock ParticleEmitterData(explosionemitterflash)
{
uiName="";
ejectionPeriodMS=3;
periodVarianceMS=0;
ejectionVelocity=10;
velocityVariance=3;
ejectionOffset=0;
thetaMin=0;
thetaMax=30;
phiReferenceVel=0;
phiVariance=360;
overrideAdvance=false;
particles="explosionflash";
};

datablock ExplosionData(TF2FlareGunExplosion)
{
   //explosionShape = "";
	soundProfile = flarehit;

   lifeTimeMS = 150;

   particleEmitter = gunExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

	emitter[0]	= explosionemitterflash;
   emitter[1] = gunExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0 0 1";
   lightEndColor = "0 0 0";

   playerBurnTime = 3500;
};

AddDamageType("TF2FlareGun",   '<bitmap:add-ons/Weapon_TF2FlareGun/flareKill> %1',    '%2 <bitmap:add-ons/Weapon_TF2FlareGun/flareKill> %1',0.2,1);
datablock ProjectileData(TF2FlareGunProjectile)
{
   projectileShapeName = "./flareblu.dts";
   directDamage        = 60;
   directDamageType    = $DamageType::Gun;
   radiusDamageType    = $DamageType::Gun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 400;
   verticalImpulse	  = 400;
   explosion           = TF2FlareGunExplosion;
   particleEmitter     = trailEmitter1;

   muzzleVelocity      = 90;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;  
   isBallistic         = true;
   gravityMod = 0.4;

   hasLight    = true;
   lightRadius = 5.0;
   lightColor  = "0 0 0.5";

   uiName = "Flare, Blu";
};

//////////
// item //
//////////
datablock ItemData(TF2FlareGunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./TF2FlareGunBlu.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	doColorShift = false;
	colorShiftColor = "0 0 1 0.5";

	//gui stuff
	uiName = "TF2 Flaregun, Blu";
	iconName = "./Icon_TF2FlareGun";
	doColorShift = false;
	colorShiftColor = "0 0 1 0.5";

	 // Dynamic properties defined by the scripts
	image = TF2FlareGunImage;
	canDrop = true;


};


////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(TF2FlareGunImage)
{
   // Basic Item properties
   shapeFile = "./TF2FlareGunBlu.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.0 1.0 -0.85"
   rotation = ""; //eulerToMatrix( "0 0 0" )

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = TF2FlareGunProjectile;
   projectileType = Projectile;

	casing = GunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   LarmReady = true;

   doColorShift = false;
   colorShiftColor = "0 0 1 0.5";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateSequence[0]                 = "Lock";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.14;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateSound[2]					= TF2FlareGunFire;
	stateEjectShell[2]       = false;

	stateName[3] = "Smoke";
	stateEmitter[3]					= GunSmokeEmitter;
	stateEmitterTime[3]				= 0.05;
	stateEmitterNode[3]				= "muzzleNode";
	stateSequence[3]				= "Reload";
	stateSound[3]					= click;
	stateTimeoutValue[3]            = 1.5;
	stateTransitionOnTimeout[3]     = "Reload";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";
	stateSequence[4]	= "Ready";


};


function TF2FlareGunImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, shiftAway);
	Parent::onFire(%this,%obj,%slot);	
}