datablock AudioProfile(tf2SMGShotSound)
{
   filename    = "./smgFire.wav";
   description = AudioClosest3d;
   preload = true;
};

AddDamageType("TF2SMG",   '<bitmap:Add-Ons/Weapon_TF2BasicGuns/CI_TF2SMG> %1',    '%2 <bitmap:Add-Ons/Weapon_TF2BasicGuns/CI_TF2SMG> %1',0.75,1);

datablock ParticleData(tf2smgFlashParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 25;
	lifetimeVarianceMS   = 15;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.9 0.9 0.0 0.9";
	colors[1]     = "0.9 0.5 0.0 0.0";
	sizes[0]      = 0.25;
	sizes[1]      = 0.5;

	useInvAlpha = false;
};
datablock ParticleEmitterData(tf2smgFlashEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "tf2smgFlashParticle";

   uiName = "SMG Flash";
};

//////////
// item //
//////////
datablock ItemData(tf2smgItem)
{
   category = "Weapon";  // Mission editor category
   className = "Weapon"; // For inventory system
   
    // Basic Item Properties
   shapeFile = "./smg.dts";
   rotate = false;
   mass = 1;
   density = 0.2;
   elasticity = 0.2;
   friction = 0.6;
   emap = true;
   
   //gui stuff
   uiName = "TF2 SMG";
   iconName = "./icon_tf2smg";
   doColorShift = true;
   colorShiftColor = "0.5 0.5 0.5 1.000";
   
    // Dynamic properties defined by the scripts
   image = tf2smgImage;
   canDrop = true;
   
   //Ammo Guns Parameters
   maxAmmo = 25;
   canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(tf2smgImage)
{
   // Basic Item properties
   shapeFile = "./smg.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0.05 0.1";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = tf2smgItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;

   casing = gunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = "";

   doColorShift = true;
   colorShiftColor = tf2smgItem.colorShiftColor;
   
   //Raycasting Weapons settings
   raycastWeaponRange = 1000;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastWeaponPierceTargets = "";				//Gun cannot pierce
   raycastExplosionProjectile = gunprojectile;
   raycastExplosionSound = ""; //sound played by exploding gunprojectile
   raycastDirectDamage = 8;
   raycastDirectDamageType = $DamageType::TF2SMG;
   raycastSpreadCount = 1;
   raycastSpreadAmt = 0.003;
   raycastTracerProjectile = TF2BulletTrailProjectile;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]				= "Activate";
	stateTimeoutValue[0]			= 0.3;
	stateWaitForTimeout[0]			= true;
	stateTransitionOnTimeout[0]		= "LoadCheckA";
	stateSound[0]				= weaponSwitchSound;
	
	stateName[1]                    	= "Ready";
	stateTransitionOnTriggerDown[1] 	= "Fire";
	stateAllowImageChange[1]        	= true;
	stateTimeoutValue[1]			= 0.01;
	stateTransitionOnNoAmmo[1]		= "Reload";

	stateName[2]                    	= "Fire";
	stateTransitionOnTimeout[2]     	= "FireLoadCheckA";
	stateTimeoutValue[2]            	= 0.06;
	stateFire[2]                    	= true;
	stateAllowImageChange[2]        	= false;
	stateSequence[2]			= "Fire";
	stateScript[2]				= "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]				= tf2smgFlashEmitter;
	stateEmitterTime[2]			= 0.06;
	stateEmitterNode[2]			= "muzzleNode";
	stateSound[2]				= tf2SMGShotSound;
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0.01;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
	
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "Reload";

	stateName[6]				= "Reload";
	stateTimeoutValue[6]			= 0.6;
	stateScript[6]				= "onReloadStart";
	stateTransitionOnTimeout[6]		= "Wait";
	stateWaitForTimeout[6]			= true;
	stateSound[6]				= Block_MoveBrick_Sound;
	
	stateName[7]				= "Wait";
	stateTimeoutValue[7]			= 0.4;
	stateScript[7]				= "onReloaded";
	stateTransitionOnTimeout[7]		= "Ready";
	stateSound[7]				= Block_PlantBrick_Sound;
	
	stateName[8]				= "FireLoadCheckA";
	stateScript[8]				= "onLoadCheck";
	stateTimeoutValue[8]			= 0.01;
	stateTransitionOnTimeout[8]		= "FireLoadCheckB";
	
	stateName[9]				= "FireLoadCheckB";
	stateTransitionOnAmmo[9]		= "Smoke";
	stateTransitionOnNoAmmo[9]		= "ReloadSmoke";
	
	stateName[10] 				= "Smoke";
	stateEmitter[10]			= gunSmokeEmitter;
	stateEmitterTime[10]			= 0.3;
	stateEmitterNode[10]			= "muzzleNode";
	stateTimeoutValue[10]			= 0.2;
	stateTransitionOnTimeout[10]		= "Ready";
	stateTransitionOnTriggerDown[10]	= "Fire";
	
	stateName[11] 				= "ReloadSmoke";
	stateEmitter[11]			= gunSmokeEmitter;
	stateEmitterTime[11]			= 0.3;
	stateEmitterNode[11]			= "muzzleNode";
	stateTimeoutValue[11]			= 0.2;
	stateTransitionOnTimeout[11]		= "Reload";
};

function tf2smgImage::onFire(%this,%obj,%slot)
{
	Parent::onFire(%this,%obj,%slot);
	%obj.playThread(2, plant);
	%obj.toolAmmo[%obj.currTool]--;
}

function tf2smgImage::onReloadStart(%this,%obj,%slot)
{
	%obj.playThread(2, shiftLeft);
}

function tf2smgImage::onReloaded(%this,%obj,%slot)
{
	%obj.playThread(2, shiftAway);
	
	%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
	%obj.setImageAmmo(%slot,1);
}

function tf2smgImage::onUnMount(%this,%obj,%slot)
{
	%obj.playThread(2, root);
}
