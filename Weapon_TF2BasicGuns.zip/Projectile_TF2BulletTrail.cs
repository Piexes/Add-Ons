//Basic bullet trail projectile that disappears

datablock ParticleData(TF2BulletTrailParticle)
{
   dragCoefficient      = 3;
   gravityCoefficient   = -0.0;
   inheritedVelFactor   = 1.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 100;
   lifetimeVarianceMS   = 0;
   textureName          = "base/data/particles/dot";
   spinSpeed		   = 0.0;
   spinRandomMin		= 0.0;
   spinRandomMax		= 0.0;
   colors[0]     = "1 1 0.2 0.9";
   colors[1]     = "1 1 0.1 0.5";
   colors[2]     = "1 1 0 0";

   sizes[0]      = 0.1;
   sizes[1]      = 0.1;
   sizes[2]      = 0.1;

   times[0] = 0.0;
   times[1] = 0.5;
   times[2] = 1.0;

   useInvAlpha = false;
};
datablock ParticleEmitterData(TF2BulletTrailEmitter)
{
   ejectionPeriodMS = 15;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TF2BulletTrailParticle";

   useEmitterColors = true;

   uiName = "";
};

datablock ProjectileData(TF2BulletTrailProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   explosion           = "";
   particleEmitter     = TF2BulletTrailEmitter;
   explodeOnDeath = false;

   brickExplosionRadius = 0;
   brickExplosionImpact = 0;             //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   collideWithPlayers = true;

   muzzleVelocity      = 200;
   velInheritFactor    = 1.0;

   armingDelay         = 0;
   lifetime            = 800;
   fadeDelay           = 750;
   bounceElasticity    = 0;
   bounceFriction      = 0.00;
   isBallistic         = true;
   gravityMod          = 0.0;

   hasLight    = true;
   lightRadius = 1.0;
   lightColor  = "1 1 0";
   
   uiName = "TF2 Bullet Trail";
};
