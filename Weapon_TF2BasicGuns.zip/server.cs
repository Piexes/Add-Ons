//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Gun");
//%error2 = ForceRequiredAddOn("Weapon_SFRevolver"); //for the Revolver

if(%error == $Error::AddOn_Disabled)
{
   GunItem.uiName = "";
}

//if(%error2 == $Error::AddOn_Disabled)
//{
//   sfRevolverItem.uiName = "";
//}

if(isFile("Add-Ons/Sound_Blockland/server.cs"))
{
   forceRequiredAddOn("Sound_Blockland");
}
else
{
   datablock AudioProfile(Block_MoveBrick_Sound)
   {
      filename = "base/data/sound/clickMove.wav";
      description = AudioClosest3d;
      preload = false;
   };
   datablock AudioProfile(Block_PlantBrick_Sound)
   {
      filename = "base/data/sound/clickPlant.wav";
      description = AudioClosest3d;
      preload = false;
   };
}

if(%error == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_TF2BasicGuns - required add-on Weapon_Gun not found");
}
else
{
   exec("./Support_AmmoGuns.cs");
   exec("./Support_RaycastingWeapons.cs");
   exec("./Projectile_TF2BulletTrail.cs");
   exec("./Weapon_TF2Scattergun.cs");
   exec("./Weapon_TF2Shotgun.cs");
   //exec("./Weapon_TF2Revolver.cs");
   //exec("./Weapon_TF2Pistol.cs");
   exec("./Weapon_TF2SMG.cs");
}

//else if(%error2 == $Error::AddOn_NotFound)
//{
//   error("ERROR: Weapon_TF2BasicGuns - required add-on Weapon_SFRevolver not found");
//}
