datablock AudioProfile(scatterGunShotSound)
{
   filename    = "./scatterFire.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(scatterReloadSound)
{
   filename    = "./scatterReload.wav";
   description = AudioClosest3d;
   preload = true;
};

AddDamageType("TF2Scattergun",   '<bitmap:Add-Ons/Weapon_TF2BasicGuns/CI_TF2Scattergun> %1',    '%2 <bitmap:Add-Ons/Weapon_TF2BasicGuns/CI_TF2Scattergun> %1',0.75,1);

//////////
// item //
//////////
datablock ItemData(scattergunItem)
{
   category = "Weapon";  // Mission editor category
   className = "Weapon"; // For inventory system
   
    // Basic Item Properties
   shapeFile = "./scattergun.dts";
   rotate = false;
   mass = 1;
   density = 0.2;
   elasticity = 0.2;
   friction = 0.6;
   emap = true;
   
   //gui stuff
   uiName = "TF2 Scattergun";
   iconName = "./icon_scattergun";
   doColorShift = true;
   colorShiftColor = "0.1 0.1 0.1 1.000";
   
    // Dynamic properties defined by the scripts
   image = scatterGunImage;
   canDrop = true;
   
   maxAmmo = 6;
   canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(scatterGunImage)
{
   // Basic Item properties
   shapeFile = "./scattergun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0.25 0.05";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = scatterGunItem;
   ammo = " ";
   projectile = gunProjectile;
   projectileType = Projectile;

   casing = gunShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;
   shellVelocity       = 5.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = "";

   doColorShift = true;
   colorShiftColor = scattergunItem.colorShiftColor;
   
   //Raycasting Weapons settings
   raycastWeaponRange = 1000;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastWeaponPierceTargets = "";				//Gun cannot pierce
   raycastExplosionProjectile = gunprojectile;
   raycastExplosionSound = ""; //sound played by exploding gunprojectile
   raycastDirectDamage = 7;
   raycastDirectDamageType = $DamageType::TF2Scattergun;
   raycastSpreadCount = 10;
   raycastSpreadAmt = 0.003;
   raycastTracerProjectile = TF2BulletTrailProjectile;
   raycastImpactImpulse = 30;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]				= "Activate";
	stateTimeoutValue[0]			= 0.3;
	stateWaitForTimeout[0]			= true;
	stateTransitionOnTimeout[0]		= "LoadCheckA";
	stateSound[0]				= weaponSwitchSound;
						
	stateName[1]				= "Ready";
	stateTransitionOnTriggerDown[1]		= "Fire";
	stateTransitionOnTimeout[1]		= "ReloadCheckA";
	stateTransitionOnNoAmmo[1]		= "ReloadCheckA";
	stateWaitForTimeout[1]			= false;
	stateTimeoutValue[1]			= 1;
	stateAllowImageChange[1]		= true;
						
	stateName[2]                    	= "Fire";
	stateTransitionOnTimeout[2]     	= "Smoke";
	stateTimeoutValue[2]            	= 0.14;
	stateFire[2]                    	= true;
	stateAllowImageChange[2]        	= false;
	stateSequence[2]                	= "Ready";
	stateScript[2]                  	= "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]				= gunFlashEmitter;
	stateEmitterTime[2]			= 0.05;
	stateEmitterNode[2]			= "muzzleNode";
	stateSound[2]				= scatterGunShotSound;
						
	stateName[3] 				= "Smoke";
	stateEmitter[3]				= gunSmokeEmitter;
	stateEmitterTime[3]			= 0.1;
	stateEmitterNode[3]			= "muzzleNode";
	stateTimeoutValue[3]			= 0.4;
	stateTransitionOnTimeout[3]		= "LoadCheckA";
						
	stateName[4]				= "LoadCheckA";
	stateScript[4]				= "onLoadCheck";
	stateTimeoutValue[4]			= 0.01;
	stateTransitionOnTimeout[4]		= "LoadCheckB";
						
	stateName[5]				= "LoadCheckB";
	stateTransitionOnAmmo[5]		= "Ready";
	stateTransitionOnNoAmmo[5]		= "ForceReload";
						
	stateName[6]				= "ReloadCheckA";
	stateScript[6]				= "onReloadCheck";
	stateTimeoutValue[6]			= 0.01;
	stateTransitionOnTimeout[6]		= "ReloadCheckB";
						
	stateName[7]				= "ReloadCheckB";
	stateTransitionOnAmmo[7]		= "Ready";
	stateTransitionOnNoAmmo[7]		= "Reload";
						
	stateName[8]				= "ForceReload";
	stateTransitionOnTimeout[8]     	= "ForceReloaded";
	stateTimeoutValue[8]			= 0.2;
	stateSequence[8]			= "Reload";
	stateScript[8]				= "onReloadStart";
	
	stateName[9]				= "ForceReloaded";
	stateTransitionOnTimeout[9]     	= "ReloadCheckA";
	stateTimeoutValue[9]			= 0.2;
	stateEjectShell[9]			= true;
	stateSound[9]				= Block_PlantBrick_Sound;
	stateScript[9]				= "onReloaded";
	
	stateName[10]				= "Reload";
	stateTransitionOnTimeout[10]     	= "Reloaded";
	stateTransitionOnTriggerDown[10]	= "Fire";
	stateWaitForTimeout[10]			= false;
	stateTimeoutValue[10]			= 0.2;
	stateSequence[10]			= "Reload";
	stateScript[10]				= "onReloadStart";
	
	stateName[11]				= "Reloaded";
	stateTransitionOnTimeout[11]     	= "ReloadCheckA";
	stateTransitionOnTriggerDown[11]	= "Fire";
	stateWaitForTimeout[11]			= false;
	stateTimeoutValue[11]			= 0.2;
	stateEjectShell[11]			= true;
	stateSound[11]				= Block_PlantBrick_Sound;
	stateScript[11]				= "onReloaded";
};

function scattergunImage::onFire(%this,%obj,%slot)
{
	Parent::onFire(%this,%obj,%slot);
	%obj.playThread(2, rotCW);
	%obj.toolAmmo[%obj.currTool]--;
}

function scattergunImage::onUnMount(%this,%obj,%slot)
{
	%obj.playThread(2, root);
}

function scattergunImage::onReloadStart(%this,%obj,%slot)
{
	%obj.playThread(2, shiftRight);
}
