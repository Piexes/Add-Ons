function loadDup(%file,%limit,%fo)
{
	cancel($DuplorcatorClientLoadTick);
	if(isFile(%file))
	{
		if(!isObject(%fo))
		{
			//Get the bricks in the save
			%count = 0;
			%fo = new FileObject();
			%fo.openForRead(%file);
			if(!isObject(%fo))
			{
				error("Error uploading client upload. Is the file in use?");
				return;
			}
			while(!%fo.isEOF())
			{
				%line = %fo.readLine();
				if(firstWord(%line) $= "Linecount")
				{
					%max = getWord(%line,1);
					if(%max > %limit)
					{
						clientcmdMessageBoxYesNo("Duplorcator Client Load Limit Reached","The file you are trying to upload to the server exceeds the max bricks you can duplicate. Would you like to load anyways?",'blank');
						MessageBoxYesNoDlg.yesCallBack = "duplorcatorYesLoad(\"" @ %file @ "\");";	
					}
					else
						duplorcatorYesLoad(%file);
				}
				%count++;
			}
			$DuplorcatorClientLoadLineCount = %count;
			%fo.close();
			%fo.delete();
			return;
		}
		if(%fo.isEOF())
		{
			%fo.close();
			%fo.delete();
			commandtoServer('duplorcatorEndUpload');
		}
		else
		{
			commandtoServer('duplorcatorClientLoadLine',%fo.readLine());
			clientcmdCenterPrint("<color:AA9999>Uploading client duplication \c4" @ mCeil(%limit/$DuplorcatorClientLoadLineCount*1000)/10 @ "%",3);
			$DuplorcatorClientLoadTick = schedule(10,0,loadDup,%file,%limit++,%fo);
		}
	}
}
function duplorcatorYesLoad(%file)
{
	$DuplicatorUploadFO = %fo = new FileObject();
	%fo.openForRead(%file);
	loadDup(%file,1,%fo);
	commandtoServer('duplorcatorStartUpload');
}
function clientcmdDuplorcatorClientLoad(%bricklimit)
{
	//Alright we can load,
	loadDup($DuplorcatorPendingSave,%bricklimit);
	$DuplorcatorPendingSave = "";
}
function clientcmdduplorcatorUploadEnded()
{
	cancel($DuplorcatorClientLoadTick);
	if(isObject($DuplicatorUploadFO))
	{
		$DuplicatorUploadFO.close();
		$DuplicatorUploadFO.delete();
	}
}
package duplorcatorClientLoad
{
	function NMH_Type::send(%this)
	{
		%msg = %this.getValue();
		if(firstWord(%msg) $= "/clientload")
		{
			%save = restWords(%msg);
			if(isFile("saves/" @ %save @ ".bls"))
			{
				commandtoserver('DuplorcatorClientLoadCheck');
				$DuplorcatorPendingSave = "saves/" @ %save @ ".bls";
			}
			else
				clientcmdCenterPrint("<color:99AAAA>Duplication file '\c4" @ %save @ "<color:99AAAA>' does not exist",3);
			%this.setValue("");
			parent::send(%this);
			return;
		}
		parent::send(%this);
	}
};
Activatepackage(duplorcatorClientLoad);