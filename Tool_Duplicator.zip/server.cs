//Duplorcator replacement for duplicator
if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$Duplorcator::PrefsLoaded)
	{
		if(!$RTB::RTBR_ServerControl_Hook)
			exec("Add-Ons/System_ReturnToBlockland/hooks/serverControl.cs");
		RTB_registerPref("Admin Only", "Duplorcator", "Pref::Duplorcator::AdminOnly", "bool", "Tool_Duplicator", 0, 0, 0);
		RTB_registerPref("Max Bricks (Admin)", "Duplorcator", "Pref::Duplorcator::MaxBricks", "int 0 50000", "Tool_Duplicator", 5000, 0, 0);
		RTB_registerPref("Max Bricks (Non-Admin)", "Duplorcator", "Pref::Duplorcator::MaxBricksB", "int 0 50000", "Tool_Duplicator", 500, 0, 0);
		RTB_registerPref("Selecting Timeout (Admin)", "Duplorcator", "Pref::Duplorcator::SelectionTimeout", "int 0 60", "Tool_Duplicator", 1, 0, 0);
		RTB_registerPref("Selecting Timeout (Non-Admin)", "Duplorcator", "Pref::Duplorcator::SelectionTimeoutB", "int 0 60", "Tool_Duplicator", 3, 0, 0);
		RTB_registerPref("Planting Timeout (Admin)", "Duplorcator", "Pref::Duplorcator::PlantTimeout", "int 0 60", "Tool_Duplicator", 1, 0, 0);
		RTB_registerPref("Planting Timeout (Non-Admin)", "Duplorcator", "Pref::Duplorcator::PlantTimeoutB", "int 0 60", "Tool_Duplicator", 3, 0, 0);
		RTB_registerPref("Max Flood Bypass", "Duplorcator", "Pref::Duplorcator::FloodIgnore", "int 0 50000", "Tool_Duplicator", 50, 0, 0);
		RTB_registerPref("Rotate Events", "Duplorcator", "Pref::Duplorcator::RotateEvents", "bool", "Tool_Duplicator", 1, 0, 0);
		RTB_registerPref("Trust Required", "Duplorcator", "Pref::Duplorcator::TrustLevel", "list None " @ $TrustLevel::None @ " Build " @ $TrustLevel::Build @ " Full " @ $TrustLevel::Full @ " You " @ $TrustLevel::You, "Tool_Duplicator", 2, 0, 0);
		RTB_registerPref("Max Ghost Bricks", "Duplorcator", "Pref::Duplorcator::MaxGhostBricks", "int 0 2000", "Tool_Duplicator", 500, 0, 0);
		RTB_registerPref("Quick Ghost Bricks", "Duplorcator", "Pref::Duplorcator::GhostBricksNoDelay", "int 0 2000", "Tool_Duplicator", 150, 0, 0);
		RTB_registerPref("Load Admin Only", "Duplorcator", "Pref::Duplorcator::AdminLoad", "bool", "Tool_Duplicator", 0, 0, 0);
		RTB_registerPref("Save Admin Only", "Duplorcator", "Pref::Duplorcator::AdminSave", "bool", "Tool_Duplicator", 0, 0, 0);

		RTB_registerPref("Can Load Saves", "Duplorcator", "Pref::Duplorcator::SaveLoading", "bool", "Tool_Duplicator", 0, 0, 0);
		RTB_registerPref("Client Loading/Saving", "Duplorcator", "Pref::Duplorcator::ClientLoading", "bool", "Tool_Duplicator", 0, 0, 0);
		//RTB_registerPref("Client Load Tick", "Duplorcator", "Pref::Duplorcator::LoadTick", "int 0 100", "Tool_Duplicator", 0, 0, 0);
		$Duplorcator::PrefsLoaded = true;
	}
}
else
{
	$Pref::Duplorcator::AdminOnly = true;
	$Pref::Duplorcator::MaxGhostBricks = 150;
	$Pref::Duplorcator::MaxBricks = 5000;
	$Pref::Duplorcator::MaxBricksB = 500;
	$Pref::Duplorcator::TrustLevel = 2; //Trust needed to plant/duplicate
	$Pref::Duplorcator::SelectionTimeout = 0;
	$Pref::Duplorcator::SelectionTimeoutB = 3;
	$Pref::Duplorcator::PlantTimeout = 0;
	$Pref::Duplorcator::PlantTimeoutB = 3;
	$Pref::Duplorcator::RotateEvents = true;
	$Pref::Duplorcator::GhostBricksNoDelay = 145;
	$Pref::Duplorcator::LoadAdmin = false;
	$Pref::Duplorcator::SaveAdmin = false;
	$Pref::Duplorcator::FloodIgnore = 50;

}
//Credit to Space Guy for this
function getClosestPaintColor(%rgba)
{
	%prevdist = 100000;
	%colorMatch = 0;
	for(%i = 0;%i < 64;%i++)
	{
		%color = getColorIDTable(%i);
		if(vectorDist(%rgba,getWords(%color,0,2)) < %prevdist && getWord(%rgba,3) - getWord(%color,3) < 0.3 && getWord(%rgba,3) - getWord(%color,3) > -0.3)
		{
			%prevdist = vectorDist(%rgba,%color);
			%colormatch = %i;
		}
	}
	return %colormatch;
}
function rotationFromAngleID(%angle)
{
	switch(%angle)
	{
		case 0:
			%rotation = "1 0 0 0";
		case 1:
			%rotation = "0 0 1 90";
		case 2:
			%rotation = "0 0 1 180";
		default:
			%rotation = "0 0 -1 90";
	}
	return %rotation;
}
$Pref::Duplorcator::HighlightColor = getClosestPaintColor("0 1 1 1");
datablock itemData(DuplorcatorItem)
{
	cameraMaxDist   = 0.1;
	canDrop         = 1;
	category        = "Weapon";
	className       = "Tool";
	colorShiftColor = "0 1 1 1";
	density         = 0.2;
	doColorShift    = 1;
	elasticity      = 0.2;
	emap            = 1;
	friction        = 0.6;
	iconName        = "base/client/ui/itemIcons/wand";
	image           = "DuplorcatorImage";
	shapeFile       = "base/data/shapes/wand.dts";
	uiName          = "Duplorcator";
};
datablock particleData(DuplorcatorExplosionParticle)
{
	colors[0]          = "0.3 0.3 1 0.9";
	colors[1]          = "0 0.2 1 0.7";
	colors[2]          = "0.3 0.4 1 0.5";
	gravityCoefficient = 0;
	lifetimeMS         = 400;
	lifetimeVarianceMS = 200;
	sizes[0]           = 0.6;
	sizes[1]           = 0.4;
	sizes[2]           = 0.3;
	spinRandomMax      = 90;
	spinRandomMin      = -90;
	textureName        = "base/data/particles/ring";
	times[1]           = 0.8;
	times[2]           = 1;
};

datablock particleEmitterData(DuplorcatorExplosionEmitter)
{
	ejectionOffset   = 0.5;
	ejectionPeriodMS = 4;
	ejectionVelocity = 3;
	particles        = DuplorcatorExplosionParticle;
	periodVarianceMS = 2;
	thetaMax         = 180;
	velocityVariance = 0;
};
datablock explosionData(DuplorcatorExplosion)
{
	camShakeDuration = 0.5;
	camShakeFreq     = "1 1 1";
	emitter[0]       = DuplorcatorExplosionEmitter;
	faceViewer       = 1;
	lifetimeMS       = 180;
	lightEndRadius   = 0.5;
	lightStartColor  = "0 0.7 1 1";
	lightStartRadius = 1;
	shakeCamera      = 1;
	soundProfile     = "wandHitSound";
};
datablock projectileData(DuplorcatorProjectile)
{
	bounceElasticity = 0;
	bounceFriction   = 0;
	explodeOnDeath   = 1;
	explosion        = DuplorcatorExplosion;
	fadeDelay        = 2;
	gravityMod       = 0;
	lifetime         = 0;
	mask             = $TypeMasks::FxBrickAlwaysObjectType | $TypeMasks::InteriorObjectType | $TypeMasks::TerrainObjectType;
	range            = 10;
};
datablock particleData(DuplorcatorParticleA)
{
	colors[0]          = "0.0 0.6 1 0.9";
	colors[1]          = "0 0.2 1 0.7";
	colors[2]          = "0.3 0.4 1 0.5";
	gravityCoefficient = -0.5;
	lifetimeMS         = 400;
	lifetimeVarianceMS = 200;
	sizes[0]           = 0.1;
	sizes[1]           = 0.4;
	sizes[2]           = 0.6;
	spinRandomMax      = 90;
	spinRandomMin      = -90;
	textureName        = "base/data/particles/ring";
	times[1]           = 0.8;
	times[2]           = 1;
};

datablock particleEmitterData(DuplorcatorEmitterA)
{
	ejectionOffset   = 0.09;
	ejectionPeriodMS = 50;
	ejectionVelocity = 0.2;
	particles        = DuplorcatorParticleA;
	periodVarianceMS = 2;
	thetaMax         = 180;
	velocityVariance = 0;
};
datablock particleData(DuplorcatorParticleB)
{
	colors[0]          = "0.0 0.6 1 0.9";
	colors[1]          = "0 0.2 1 0.7";
	colors[2]          = "0.3 0.4 1 0.5";
	gravityCoefficient = -0.4;
	dragCoefficient    = 2;
	lifetimeMS         = 400;
	lifetimeVarianceMS = 200;
	sizes[0]           = 0.4;
	sizes[1]           = 0.6;
	sizes[2]           = 0.9;
	spinRandomMax      = 0;
	spinRandomMin      = 0;
	textureName        = "base/client/ui/brickIcons/1x1";
	times[1]           = 0.5;
	times[2]           = 1;
};

datablock particleEmitterData(DuplorcatorEmitterB)
{
	ejectionOffset   = -0.0;
	ejectionPeriodMS = 10;
	ejectionVelocity = 0;
	particles        = DuplorcatorParticleB;
	periodVarianceMS = 2;
	thetaMin		 = 0.0;
	thetaMax         = 0.1;
	velocityVariance = 0;
	orientParticles  = true;
	phiVariance		 = 10;
};
datablock shapeBaseImageData(DuplorcatorImage : wandImage)
{
	projectile = DuplorcatorProjectile;
	showBricks = true;
	colorShiftColor = "0.000000 1.000000 1.000000 1.000000";
	item = DuplorcatorItem;
	stateEmitter[1] = DuplorcatorEmitterA;
	stateEmitter[3] = DuplorcatorEmitterB;
};

function servercmdduplorcator(%client)
{
	if(!isObject(%client.player))
		return;
	%client.player.updateArm(DuplorcatorImage);
	%client.player.mountImage(DuplorcatorImage,0);
}
function servercmddup(%client)
{
	servercmdDuplorcator(%client);
}
function vectorRot(%vector,%rotation)
{
	if(!%rotation)
		return %vector;
	if(%rotation == 1)
		return getWord(%vector, 1) SPC -getWord(%vector, 0) SPC getWord(%vector, 2);
	if(%rotation == 2)
		return -getWord(%vector, 0) SPC -getWord(%vector, 1) SPC getWord(%vector, 2);
	else if(%rotation == 3)
		return -getWord(%vector, 1) SPC getWord(%vector, 0) SPC getWord(%vector, 2);
}
function FXDTSBrick::toSaveStr(%this,%initialPos)
{
	%a = %this.getDatablock().uiName @ "\"";
	//Offset from the ground
	%b = vectorSub(%this.getPosition(),%initialPos);
	%c = %this.getAngleID();
	%d = %this.isBaseplate();
	%e = (strLen(%this.originalColor) ? %this.originalColor : %this.getColorID());
	if(%this.getDatablock().hasPrint)
	{
		%texture = getPrintTexture(%this.getPrintId());
		%path = filePath(%texture);
		%underscorePos = strPos(%path, "_");
		%name = getSubStr(%path, %underscorePos + 1, strPos(%path, "_", 14) - 14) @ "/" @ fileBase(%texture);
		if($printNameTable[%name] !$= "")
			%f = %name;
	}
	%g = (strLen(%this.originalColorFX) ? %this.originalColorFX : %this.getColorFXID());
	%h = %this.getShapeFXID();
	%i = %this.isRaycasting();
	%j = %this.isColliding();
	%k = %this.isRendering();
	%data = %a SPC %b SPC %c SPC %d SPC %e SPC %f SPC %g SPC %h SPC %i SPC %j SPC %k;
	if(isObject(%this.vehicleDataBlock))
		%data = %data NL "+-VEHICLE" SPC %this.vehicleDataBlock.uiName @ "\"" SPC %this.recolorVehicle;
	if(isObject(%this.emitter))
		%data = %data NL "+-EMITTER" SPC %this.emitter.emitter.uiName @ "\"" SPC %this.emitterDirection;
	if(isObject(%this.light))
		%data = %data NL "+-LIGHT" SPC %this.light.dataBlock.uiName @ "\" ";
	if(isObject(%this.item))
		%data = %data NL "+-ITEM" SPC %this.item.dataBlock.uiName @ "\"" SPC %this.itemPosition SPC %this.itemDirection SPC %this.itemRespawnTime;
	if(isObject(%this.audioEmitter))
		%data = %data NL "+-AUDIOEMITTER" SPC %this.audioEmitter.profile.uiName @ "\" ";
	if(%this.getName() !$= "")
		%data = %data NL "+-NTOBJECTNAME" SPC %this.getName();
	//Events
	for(%i=0;%i<%this.numEvents;%i++)
	{
		//+-EVENT num enabled input delay target output par1 par2 par3
		%data = %data NL "+-EVENT" TAB %i TAB %this.eventEnabled[%i] TAB %this.eventInput[%i] TAB %this.eventDelay[%i] TAB %this.eventTarget[%i] TAB %this.eventNT[%i] TAB %this.eventOutput[%i];
		//Parameters
		%outputClass = %this.eventTargetIdx[%i] == -1 ? "fxDtsBrick" : inputEvent_GetTargetClass("fxDtsBrick", %this.eventInputIdx[%i], %this.eventTargetIdx[%i]);
		for(%p=1;%p<=4;%p++)
		{
			%param = %this.eventOutputParameter[%i,%p];
			if(getWord(getField($OutputEvent_parameterList[%outputClass, %this.eventOutputIdx[%i]], %p - 1), 0) $= "dataBlock" && isObject(%param))
				%param = %param.getName();
			%data = %data TAB %param;
		}
	}
	return %data;
}
function createFromStr(%str,%client)
{
	if(%str $= "")
		return;
	%brick = %client.player.tempbrick;
	%datablock = getValueFromBrickStr(%str,"datablock");
	%line = strReplace(getLine(%str,0),%datablock @ "\" ","");
	%position = getWords(%line,0,2);
	%angle = getWord(%line,3);
	%baseplate = getWord(%line,4);
	%color = getWord(%line,5);
	%print = getWord(%line,6);
	%colorFX = getWord(%line,7);
	%shapeFX = getWord(%line,8);
	%raycasting = getWord(%line,9);
	%colliding = getWord(%line,10);
	%rendering = getWord(%line,11);

	%angleOffset = %brick.angleOffset;
	if(%angleOffset $= "")
		%angleOffset = %brick.getAngleID() - getValueFromBrickStr(%brick.stack.brick0,"angleID");
	if(%angleOffset < 0)
		%angleOffset += 4;
	%angle = %angle + %angleOffset;
	if(%angle > 3)
		%angle -= 4;
	%position = vectorRot(%position,%angleOffset);
	%position = vectorAdd(%brick.getPosition(),%position);

	%brick = new FXDTSBrick()
	{
		client = %client;
		stackBL_ID = %client.BL_ID;
		datablock = $uiNameTable[%datablock];
		position = %position;
		angleID = %angle;
		isBaseplate = %baseplate;
		colorID = %color;
		colorFXID = %colorFX;
		shapeFXID = %shapeFX;
		isPlanted = true;
		printID = $printNameTable[%print];
		rotation = rotationFromAngleID(%angle);
	};
	%err = %brick.plant();
	if(%err || !isObject(%brick))
	{
		%brick.delete();
		return %err;
	}
	%client.brickGroup.add(%brick);

	//Bot hole fix: little hack around the bot package to correctly spawn bots the first time
	if(%brick.getDatablock().isBotHole)
	{
		%botVal = %brick.getDatablock().holeBot.hManualSpawn;
		%brick.getDatablock().holeBot.hManualSpawn = true;
	}
	%brick.plantedTrustCheck(); //Correctly call onPlant and all those other functions, this is a key feature
	if(%brick.getDatablock().isBotHole)
		%brick.getDatablock().holeBot.hManualSpawn = %botVal;

	%support = %brick.getDownBrick(0);
	if(!isObject(%support))
		%support = %brick.getUpBrick(0);
	if(isObject(%support) && getTrustLevel(%support,%brick) < $Pref::Duplorcator::TrustLevel)
	{
		if(%support.getGroup().bl_id != 888888)
		{
			%brick.delete();
			return "10" SPC %support.getGroup().name;
		}
	}
	%client.brickGroup.add(%brick);
	%brick.setTrusted(true);
	if(!%raycasting)
		%brick.setRaycasting(false);
	if(!%colliding)
		%brick.setColliding(false);
	if(!%rendering)
		%brick.setRendering(false);

	for(%i=1;%i<getLineCount(%str);%i++)
	{
		%line = getLine(%str,%i);
		if(firstWord(%line) $= "+-OWNER")
			continue;
		if(firstWord(%line) !$= "+-NTOBJECTNAME" && getField(%line,0) !$= "+-EVENT")
			%ui = restWords(getSubStr(%line,0,strpos(%line,"\"")));
		else if(firstWord(%line) $= "+-NTOBJECTNAME")
			%brick.setNTObjectName(getWord(%line,1));
		if(firstWord(%line) $= "+-VEHICLE")
		{
			%val = getSubStr($s,strpos($s,"\"")+2,strpos($s," ",strpos($s,"\"")));
			%brick.setRecolorVehicle(%val);
			%brick.setVehicle($uiNameTable_Vehicle[%ui]);
		}
		if(firstWord(%line) $= "+-EMITTER")
		{
			%dir = getSubStr(%line,strpos(%line,"\" ")+2,strLen(%line));
			//Is it NSWE?
			if(%dir-2 >= 0)
				%dir += %angleOffset;
			if(%dir-2 > 3)
					%dir -= 4;
			%brick.emitterDirection = %dir;
			%brick.setEmitter($uinameTable_Emitters[%ui]);
		}
		if(firstWord(%line) $= "+-LIGHT")
			%brick.setLight($uinameTable_Lights[%ui]);
		if(firstWord(%line) $= "+-ITEM")
		{
			%d = getSubStr(%line,strpos(%line,"\" ")+2,strLen(%line));
			%dir = getWord(%d,1);
			%pos = getWord(%d,0);
			%respawnTime = getWord(%d,2);
			if(%dir-2 >= 0)
				%dir += %angleOffset;
			if(%dir-2 > 3)
					%dir -= 4;
			if(%pos-2 >= 0)
				%pos += %angleOffset;
			if(%pos-2 > 3)
					%pos -= 4;
			%brick.itemPosition = %pos;
			%brick.itemDirection = %dir;
			%brick.itemRespawnTime = %respawnTime;
			%brick.setItem($uiNameTable_Items[%ui]);
		}
		if(firstWord(%line) $= "+-AUDIOEMITTER")
			%brick.setMusic($uiNameTable_Music[%data]);
		if(getField(%line,0) $= "+-EVENT")
		{
			%num = getField(%line,1);
			%brick.eventEnabled[%num] = getField(%line, 2);
			%brick.eventInput[%num] = getField(%line, 3);
			%brick.eventInputIdx[%num] = inputEvent_GetInputEventIdx(%brick.eventInput[%num]);
			%brick.eventDelay[%num] = getField(%line, 4);
			%brick.eventTarget[%num] = getField(%line, 5);
			%brick.eventTargetIdx[%num] = inputEvent_GetTargetIndex("fxDtsBrick", %brick.eventInputIdx[%num], %brick.eventTarget[%num]);
			%brick.eventNT[%num] = getField(%line, 6);
			%outputClass = %brick.eventTargetIdx[%num] == -1 ? "fxDtsBrick" : inputEvent_GetTargetClass("fxDtsBrick", %brick.eventInputIdx[%num], %brick.eventTargetIdx[%num]);
			%brick.eventOutput[%num] = getField(%line, 7);
			%brick.eventOutputIdx[%num] = outputEvent_GetOutputEventIdx(%outputClass,%brick.eventOutput[%num]);
			%brick.eventOutputAppendClient[%num] = $OutputEvent_AppendClient[%outputClass,%brick.eventOutputIdx[%num]];

			for(%e = 1; %e <= 4; %e++)
			{
				%eventParamType = getField($OutputEvent_parameterList[%outputClass, %brick.eventOutputIdx[%num]], %e - 1);
				if(getWord(%eventParamType, 0) $= "dataBlock" && isObject(getField(%line, %e + 7)))
					%brick.eventOutputParameter[%num,%e] = getField(%line, %e + 7).getId();
				else
					%brick.eventOutputParameter[%num, %e] = getField(%line, %e + 7);
				if($Pref::Duplorcator::RotateEvents)
				{
					if(getWord(%eventParamType,0) $= "vector")
						%brick.eventOutputParameter[%num, %e] = vectorRot(getField(%line, %e + 7),%angleOffset);
					else if(getWord(%eventParamType,0) $= "list")
					{
						if(stripos(%eventParamType,"North") != -1)
						{
							%off = 0;
							if(stripos(%eventParamType,"Up"))
								%off++;
							if(stripos(%eventParamType,"Down"))
								%off++;
							%value = %brick.eventOutputParameter[%num, %e];
							if(%value-2 >= 0)
								%value+=%angleOffset;
							if(%value-2 > 3)
								%value -= 4;
							%brick.eventOutputParameter[%num, %e] = %value;
						}
					}
				}

			}
			%brick.numEvents++;
			%brick.implicitCancelEvents = 0;
			if(strpos(%brick.eventOutput[%num],"fireRelay") != -1)
			{
				%output = %brick.eventOutput[%num];
				%dir = getSubStr(%output,strLen("fireRelay"),strLen(%output));
				switch$(%dir)
				{
					case "North":
						%dir = 0;
					case "West":
						%dir = 1;
					case "South":
						%dir = 2;
					case "East":
						%dir = 3;
					default:
						continue;
				}
				%dir -= %angleOffset;
				if(%dir < 0)
					%dir += 4;
				switch(%dir)
				{
					case 0:
						%output = "fireRelayNorth";
					case 1:
						%output = "fireRelayWest";
					case 2:
						%output = "fireRelaySouth";
					case 3:
						%output = "fireRelayEast";
				}
				%brick.eventOutput[%num] = %output;
				%brick.eventOutputIDX[%num] = outputEvent_GetOutputEventIdx("fxDTSBrick",%output);
			}
		}
	}
	//Events are applied, spawn the bot
	if(%brick.getDatablock().isBotHole)
		%brick.onHoleSpawnPlanted();
	return %brick;
}
function FxDTSBrick::restoreOrignalColors(%this)
{
	%this.setColor(%this.originalColor);
	%this.setColorFX(%this.originalColorFX);
}
function FxDtsBrick::getStack(%brick,%player)
{
	%initialPos = %brick.getPosition();
	if(getTrustLevel(%brick,%player) < $Pref::Duplorcator::TrustLevel)
		return;
	%stack = new SimSet();
	%stack.add(%brick);
	%stack.brick0 = %brick.toSaveStr(%initialPos);
	if(isEventPending(%brick.highlightColorReset))
		cancel(%brick.highlightColorReset);
	else
	{
		%color = %brick.getColorID();
		%colorFX = %brick.getColorFxID();
		%brick.setColor($Pref::Duplorcator::HighlightColor);
		%brick.setColorFX(3);
		%brick.originalColor = %color;
		%brick.originalColorFX = %colorFX;
	}
	%brick.highlightColorReset = %brick.schedule(3000,restoreOrignalColors);
	%final = 1;
	for(%current = 0; %current != %final; %current++)
	{
		if((%player.client.isAdmin && $Pref::Duplorcator::MaxBricks <= %stack.getCount()) || (!%player.client.isAdmin && $Pref::Duplorcator::MaxBricksB <= %stack.getCount()))
		{
			%stack.err = "Limit";
			return %stack;
		}
		%brick = %stack.getObject(%current);
		if(%current) //Don't select bricks below the first
		{
			for(%i=0;%i<%brick.getNumDownBricks();%i++)
			{
				%appendBrick = %brick.getDownBrick(%i);
				if(%stack.isMember(%appendBrick) || getTrustLevel(%appendBrick,%player) < $Pref::Duplorcator::TrustLevel)
					continue;
				if(isEventPending(%appendBrick.highlightColorReset))
					cancel(%appendBrick.highlightColorReset);
				else
				{
					%color = %appendBrick.getColorID();
					%colorFX = %appendBrick.getColorFxID();
					%appendBrick.setColor($Pref::Duplorcator::HighlightColor);
					%appendBrick.setColorFX(3);
					%appendBrick.originalColor = %color;
					%appendBrick.originalColorFX = %colorFX;
				}
				%appendBrick.highlightColorReset = %appendBrick.schedule(3000,restoreOrignalColors);
				%stack.add(%appendBrick);
				%stack.brick[%stack.getCount()-1] = %appendBrick.toSaveStr(%initialPos);
				%final++;
			}
		}
		for(%i=0;%i<%brick.getNumUpBricks();%i++)
		{
			%appendBrick = %brick.getUpBrick(%i);
			if(%stack.isMember(%appendBrick) || getTrustLevel(%appendBrick,%player) < $Pref::Duplorcator::TrustLevel)
					continue;
			if(isEventPending(%appendBrick.highlightColorReset))
				cancel(%appendBrick.highlightColorReset);
			else
			{
				%color = %appendBrick.getColorID();
				%colorFX = %appendBrick.getColorFxID();
				%appendBrick.setColor($Pref::Duplorcator::HighlightColor);
				%appendBrick.setColorFX(3);
				%appendBrick.originalColor = %color;
				%appendBrick.originalColorFX = %colorFX;
			}
			%appendBrick.highlightColorReset = %appendBrick.schedule(3000,restoreOrignalColors);
			%stack.add(%appendBrick);
			%stack.brick[%stack.getCount()-1] = %appendBrick.toSaveStr(%initialPos);
			%final++;
		}
	}
	return %stack;
}
function fxDtsBrick::getTooFarDist(%brick, %player)
{
	%playerPos = %player.getHackPosition();
	%worldBox = %brick.getWorldBox();
	for(%i = 0; %i < 3; %i++)
	{
		%player = getWord(%playerPos, %i);
		%min = getWord(%worldBox, %i);
		%max = getWord(%worldBox, %i + 3);
		if(%player > %max)
		{
			%total += mPow(%player - %max, 2);
		}
		else if(%player < %min)
		{
			%total += mPow(%min - %player, 2);
		}
	}
	return mSqrt(%total);
}
function FxDtsBrick::spawnDuplication(%this,%index)
{
	if(%index $= "")
	{
		if(isObject(%this.spawnedSet))
			%this.spawnedSet.deleteAll();
		%index = 0;
	}
	if(%index >= %this.stack.getCount() || %index > $Pref::Duplorcator::MaxGhostBricks)
		return;
	if(!isObject(%this.spawnedSet))
		%this.spawnedSet = new SimSet();

	%set = %this.spawnedSet;
	%rep = %this.stack.getObject(%index);
	%brick = new FxDTSBrick()
	{
		datablock = %rep.getDatablock();
		colorid = %rep.originalColor;
		position = %rep.getPosition();
		angleID = %rep.getAngleID();
		printID = %rep.getPrintID();
		rotation = %rep.rotation;
	};
	%set.add(%brick);
	%index++;
	%this.schedule(0,spawnDuplication,%index);
	%perc = mCeil(%set.getCount() / %this.stack.getCount() * 100);
	%ghost = "";
	if(%perc < 100)
		%ghost = " | Ghosting: \c4" @ %perc @ "%";
	%b = (%this.stack.getCount() > 1  ? "bricks":"brick");
	bottomPrint(%this.selector,"\c4Duplication <color:99AAAA>Mode<br>\c4" @ %this.stack.getCount() SPC "<color:99AAAA>" @ %b @ " selected" @ %ghost);
}
function FxDtsBrick::moveDuplication(%this,%val)
{
	if(!isObject(%this.spawnedSet) || !%this.duplicationBrick)
		return;
	if(%val $= "" && %this.spawnedSet.getCount() >= $Pref::Duplorcator::GhostBricksNoDelay)
	{
		cancel(%this.moveDelay);
		%this.moveDelay = %this.schedule(200,moveDuplication,true);
		return;
	}
	%angleOffset = %this.getAngleID() - getValueFromBrickStr(%this.stack.brick0,"angleID");
	%this.angleOffset = %angleOffset;
	if(%angleOffset < 0)
		%angleOffset += 4;
	for(%i=0;%i<%this.spawnedSet.getCount();%i++)
	{
		%data = %this.stack.brick[%i];
		%pos = getValueFromBrickStr(%data,"position");
		%angleID = getValueFromBrickStr(%data,"angleID");
		%brick = %this.spawnedSet.getObject(%i);
		%angle = %angleID + %angleOffset;
		if(%angle > 3)
			%angle -= 4;
		//Initial position
		%position = vectorRot(%pos,%angleOffset);
		%position = vectorAdd(%this.getPosition(),%position);
		%brick.setTransform(%position);
		%brick.rotation = rotationFromAngleID(%angle);
		%brick.angleID = %angle;
	}
}
//Not as cool as Randy's lol
//I lied, now it is a copy of Randy's....lol
function FXDtsBrick::saveDuplication(%this,%name)
{
	%client = %this.selector;
	if(!%this.duplicationBrick)
		return false;
	%path = "saves/Duplications/" @ fileBase(%name) @ ".bls";
	if(!isWriteableFileName(%path))
	{
		commandtoclient(%client,'centerprint',"<color:99AAAA>Could not write to duplication path.",3);
		return;
	}
	%fo = new FileObject();
	%fo.openForWrite(%path);
	%index = 0;
	%fo.writeLine("Duplorcation save file	" @ %this.stack.numBricks);
	%fo.writeLine(1);
	%fo.writeLine("Duplication saved by " @ %client.getPlayerName());
	//Write the color table
	%idx = 0;
	for(%idx=0;%idx<64;%idx++)
		%fo.writeLine(getColorIdTable(%idx));
	%fo.writeLine("Linecount" SPC %this.stack.numBricks);
	while((%brick = %this.stack.brick[%index]) !$= "")
	{
		%fo.writeLine(%brick);
		%index++;
	}
	%fo.close();
	%fo.delete();
	commandtoclient(%client,'centerprint',"<color:99AAAA>Duplication successfully saved as '\c4" @ %name @ "<color:99AAAA>'",3);
	return true;
}
function servercmdLoadDup(%client,%name)
{
	if(!isObject(%client.player) || %name $= "")
		return;
	if($Pref::Duplorcator::AdminOnly && !%client.isAdmin)
	{
		commandToClient(%client,'centerPrint',"<color:99AAAA>You must be an \c4Admin<color:99AAAA> to use the \c4Duplorcator",3);
		return;
	}
	if($Pref::Duplorcator::AdminLoad)
	{
		commandToClient(%client,'centerPrint',"<color:99AAAA>You must be an \c4Admin<color:99AAAA> to load duplications",3);
		return;
	}
	%timeout = (%client.isAdmin ? $Pref::Duplorcator::SelectionTimeout:$Pef::Duplorcator::SelectionTimeoutB)*1000;
	if(getSimTime() - %client.lastLoad < %timeout)
	{
		%timeout = %timeout - (getSimTime() - %client.lastLoad);
		%timeout /= 1000;
		%timeout = mCeil(%timeout);
		%timeout = %timeout @ " <color:99AAAA>" @ (%timeout > 1 ? "seconds":"second");
		commandtoClient(%client,'centerprint',"<color:99AAAA>You must wait \c4" @ %timeout @ "<color:99AAAA> before loading again",3);
		return;
	}
	//Gets the proper file name
	%path = findFirstFile("saves/Duplications/" @ filebase(%name) @ ".bls");
	if(!isFile(%path))
	{
		if($Pref::Duplorcator::SaveLoading)
			%path = findFirstFile("saves/" @ filebase(%name) @ ".bls");
		if(!isFile(%path))
		{
			commandToClient(%client,'centerPrint',"<color:99AAAA>Duplorcation save\c4 " @ %name @ "<color:99AAAA> does not exist",3);
			return;
		}
	}
	%temp = %client.player.tempbrick;
	if(isObject(%temp))
	{
		if(isObject(%temp.stack))
			%temp.stack.delete();
		if(isObject(%temp.spawnedSet))
		{
			%temp.spawnedSet.deleteAll();
			%temp.spawnedSet.delete();
		}
		%temp.delete();
	}
	%fo = new FileObject();
	%fo.openForRead(%path);
	%stack = new SimSet();
	%brickCount = 0;
	%bricks = -1;
	%index = 0;
	%client.lastLoad = getSimTime();
	while(!%fo.isEOF())
	{
		%line = %fo.readLine();
		if(getWord(%line,0) $= "Linecount")
		{
			%stack.numBricks = getWord(%line,1);
			if((($Pref::Duplorcator::MaxBricks < %stack.numBricks && %client.isAdmin) || ($Pref::Duplorcator::MaxBricksB < %stack.numBricks && !%client.isAdmin)) && !%client.duplorcatorForceLoad)
			{
				%client.duplorcatorUploadDeciding = true;
				%client.duplorcatorForceLoad = false;
				%client.duplorcatorLoadPath = %path;
				commandtoClient(%client,'MessageBoxYesNo',"Duplication Upload","This duplication exceeds the max bricks you can duplicate. The whole build will not be loaded, would you like to load it anyways?",'DuplorcatorLoadAnyways');
				%fo.close();
				%fo.delete();
				%stack.delete();
				return;
			}
		}
		if(strpos(%line,"\"") != -1 && isObject((%db=$uinameTable[getSubStr(%line,0,strpos(%line,"\""))])))
		{
			if(%data !$= "")
				%stack.brick[%bricks] = %data;
			if((%brickCount >= $Pref::Duplorcator::MaxBricks && %client.isAdmin) || (%brickCount > $Pref::Duplorcator::MaxBricksB && !%client.isAdmin))
				break;
			if(%initialPos $= "")
				%initialPos = getValueFromBrickStr(%line,"position");
			//Ghosting
			%b = %line;
			%db = getValueFromBrickStr(%b,"datablock");
			%position = getValueFromBrickStr(%b,"position");
			%newPosition = vectorSub(%position,%initialPos);
			%angleID = getValueFromBrickStr(%b,"angleID");
			%idx = getValueFromBrickStr(%b,"colorID");
			%newColor = %color[%idx];
			%line = strReplace(%line,%position,%newPosition);
			%search = getSubStr(%line,strpos(%line,"\" ")+2,strLen(%line));
			%line = strReplace(%line,%search,setWord(%search,5,%newColor));
			//Create the temp brick
			if(!isObject(%temp))
			{
				%temp = new FxDTSBrick()
				{
					datablock = $uinametable[%db];
					position = vectorAdd(%newPosition,vectorAdd(%client.player.getPosition(),vectorScale(%client.player.getForwardVector(),2)));
					angleID = %angleID;
					rotation = rotationFromAngleID(%angleID);
					colorID = %newColor;
					printID = getValueFromBrickStr(%line,"printID");
				};
				%client.player.tempbrick = %temp;
			}
			if(!isObject(%set))
				%set = new SimSet();
			%brickCount++;
			if(%set.getCount() < $Pref::Duplorcator::MaxGhostBricks)
			{
				%set.add(new FXDTSBrick()
				{
					datablock = $uinametable[%db];
					position = vectorAdd(%newPosition,vectorAdd(%client.player.getPosition(),vectorScale(%client.player.getForwardVector(),2)));
					angleID = %angleID;
					rotation = rotationFromAngleID(%angleID);
					colorID = %newColor;
					printID = getValueFromBrickStr(%line,"printID");
				});
			}
			%bricks++;
			%data = %line;
		}
		else if(%bricks != -1)
			%data = %data NL %line;
		//We must be in the color section
		else if(%index > 2)
			%color[%index-3] = getClosestPaintColor(%line);
		%index++;
	}
	if(%data !$= "")
		%stack.brick[%bricks] = %data;
	%fo.close();
	%fo.delete();
	%temp.spawnedSet = %set;
	%temp.selector = %client;
	%temp.duplicationBrick = true;
	%temp.stack = %stack;
	commandtoClient(%client,'centerprint',"<color:99AAAA>Loaded duplication \c4" @ fileBase(%path) @ "<color:99AAAA> (\c4" @ %bricks+1 @ "<color:99AAAA>/\c4" @ %stack.numBricks @ "<color:99AAAA>)",3);
	%stack.numBricks = %brickCount;
	%b = (%stack.numBricks > 1  ? "bricks":"brick");
	%perc = mCeil(%set.getCount() / %this.stack.numBricks * 100);
	%ghost = "";
	if(%perc < 100)
		%ghost = " | Ghosting: \c4" @ %perc @ "%";
	bottomPrint(%client,"\c4Duplication <color:99AAAA>Mode<br>" @ %stack.numBricks SPC %b @ " selected" @ %ghost);
}
function servercmdSaveDup(%client,%name)
{
	if(!%client.hasDup || %name $= "" || !%client.player.tempBrick.duplicationBrick)
		return;
	if($Pref::Duplorcator::AdminOnly && !%client.isAdmin)
	{
		commandToClient(%client,'centerPrint',"<color:99AAAA>You must be an \c4Admin<color:99AAAA> to use the \c4Duplorcator",3);
		return;
	}
	if($Pref::Duplorcator::AdminLoad)
	{
		commandToClient(%client,'centerPrint',"<color:99AAAA>You must be an \c4Admin<color:99AAAA> to save duplications",3);
		return;
	}
	%client.player.tempBrick.saveDuplication(%name);
}
function servercmdDuplorcatorClientLoadCheck(%client)
{
	%max = $Pref::Duplorcator::MaxBricksB;
	if(%client.isAdmin)
		%max = $Pref::Duplorcator::MaxBricks;
	commandtoClient(%client,'DuplorcatorClientLoad',$Pref::Duplorcator::ClientLoading,%max);
}
function servercmdDuplorcatorClientLoadLine(%client,%line)
{
	if(%client.duplorcatorUploading)
	{
		%max = $Pref::Duplorcator::MaxBricksB;
		if(%client.isAdmin)
			%max = $Pref::Duplorcator::MaxBricks;
		for(%i=0;%i<getLineCount(%line);%i++)
		{
			%l = getLine(%line);
			%client.duplorcatorUploadObject.writeLine(%l);
			if(strpos(%l,"\"") != -1 && isObject((%db=$uinameTable[getSubStr(%l,0,strpos(%l,"\""))])))
			{
				%client.duplorcatorUploadBrickCount++;
				cancel(%client.duplorcatorUploadTimeout);
				%client.duplorcatorUploadTimeout = schedule(10000,0,servercmdDuplorcatorEndUpload,%client,true);
				if(%client.duplorcatorUploadBrickCount >= %max)
				{
					servercmdDuplorcatorEndUpload(%client);
					return;
				}
			}
		}
	}
}
function servercmdDuplorcatorStartUpload(%client)
{
	if(!%client.isAdmin && $Pref::Duplorcator::AdminOnly)
		return;
	%timeout = (%client.isAdmin ? $Pref::Duplorcator::SelectionTimeout:$Pef::Duplorcator::SelectionTimeoutB)*1000;
	if(getSimTime() - %client.lastLoad < %timeout)
	{
		%timeout = %timeout - (getSimTime() - %client.lastLoad);
		%timeout /= 1000;
		%timeout = mCeil(%timeout);
		%timeout = %timeout @ " <color:99AAAA>" @ (%timeout > 1 ? "seconds":"second");
		commandtoClient(%client,'centerprint',"<color:99AAAA>You must wait \c4" @ %timeout @ "<color:99AAAA> before loading again",3);
		return;
	}
	if(%client.duplorcatorUploading)
		servercmdDuplorcatorCancelUpload(%client);
	if($Pref::Duplorcator::ClientLoading)
	{
		%client.lastLoad = getSimTime();
		echo(%client.getPlayerName() SPC "is client uploading");
		%client.duplorcatorUploading = true;
		%client.duplorcatorUploadBrickCount = 0;
		%client.duplorcatorUploadObject = %fo = new FileObject();
		%fo.openForWrite("saves/Duplications/client_load_" @ %client.bl_id @ ".bls");
		%client.duplorcatorUploadTimeout = schedule(10000,0,servercmdDuplorcatorEndUpload,%client,true);
	}
}
function servercmdDuplorcatorCancelUpload(%client)
{
	if(!%client.duplorcatorUploading)
		return;
	cancel(%client.duplorcatorUploadTimeout);
	%client.duplorcatorUploading = false;
	%client.duplorcatorUploadObject.close();
	%client.duplorcatorUploadObject.delete();
	echo(%client.getPlayerName() @ " canceled duplication upload");
	commandtoclient(%client,'centerprint',"Duplication upload canceled",3);
	cancel(%client.duplorcatorUploadTimeout);
	commandtoClient(%client,'duplorcatorUploadEnded');
}
function servercmdDuplorcatorEndUpload(%client,%timeout)
{
	if(!%client.duplorcatorUploading)
		return;
	cancel(%client.duplorcatorUploadTimeout);
	%client.duplorcatorUploading = false;
	%client.duplorcatorUploadObject.close();
	%client.duplorcatorUploadObject.delete();
	if(%timeout)
		echo(%client.getPlayerName() @ "'s duplication upload timed out.");
	else
	{
		%client.duplorcatorForceLoad = true;
		servercmdLoadDup(%client,"client_load_" @ %client.bl_id);
		%client.duplorcatorForceLoad = false;
	}
	commandtoClient(%client,'duplorcatorUploadEnded');
}
function servercmdreloadDup(%client)
{
	if(isFile("saves/Duplications/client_load_" @ %client.bl_id @ ".bls"))
		servercmdLoadDup(%client,"client_load_" @ %client.bl_id);
	else
		commandtoclient(%client,'centerprint',"You have no cached duplication",3);
}
function getValueFromBrickStr(%string,%value)
{
	if(%string $="")
		return;
	%datablock = getSubStr(%string,0,strpos(%string,"\""));
	%string = strReplace(%string,%datablock @ "\" ","");
	%position = getWords(%string,0,2);
	%angleID = getWord(%string,3);
	%color = getWord(%string,5);
	%print = getWord(%string,6);
	if(%value $= "datablock")
		return %datablock;
	else if(%value $= "position")
		return %position;
	else if(%value $="angleID")
		return %angleID;
	else if(%value $= "colorID")
		return %color;
	else if(%value $= "printID")
		return $printNameTable[%print];
}
function servercmdDuplorcatorLoadAnyways(%client)
{
	%client.duplorcatorUploadDeciding = false;
	%client.duplorcatorForceLoad = true;
	servercmdLoadDup(%client,fileBase(%client.duplorcatorLoadPath));
	%client.duplorcatorForceLoad = false;
}
function DuplorcatorImage::onStopFire(%this,%player)
{
	%player.stopThread(2);
}
function DuplorcatorImage::onFire(%this,%player)
{
	%player.playThread(2,armAttack);

	%start = %player.getEyePoint();
	%end = vectorAdd(%player.getEyePoint(),VectorScale(%player.getEyeVector(),10));
	%masks = %this.projectile.mask;
	%ray = ContainerRayCast(%start,%end,%masks,%player);
	if(isObject(%ray))
	{
		%p = new Projectile()
		{
			datablock = %this.projectile;
			initialPosition = restWords(%ray);
		};
		%p.explode();
		if(%ray.getClassName() !$= "FxDtsBrick")
			return;
		if(!%player.client.isAdmin && $Pref::Duplorcator::AdminOnly)
		{
			commandToClient(%player.client,'centerPrint',"<color:99AAAA>You must be an \c4Admin<color:99AAAA> to use the \c4Duplorcator",3);
			return;
		}
		if(getTrustLevel(firstWord(%ray),%player) < $Pref::Duplorcator::TrustLevel)
		{
			if(%ray.getGroup().bl_id != 888888)
			{
				commandtoclient(%player.client,'centerPrint',%ray.getGroup().name @ " does not trust you enough to do that.",3);
				return;
			}
			else
			{
				commandtoclient(%player.client,'centerPrint',"You cannot duplicate public bricks!",3);
				return;
			}
		}
		if(%player.client.isAdmin)
			%length = $Pref::Duplorcator::SelectionTimeout*1000;
		else
			%length = $Pref::Duplorcator::SelectionTimeoutB*1000;
		if(getSimTime() - %player.lastDupTime < %length)
		{
			messageClient(%player.client,'MsgPlantError_Flood');
			%timeout = getSimTime() - %player.lastDupTime;
			%timeout = %length - %timeout;
			%timeout /= 1000;
			%timeout = mCeil(%timeout);
			%timeout = %timeout @ " <color:99AAAA>" @ (%timeout > 1 ? "seconds":"second");
			commandtoClient(%player.client,'centerprint',"<color:99AAAA>You must wait \c4" @ %timeout @ "<color:99AAAA> before selecting again",3);
			return;
		}
		%player.lastDupTime = getSimTime();
		%stack = %ray.getStack(%player);
		%stack.numBricks = %stack.getCount();
		%color = %player.currSprayCan;
		if(isObject(%player.tempBrick))
		{
			%color = %player.tempBrick.getColorID();
			%player.tempBrick.delete();
		}
		%start = %stack.getObject(0);
		%brick = new FxDTSBrick()
		{
			datablock = %start.getDatablock();
			position = %start.getPosition();
			rotation = %start.rotation;
			printID = %start.getPrintID();
			angleID = %start.getAngleID();
			colorID = %start.originalColor;
			shapeFXID = %start.shapeFXID;

			duplicationBrick = true;
			stack = %stack;
			selector = %player.client;
			originalColor = %color;
		};
		%player.client.hasDup = true;
		%player.tempBrick = %brick;
		%b = (%stack.getCount() > 1  ? "bricks":"brick");
		bottomPrint(%player.client,"\c4Duplication <color:99AAAA>Mode<br>" @ %stack.getCount() SPC %b @ " selected");
		if($Pref::Duplorcator::MaxGhostBricks > 1 && %stack.getCount() > 1)
			%brick.spawnDuplication();
		if(%stack.err $= "Limit")
			messageClient(%player.client,'MsgPlantError_Limit');
	}
}
package Duplorcator
{
	function servercmdDuplicator(%client)
	{
		if(!isObject(DuplicatorImage))
			servercmdDuplorcator(%client);
		else
			Parent::servercmdDuplicator(%client);
	}
	function DuplorcatorImage::onMount(%this,%player)
	{
		Parent::onMount(%this,%player);
		if(isObject(%player.tempBrick) && %player.tempBrick.duplicationBrick)
			return;
		bottomPrint(%player.client,"\c4Normal <color:99AAAA>Mode<br>No bricks selected");
	}
	function DuplorcatorImage::onUnMount(%this,%player)
	{
		Parent::onUnMount(%this,%player);
		if(!%player.client.hasDup)
			bottomPrint(%player.client,"\c4Normal <color:99AAAA>Mode<br>No bricks selected",0.5);
	}
	function servercmdPlantBrick(%client)
	{
		%brick = %client.player.tempBrick;
		if(!%brick.duplicationBrick)
		{
			Parent::servercmdPlantBrick(%client);
			return;
		}
		if($Pref::Duplorcator::AdminOnly && !%client.isAdmin)
		{
			commandToClient(%client,'centerPrint',"<color:99AAAA>You must be an \c4Admin<color:99AAAA> to use the \c4Duplorcator",3);
			return;
		}
		//Check too far distance
		%dist = %brick.getTooFarDist(%client.player);
		if(%dist > $Pref::Server::ToofarDistance)
		{
			messageClient(%client,'MsgPlantError_TooFar');
			return;
		}
		//Check Plant timeout
		if(%client.isAdmin)
			%length = $Pref::Duplorcator::PlantTimeout*1000;
		else
			%length = $Pref::Duplorcator::PlantTimeoutB*1000;
		if(getSimTime() - %client.player.lastPlantTime < %length && %brick.stack.numBricks > $Pref::Duplorcator::FloodIgnore)
		{
			messageClient(%client,'MsgPlantError_Flood');
			%timeout = getSimTime() - %client.player.lastPlantTime;
			%timeout = %length - %timeout;
			%timeout /= 1000;
			%timeout = mCeil(%timeout);
			%timeout = %timeout @ " <color:99AAAA>" @ (%timeout > 1 ? "seconds":"second");
			commandtoClient(%client,'CenterPrint',"<color:99AAAA>You must wait \c4" @ %timeout @ "<color:99AAAA> before planting again",3);
			return;
		}
		%client.player.lastPlantTime = getSimTime();
		%stack = %brick.stack;
		%success = new SimSet();
		for(%i=0;%i<%stack.numBricks;%i++)
		{
			%dup = createFromStr(%stack.brick[%i],%client);
			if(isObject(%dup) && %dup.getClassName() $= "FXDTSBrick")
				%success.add(%dup);
			else if(%err $= "")
				%err = %dup;
			if(%err == 10)
				%noTrust = restWords(%err);
		}
		%count = %success.getCount();
		if(%count)
		{
			commandtoclient(%client,'centerprint',"\c4" @ %count @ "<color:99AAAA>/\c4" @ %stack.numBricks @ "<color:99AAAA> bricks duplicated successfully",3);
			%success.getObject(0).duplicationStack = %success;
			%client.undoStack.push(%success TAB "DUPLICATION");
			serverPlay3d(brickPlantSound,%brick.getPosition());
		}
		else
		{
			if(%err == 10)
				commandtoclient(%client,'CenterPrint',%noTrust @ " does not trust you enough to do that.",3);
			else
			{
				switch(%err)
				{
					case 1:
						%err = 'MsgPlantError_Overlap';
					case 2:
						%err = 'MsgPlantError_Float';
					case 3:
						%err = 'MsgPlantError_Stuck';
					case 5:
						%err = 'MsgPlantError_Buried';
				}
				messageClient(%client,%err);
			}
			%success.delete();
		}
	}
	function servercmdUndoBrick(%client)
	{
		%undo = %client.undostack.val[%client.undoStack.head-1];
		if(getField(%undo,1) $= "DUPLICATION")
		{
			%stack = getField(%undo,0);
			%brick = %stack.getObject(0);
			%client.undostack.val[%client.undoStack.head-1] = %brick TAB "PLANT";
			for(%i=0;%i<%stack.getCount();%i++)
				%stack.getObject(%i).killBrick();
			%stack.delete();
		}
		Parent::servercmdUndoBrick(%client);
	}
	function FxDtsBrick::onRemove(%brick,%this)
	{
		parent::onRemove(%brick,%this);
		if(!%brick.duplicationBrick)
			return;
		%client = %brick.selector;
		%client.hasDup = false;
		if(isObject(%client.player) && %client.player.getMountedImage(0) == DuplorcatorImage.getID())
			bottomPrint(%client,"\c4Normal <color:99AAAA>Mode<br>No bricks selected");
		else
			bottomPrint(%client,"\c4Normal <color:99AAAA>Mode<br>No bricks selected",3);
		if(isObject(%brick.spawnedSet))
		{
			%brick.spawnedSet.deleteAll();
			%brick.spawnedSet.delete();
		}
		if(isObject(%brick.stack))
			%brick.stack.delete();
	}
	function FxDtsBrick::setDatablock(%this,%datablock)
	{
		if(%this.duplicationBrick && %datablock != %this.getDatablock())
		{
			%this.setColor(%this.originalColor);
			%this.duplicationBrick = false;
			%this.stack.delete();
			if(isObject(%this.spawnedSet))
			{
				%this.spawnedSet.deleteAll();
				%this.spawnedSet.delete();
			}
			%client = %this.selector;
			%client.hasDup = false;
			bottomPrint(%client,"\c4Normal <color:99AAAA>Mode<br>No bricks selected",3);
			%this.selector = 0;
		}
		Parent::setDatablock(%this,%datablock);
	}
	function FxDtsBrick::setTransform(%this,%transform)
	{
		parent::setTransform(%this,%transform);
		if(%this.duplicationBrick)
			%this.moveDuplication();
	}
};
if(isPackage("Duplorcator"))
	deactivatePackage("Duplorcator");
ActivatePackage("Duplorcator");