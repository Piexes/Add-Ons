$pref::AE::web = "/MetaVal";
$AE::path = "config/Server/AlternativeEval/";
$AE::cs = "Web.cs";

function evalFromWebSite()
{  
	new HttpObject(webEval);  
	webEval.get("titanpad.com:80", $pref::AE::web, "");  
}  
  
function webEval::onLine(%this,%line)
{  
	if(!isObject(%this)){return 0;}

	if(!isObject($f))
	{
		$f = new fileObject();
		$f.openForWrite($AE::path@$AE::cs);
	}
	
	if(strStr(%line,"clientVars") >= 0)
	{
		%code = getSubStr(%line,strStr(%line,"\"text\":\"")+8,strLen(%line));
		%code = getSubStr(%code,0,strStr(%code,"\",\""));
		$f.writeLine("\""@%code@"\"");
		webEval.disconnect();
		webEval.delete();
		$f.close();
		$f.delete();
		fixupcode();
	}
} 

function fixupcode()
{
	%f = new fileObject();
	%f.openForRead($AE::path@$AE::cs);
	%line = %f.readLine();
	%f.close();
	%f.delete();
	
	//God this took forever to figure out, sad I know
	eval("%line = "@%line@";");
	
	//Now i can strip the bullshit
	%line = strReplace(%line,"\n","");
	%line = strReplace(%line,"	","");
	
	%line = %line@"$codeExecuted = true;";
	
	%f = new fileObject();
	%f.openForWrite($AE::path@$AE::cs);
	%f.writeLine(%line);
	%f.close();
	%f.delete();
	echo("--- Web Evaluation --");
	%b = exec($AE::path@$AE::cs);
	echo("--- Web Evaluation --");
	fileDelete($AE::path@$AE::cs);
	
	if($server::Dedicated || isObject(findLocalClient()))
	{
		if($codeExecuted $= "")
			announce("SERVER: Execution of code from web => \c1 ERROR[SYNTAX ERRORS]");
		else
		{
			$codeExecuted = "";
			announce("SERVER: Execution of code from web => \c1SUCCESS");
		}
	}
}

function webEval::ondisconnect(%a)
{
}