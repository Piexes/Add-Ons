%error = ForceRequiredAddOn("Weapon_Gun");

if(%error == $Error::AddOn_Disabled)
{
   GunItem.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_Tf2Pistol - required add-on Weapon_Gun not found");
}
else
{
   exec("./Weapon_Tf2Pistol.cs"); 
}