exec("./Support_DateTime.cs");
exec("./Support_LibStr.cs");
exec("./Support_PreLoad.cs");
exec("./Support_SemVer.cs");
exec("./Support_TCPClient.cs");
exec("./Support_TMLParser.cs");

exec("./statistics.cs");

if($Pref::Updater::DefaultPrefVersion !$= "0.5.0")
{
	$Pref::Updater::DefaultPrefVersion = "0.5.0";
	//default preferences:
	$Pref::Updater::DedicatedServerUpdates = true;
	$Pref::Updater::QueryInterval = 1;
	$Pref::Updater::SilentUpdates = false;
	echo("Updater set default preferences.");
}

//Handles startup tasks and initializes update check.
function updater::onAdd(%this)
{
	%date = getDateTime();
	%last = $Pref::Updater::LastQueryDate;
	%interval = $Pref::Updater::QueryInterval;
	%this.readFileInfo();
	if($Updater::ManualQuery || !strLen(%last) || DT_getDayDifference(%last, %date) >= %interval)
	{
		$Pref::Updater::LastQueryDate = %date;
		%this.schedule(100, "queryRepositories");
	}
}

//Handles cleanup tasks.
function updater::onRemove(%this)
{
	%this.queue.delete();
}

//Reads version information from all .zip files in Add-Ons.
function updater::readFileInfo(%this)
{
	%readFO = new FileObject();

	%mask = "Add-Ons/*/version.txt";
	for(%file = findFirstFile(%mask); %file !$= ""; %file = findNextFile(%mask))
	{
		%filePath = filePath(%file);
		%zip = %filePath @ ".zip";
		if($Pref::Updater::ZippedFilesOnly)
		{
			if(!isFile(%zip))
				continue;
		}
		%zipPath = filePath(%zip);
		if(%zipPath !$= "Add-Ons")
			continue;
		%zipBase = fileBase(%zip);
		%readFO.openForRead(%file);
		while(!%readFO.isEOF())
		{
			%line = %readFO.readLine();
			%this.parseFileLine(%zipBase, %line);
		}
		%readFO.close();
	}

	%readFO.delete();
}

//Parses individual lines of version information files.
//@param	string addon	The name of the add-on, such as Weapon_Gun.
//@param	string line	The line to parse.
function updater::parseFileLine(%this, %addon, %line)
{
	if(getFieldCount(%line) == 2)
	{
		%tag = getField(%line, 0);
		%val = getField(%line, 1);
	}
	else if(getWordCount(%line) == 2)
	{
		%tag = getWord(%line, 0);
		%val = getWord(%line, 1);
	}
	else
	{
		return;
	}

	if(!isObject(%this.addon[%addon]))
	{
		%this.addon[%addon] = new ScriptObject()
		{
			name = %addon;
		};
		%this.add(%this.addon[%addon]);
	}

	%this.addon[%addon].tag[%tag] = %val;
}

//Connects to repositories and looks for updates.
function updater::queryRepositories(%this)
{
	//hack to update broken 3rd party mods
	if(!isObject(%this.addon["__updaterDummy3rdParty"]))
	{
		%this.parseFileLine("__updaterDummy3rdParty", "repository\tmods.greek2me.us/third-party");
	}

	%count = %this.getCount();
	for(%i = 0; %i < %count; %i ++)
	{
		%addon = %this.getObject(%i);
		%url = %addon.tag["repository"];
		if(%url $= "")
		{
			continue;
		}

		%components = urlGetComponents(%url);
		%server = getField(%components, 1);
		%port = getField(%components, 2);
		%path = getField(%components, 3);
		%query = getField(%components, 4);

		%simpleURL = %server @ %path;
		if(strLen(%query))
			%simpleURL = %simpleURL @ "?" @ %query;
		%addon.simpleURL = %simpleURL;

		if(!%queried[%simpleURL] && strLen(%simpleURL))
		{
			%queried[%simpleURL] = true;
			
			//send the username with the query
			%name = "user=" @ urlEnc($Pref::Player::NetName);
			%query = (%query $= "" ? %name : %query @ "&" @ %name);
			
			%tcp = TCPClient("GET", %server, %port, %path, %query, "", "updaterRepoTCP");
			if(isObject(%tcp))
			{
				%tcp.parserObj = new ScriptObject()
				{
					tcpObj = %tcp;
				};
				%tcp.repoFullUrl = %url;
				%tcp.repoSimpleURL = %simpleURL;
			}
		}
	}
}

//Downloads and installs selected updates.
function updater::doUpdates(%this)
{
	%this.queue.downloadNext();
}

//Adds an add-on to the update queue
//@param	string addon	The name of an add-on w/ an available update, such as Weapon_Gun.
function updaterQueue::push(%this, %addon)
{
	if(!strLen(updater.repoTag[%addon, "file"]))
	{
		error("ERROR:" SPC %addon SPC "invalid download URL.");
		return;
	}
	%downloadPath = "Add-Ons/" @ %addon @ ".zip";
	if(!isWriteableFileName(%downloadPath))
	{
		error("ERROR:" SPC %addon SPC "invalid download path.");
		//return; //this will be caught later in the process - at least let the user know there's an update
	}

	%currentVersion = updater.addon[%addon].tag["version"];

	//maybe this should be created outside of ::push and then given as argument
	%download = new ScriptObject()
	{
		addon = %addon;
		downloadPath = %downloadPath;
		repoName = updater.repoName[%addon];

		updateVersion = updater.repoTag[%addon, "version"];
		updateFileURL = updater.repoTag[%addon, "file"];
		updateChangeLogURL = updater.repoTag[%addon, "changeLog"];
		updateRestartRequired = (semanticVersionCompare(updater.repoTag[%addon, "restartRequired"], %currentVersion) == 1);
		updateDescription = updater.repoTag[%addon, "desc"];
	};
	%this.add(%download);
	%this.addon[%addon] = %download;

	if($Pref::Updater::SilentUpdates)
	{
		cancel(updater.silentUpdateSched);
		updater.silentUpdateSched = updater.schedule(5000, "doUpdates");
	}
	else
	{
		updaterInterfacePushItem(%download);
	}

	echo(%addon SPC "added to download queue.");
}

//Deletes the first object from the queue.
function updaterQueue::pop(%this)
{
	%download = %this.getObject(0);
	if(!$Pref::Updater::SilentUpdates)
		updaterInterfacePopItem(%download);
	%download.delete();
}

//Advances to the next file and begins downloading it.
function updaterQueue::downloadNext(%this)
{
	if(%this.getCount() < 1)
	{
		%this.onQueueEmpty();
		return;
	}
	%this.currentDownload = %this.getObject(0);

	//view info
	if(!$Pref::Updater::SilentUpdates)
		updaterInterfaceSelectItem(%this.currentDownload);

	%this.downloadTCP = connectToURL(%this.currentDownload.updateFileURL, "GET", %this.currentDownload.downloadPath, "updaterDownloadTCP");
}

//Downloads the change log associated with an object in the queue.
//@param	ScriptObject queueObj	A download object which is currently in the queue.
function updaterQueue::downloadChangeLog(%this, %queueObj)
{
	%queueObj.changeLogTCP = connectToURL(%queueObj.updateChangeLogURL, "GET", "", "updaterChangeLogTCP");
	%queueObj.changeLogTCP.queueObj = %queueObj;
}

//Handles cleanup tasks after a download has finished.
function updaterQueue::onDownloadFinished(%this, %error)
{
	%addon = %this.currentDownload.addon;
	if(%error)
	{
		warn("Unable to update" SPC %addon @ "! TCPClient error" SPC %error);
		updater.hasErrors = true;
	}
	else
	{
		%callbackFile = "Add-Ons/" @ %addon @ "/update.cs";
		%restart = %this.currentDownload.updateRestartRequired;
		%zip = "Add-Ons/" @ %addon @ ".zip";
		discoverFile(%zip);
		$version__[%addon] = %this.currentDownload.updateVersion;
		$versionOld__[%addon] = updater.addon[%addon].tagVersion;
		$versionRestartRequired__[%addon] = %restart;
		if(isFile(%callbackFile))
		{
			echo(%addon SPC "running update scripts.");
			exec(%callbackFile);
		}
		if(%restart)
		{
			warn(%addon SPC "requires a restart!");
			updater.restartRequired = true;
		}
		else
		{
			echo(%addon SPC "update completed!");
			%file = "Add-Ons/" @ %addon @ "/server.cs";
			if(isFile(%file) && $Game::Running && $AddOnLoaded__[%addon])
				exec(%file);
			%file = "Add-Ons/" @ %addon @ "/client.cs";
			if(isFile(%file) && !$Server::Dedicated)
				exec(%file);
		}
	}

	%this.currentDownload = "";

	%this.pop();
	%this.downloadNext();
}

//Called when all downloads have completed.
function updaterQueue::onQueueEmpty(%this)
{
	if(!$Pref::Updater::SilentUpdates)
		updaterInterfaceOnQueueEmpty();
	updater.schedule(0, "delete");
}

//Handles cleanup after a file has been downloaded.
function updaterDownloadTCP::onDone(%this, %error)
{
	updater.queue.onDownloadFinished(%error);
}

//Sets the progress bar.
//@param	float value	A floating point number from 0 to 1.
function updaterDownloadTCP::setProgressBar(%this, %value)
{
	%progressBar = updater.queue.currentDownload.guiSwatch.progress;
	if(isObject(%progressBar))
		%progressBar.setValue(%value);
}

//Cleans up after the connection has completed.
function updaterRepoTCP::onDone(%this, %error)
{
	if(isObject(%this.parserObj))
		%this.parserObj.delete();
}

//Callback from the TCP library.
function updaterRepoTCP::handleText(%this, %text)
{
	parseCustomTML(%text, %this.parserObj, "updater");
}

//Parses version info from repository.
function customTMLParser_updater(%obj,%val0,%val1,%val2,%val3,%val4,%val5,%val6,%val7,%val8,%val9,%val10,%val11,%val12,%val13,%val14,%val15)
{
	switch$(%val[0])
	{
		case "repository":
			if(strLen(%val[1]))
				%obj.repoName = %val[1];
			else
				%obj.repoName = %obj.tcpObj.repoSimpleURL;
			echo("Updater checking repository" SPC %obj.repoName);

		case "/repository":
			if(%obj.addedToQueue > 0)
			{

			}
			%obj.repoName = "";

		case "addon":
			%obj.addon = %val[1];
			if(!isObject(updater.addon[%val[1]]) && isFile("Add-Ons/" @ %val[1] @ ".zip"))
			{
				if(%obj.tcpObj.server $= "mods.greek2me.us")
				{
					//This is a special exception for RTB.
					//I have to resort to awful hacks like this
					// because people like their special RTB
					// versions.
					if(%val[1] $= "System_ReturnToBlockland")
					{
						%crc = getFileCRC("Add-Ons/System_ReturnToBlockland.zip");
						if(%crc $= "-1")
							%channel = "Not_a_real_channel";
						else if(%crc $= "-343036381")
							%channel = "DAProgs";
						else if(%crc $= "-642662817")
							%channel = "Port";
						else
							%channel = "NO_INET";
					}
					else
					{
						%channel = "release";
					}
					
					updater.parseFileLine(%obj.addon, "version\t0");
					updater.parseFileLine(%obj.addon, "channel" TAB %channel);
					updater.parseFileLine(%obj.addon, "repository" TAB %obj.tcpObj.repoFullUrl);
					updater.addon[%obj.addon].simpleURL = %obj.tcpObj.repoSimpleURL;
				}
			}
			%obj.addonSO = updater.addon[%val[1]];
			if(isObject(%obj.addonSO) && !$Pref::Updater::Ignore[%val[1]])
			{
				if(%obj.tcpObj.repoSimpleURL !$= %obj.addonSO.simpleURL)
				{
					warn(%obj.repoName SPC "does not own" SPC %obj.addon @ "!");
					%obj.skipAddon = true;
				}
			}
			else
			{
				%obj.skipAddon = true;
			}

		case "/addon":
			if(!%obj.skipAddon)
			{
				updater.repoName[%obj.addon] = %obj.repoName;
				if(semanticVersionCompare(updater.repoTag[%obj.addon, "version"], %obj.addonSO.tag["version"]) == 1)
				{
					%obj.addedToQueue ++;
					updater.queue.push(%obj.addon);
				}
			}
			%obj.skipAddon = false;
			%obj.addon = "";
			%obj.addonSO = "";

		case "channel":
			if(%val[1] $= %obj.addonSO.tag["channel"])
			{
				%obj.inUpdateChannel = true;
			}

		case "/channel":
			%obj.inUpdateChannel = "";

		default:
			if(!%obj.skipAddon && %obj.inUpdateChannel)
			{
				%v = %val[1];
				//URL handling
				if((%v $= "http" || %v $= "https") &&
					strPos(%val[2], "//") == 0)
				{
					%v = getSubStr(%val[2], 2, strLen(%val[2]));
				}
				updater.repoTag[%obj.addon, %val[0]] = %v;
			}
	}
}

//Displays the change log text.
function updaterChangeLogTCP::onDone(%this, %error)
{
	if(updaterDlg.viewItem == %this.queueObj)
	{
		if(%error)
		{
			updaterDlgChangeLogText.setText("<color:ffffff><just:center>\n\n\n\nError occured. Change log unavailable.");
		}
		else
		{
			if(!%this.queueObj.changeLogParsed)
			{
				%this.queueObj.changeLogText = parseCustomTML(
					"<color:ffffff><linkcolor:cccccc>" @ %this.queueObj.changeLogText,
					updaterDlgChangeLogText,
					"updaterChangeLog\tdefault");
				%this.queueObj.changeLogParsed = true;
			}
			updaterDlgChangeLogText.setText(%this.queueObj.changeLogText);
		}
	}
}

//Callback from the TCP library.
function updaterChangeLogTCP::handleText(%this, %text)
{
	%this.queueObj.changeLogText = %this.queueObj.changeLogText @ %text;
}

function customTMLParser_updaterChangeLog(%obj,%value0,%value1)
{
	switch$(%value[0])
	{
		case "version":
			return true TAB "<h3>Version" SPC %value[1] @ "</h3>";

		case "/version":
			return true TAB "<br><br>";
	}

	return false;
}

if(!isObject(updater))
{
	new ScriptGroup(updater);
	updater.queue = new ScriptGroup()
	{
		class = "updaterQueue";
	};
}