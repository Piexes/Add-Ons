if(!$Server::Dedicated)
	return;

exec("./common.cs");

function update()
{
	cancel($Updater::dediContinueSched);
	if(!isObject(updater.queue) || updater.queue.getCount() < 1)
		echo("There are no updates to be performed.");
	else if(isObject(updater.queue.currentDownload))
		echo("An update is in progress.");
	else
	{
		echo("Performing updates...");
		updater.doUpdates();
		return true;
	}
	return false;
}

function skip(%addon, %ignore)
{
	cancel($Updater::dediContinueSched);
	%obj = updater.queue.addon[%addon];
	if(isObject(%obj))
	{
		if(%ignore)
		{
			echo("Ignoring" SPC %obj.addon);
			$Pref::Updater::Ignore[%obj.addon] = true;
		}
		else
			echo("Skipping" SPC %obj.addon);
		%obj.delete();
		if(updater.queue.getCount() < 1)
			updater.queue.onQueueEmpty();
		return true;
	}
	else if(%addon $= "")
	{
		echo("Please specify an add-on to skip. SYNTAX: skip(\"AddOn_Name\");");
	}
	else
	{
		echo(%addon SPC "is not in the update queue.");
	}
	return false;
}

function skipAll()
{
	cancel($Updater::dediContinueSched);
	updater.skipAll = true;
	updater.queue.onQueueEmpty();
}

function ignore(%addon)
{
	skip(%addon, true);
}

function updaterInterfaceDisplay()
{
	%width = 65;
	%div = repeatChar("-", %width);
	%col0 = 35;
	%col1 = 20;
	%col2 = 8;
	%head0 = "Add-On";
	%head1 = "New Version";
	%head2 = "Restart?";
	%numCols = 3;
	echo(" \nUPDATES AVAILABLE:\n");
	%line = "  ";
	for(%e = 0; %e < %numCols; %e ++)
		%line = %line @ %head[%e] @ repeatChar(" ", %col[%e] - strLen(%head[%e]));
	echo(%line);
	echo("  " @ %div);
	%count = updater.queue.getCount();
	for(%i = 0; %i < %count; %i ++)
	{
		%item = updater.queue.getObject(%i);
		%val0 = %item.addon;
		%val1 = %item.updateVersion;
		%val2 = (%item.updateRestartRequired ? "Yes" : "No");
		%line = "   ";
		for(%e = 0; %e < %numCols; %e ++)
			%line = %line @ %val[%e] @ repeatChar(" ", %col[%e] - strLen(%val[%e]));
		echo(%line);
	}
	echo("  " @ %div @ "\n");
	echo("  update(); - Perform all updates in the queue."
		NL "  ignore(\"AddOn_Name\"); - Skip and ignore all future updates."
		NL "  skip(\"AddOn_Name\"); - Skip an update once."
		NL "  skipAll(); - Skip all updates in the queue.\n");
	if($Updater::dediServerPaused)
	{
		echo("  If no action is taken, updates will be automatically skipped in 30 seconds.");
		cancel($Updater::dediContinueSched);
		$Updater::dediContinueSched = schedule(30000, 0, updaterDediContinue);
	}
}

function updaterInterfacePushItem(%item)
{
	cancel($Updater::displaySched);
	$Updater::displaySched = schedule(4000, 0, "updaterInterfaceDisplay");
}

function updaterInterfacePopItem(%item)
{

}

function updaterInterfaceSelectItem(%item)
{

}

function updaterInterfaceOnQueueEmpty()
{
	if(updater.skipAll)
		echo("All updates skipped.");
	else if(updater.restartRequired)
	{
		if(updater.hasErrors)
			warn("Updater completed with errors.");
		echo("Some updates require a restart. Type \"quit();\" to close Blockland now.");
	}
	else if(updater.hasErrors)
		warn("Updater completed with errors.");
	else
		echo("All updates have been completed.");

	if($Updater::dediServerPaused)
	{
		cancel($Updater::dediContinueSched);
		$Updater::dediContinueSched = schedule(3000, 0, updaterDediContinue);
	}
}

function repeatChar(%char, %count)
{
	for(%i = 0; %i < %count; %i ++)
		%string = %string @ %char;
	return %string;
}