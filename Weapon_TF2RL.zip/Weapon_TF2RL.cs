//TF2 Rocket Launcher - Script by Takato14/Moonwalker. Model by Moonwalker.

/////////
//Audio//
/////////

datablock AudioProfile(TF2RLFireSound)
{
	filename = "./TF2RL_fire.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(TF2RLLoop)
{
	filename = "./TF2RL_Loop.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(TF2RLExplodeSound)
{
	filename = "./TF2RLExplode.wav";
	description = AudioClose3d;
	preload = true;
};

datablock ParticleData(TF2RLExplosionFlashParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 40;
	lifetimeVarianceMS   = 10;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1 0.5 0.2 0.5";
	colors[1]     = "0.9 0.0 0.0 0.0";
	sizes[0]      = 6;
	sizes[1]      = 10;

	useInvAlpha = false;
};
datablock ParticleEmitterData(TF2RLExplosionFlashEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 0.0;
   ejectionOffset   = 3.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TF2RLExplosionFlashParticle";

   uiName = "TF2 Rocket Launcher Flash";
};

datablock ParticleData(TF2RLTrailParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.0;
	inheritedVelFactor   = 0.15;
	constantAcceleration = 0.0;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 805;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -150.0;
	spinRandomMax		= 150.0;
	colors[0]     = "1.0 1.0 0.0 0.4";
	colors[1]     = "1.0 0.2 0.0 0.5";
   colors[2]     = "0.20 0.20 0.20 0.3";
   colors[3]     = "0.0 0.0 0.0 0.0";

	sizes[0]      = 0.25;
	sizes[1]      = 0.85;
   sizes[2]      = 0.35;
 	sizes[3]      = 0.05;

   times[0] = 0.0;
   times[1] = 0.05;
   times[2] = 0.3;
   times[3] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(TF2RLTrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TF2RLTrailParticle";

   uiName = " TF2 Rocket Launcher Trail";
};

datablock ParticleData(TF2RLSmokeParticle)
{
	dragCoefficient      = 4;
	gravityCoefficient   = -1.0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 425;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.5 0.5 0.5 0.7";
	colors[1]     = "0.5 0.5 0.5 0.0";
	sizes[0]      = 0.05;
	sizes[1]      = 0.25;

	useInvAlpha = false;
};
datablock ParticleEmitterData(TF2RLSmokeEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TF2RLSmokeParticle";
};

datablock ParticleData(TF2RLExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 700;
	lifetimeVarianceMS   = 400;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.3 0.3 0.3 0.9";
	colors[1]     = "0.3 0.3 0.3 0";
	sizes[0]      = 5.25;
	sizes[1]      = 6.0;

	useInvAlpha = true;
};

datablock ParticleEmitterData(TF2RLExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TF2RLExplosionParticle";
};



datablock ExplosionData(TF2RLExplosion)
{
   //explosionShape = "";
   soundProfile = "TF2RLExplodeSound";

   lifeTimeMS = 300;

   particleEmitter = TF2RLExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0.9;

   emitter[0] = TF2RLExplosionFlashEmitter;

   faceViewer     = true;
   explosionScale = "5 5 5";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 1;
   lightEndRadius = 0;
   lightStartColor = "1 1 1";
   lightEndColor = "0 0 0";

   damageRadius = 10;
   radiusDamage = 35;

   impulseRadius = 6;
   impulseForce = 1300;

   uiName = " TF2 Rocket Launcher";

   };



AddDamageType("TF2RL",   '<bitmap:add-ons/Weapon_TF2RL/CI_TF2RL> %1',    '%2 <bitmap:add-ons/Weapon_TF2RL/CI_TF2RL> %1',0.5,1);
AddDamageType("TF2RLRadius",   '<bitmap:add-ons/Weapon_TF2RL/CI_TF2RL> %1',    '%2 <bitmap:add-ons/Weapon_TF2RL/CI_TF2RL> %1',0.5,1);
datablock ProjectileData(TF2RLProjectile)
{
   projectileShapeName = "./grenade.dts";
   directDamage        = 75;
   directDamageType    = $DamageType::TF2RL;
   radiusDamageType    = $DamageType::TF2RLRadius;

   brickExplosionRadius = 7;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 15;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 20;  //max volume of bricks that we can destroy if they aren't connected to the ground

   sound = TF2RLLoop;

   impactImpulse	     = 10;
   verticalImpulse	  = 4;
   explosion           = TF2RLExplosion;
   particleEmitter     = "TF2RLTrailEmitter";

   muzzleVelocity      = 80;
   velInheritFactor    = 1;

    armingDelay         = 00;
   lifetime            = 30000;
   fadeDelay           = 29500;
   bounceElasticity    = 0.9;
   bounceFriction      = 0.9;
   isBallistic         = true;
   gravityMod          = 0.12;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0.5 0 0";

   uiName = " TF2 Rocket Launcher";
};

//////////
// item //
//////////
datablock ItemData(TF2RLItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./TF2RL.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "TF2 Rocket Launcher";
	iconName = "./Icon_TF2RL";
	doColorShift = false;
	colorShiftColor = (180/255) SPC (180/255) SPC (180/255) SPC (255/255);

	 // Dynamic properties defined by the scripts
	image = TF2RLImage;
	canDrop = true;


};


////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(TF2RLImage)
{
   // Basic Item properties
   shapeFile = "./TF2RL.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.0 1.0 -0.85"
   rotation = ""; //eulerToMatrix( "0 0 0" )

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = TF2RLProjectile;
   projectileType = Projectile;

	casing = GunShellDebris; // If we did eject shells, this is where you would set the paramaters.
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   LarmReady = true;

   doColorShift = true;
   colorShiftColor = TF2RLItem.colorShiftColor;//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateSequence[0]		= "Rocket";
	stateTimeoutValue[0]            = 0.4;
	stateTransitionOnTimeout[0]     = "Ready";
	stateSound[0]					= weaponSwitchSound;
	
	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateSequence[1]				= "ready";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "Smoke";
	stateTimeoutValue[3]            = 1.0;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Fire";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]			= true;
	stateEmitter[3]					= gunFlashEmitter;
	stateEmitterTime[3]				= 0.15;
	stateEmitterNode[3]				= "muzzleNode";
	stateSound[3]					= TF2RLFireSound;
	//stateEjectShell[3]       		= false;

	stateName[4] 					= "Smoke";
	stateEmitter[4]					= TF2RLSmokeEmitter;
	stateEmitterTime[4]				= 0.14;
	stateEmitterNode[4]				= "muzzleNode";
	stateSequence[3]                = "Reload";
	stateTimeoutValue[4]            = 0.5;
	stateTransitionOnTimeout[4]     = "Ready";

	
};

function TF2RLImage::onFire(%this,%obj,%slot)
{
	if(%obj.getDamagePercent() < 1.0)
		%obj.playThread(2, plant);
	%projectile = %this.projectile;
	%spread = 0.0013;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 10 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

