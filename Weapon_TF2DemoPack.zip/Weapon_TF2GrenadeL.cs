datablock AudioProfile(tf2PipeFireSound)
{
   filename    = "./grenadel_fire.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(tf2PipeExplodeSound)
{
   filename    = "./grenadel_explode.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(tf2PipeFlashParticle)
{
	dragCoefficient      = 0;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 40;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

	colors[0]     = "0.9 0.9 0 0.3";
	colors[1]     = "1 0.5 0.2 0.5";
	colors[2]     = "1 0.5 0.2 0.0";

	sizes[0]      = 0.34;
	sizes[1]      = 0.20;
	sizes[2]      = 0.05;

	times[0] = 0.0;
	times[1] = 0.1;
	times[2] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(tf2PipeFlashEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 15.0;
   velocityVariance = 5.0;
   ejectionOffset   = 0.1;
   thetaMin         = -10;
   thetaMax         = 10;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "tf2PipeFlashParticle";

   //uiName = "";
};

datablock ParticleData(tf2PipeTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.5;
	constantAcceleration	= 0.0;
	lifetimeMS		= 800;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/ring";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "0 0.4 1 0.1";
	colors[1]	= "0 0.4 1 0.3";
	colors[2]	= "0 0.4 1 0.0";
	sizes[0]	= 0.5;
	sizes[1]	= 0.15;
	sizes[2]	= 0.05;
	times[0]	= 0.0;
	times[1]	= 0.05;
	times[2]	= 1.0;
};

datablock ParticleEmitterData(tf2PipeTrailEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;

   ejectionVelocity = 0; //0.25;
   velocityVariance = 0; //0.10;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = tf2PipeTrailParticle;

   useEmitterColors = true;
   uiName = "Pipebomb Trail";
};

datablock ExplosionData(tf2PipeExplosion)
{
   explosionShape = "";
   soundProfile = tf2PipeExplodeSound;

   lifeTimeMS = 100;

   particleEmitter = gravityRocketExplosionEmitter;
   particleDensity = 2;
   particleRadius = 0.1;

   emitter[0] = gravityRocketExplosionRingEmitter;
   //emitter[1] = gravityRocketExplosionChunkEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "3.0 10.0 3.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 5;
   lightEndRadius = 20;
   lightStartColor = "1 1 0 1";
   lightEndColor = "1 0 0 0";

   damageRadius = 5;
   radiusDamage = 75;

   impulseRadius = 5;
   impulseForce = 6000;

   playerBurnTime = 1000;
};

AddDamageType("TF2Pipe",   '<bitmap:add-ons/Weapon_Tf2DemoPack/ci_pipebomb> %1',    '%2 <bitmap:add-ons/Weapon_Tf2DemoPack/ci_pipebomb> %1',1,1);
datablock ProjectileData(tf2PipeProjectile)
{
   projectileShapeName = "./demobomb.1.dts";
   directDamage        = 20; //0 after bounce
   directDamageType = $DamageType::TF2Pipe;
   radiusDamage = 0;
   radiusDamageType = $DamageType::TF2Pipe;
   impactImpulse	   = 0;
   verticalImpulse	   = 0;
   explosion           = tf2PipeExplosion;
   particleEmitter = tf2PipeTrailEmitter;
   
   explodeOnDeath = true;

   brickExplosionRadius = 3;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = "";

   muzzleVelocity      = 45;
   velInheritFactor    = 0.0;

   armingDelay         = 2950;
   lifetime            = 3000;
   fadeDelay           = 4000;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.50;
   isBallistic         = true;
   gravityMod = 1.0;

   hasLight    = true;
   lightRadius = 1.0;
   lightColor  = "0 0.3 1.0";

   uiName = "TF2 Pipebomb";
};

function tf2PipeProjectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)
{
	%type = %col.getType();
	if(((%type & $TypeMasks::PlayerObjectType) || (%type & $TypeMasks::VehicleObjectType)) && minigameCanDamage(%obj,%col) && %obj.numBounces <= 0)
		%obj.explode();
	else
	{
		if(%obj.numBounces < 3)
			serverPlay3D(hammerHitSound,%obj.getTransform());
		%obj.numBounces++;
	}
	
	return Parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);
}

function tf2PipeProjectile::onExplode(%this,%obj,%pos,%a)
{
	%obj.setScale(vectorScale(%obj.getScale(),0.5));
	return Parent::onExplode(%this,%obj,%pos,%a);
}

function tf2PipeProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
	if(%obj.numBounces > 0)
		return;
	
	//Projectile is scaled for explosion size but damage should stay
	%this.directDamage *= 2;
	%val = Parent::damage(%this,%obj,%col,%fade,%pos,%normal);
	%this.directDamage /= 2;
	
	return %val;
}

function tf2PipeProjectile::radiusDamage(%this, %obj, %col, %distanceFactor, %pos, %damageAmt)
{
	%damageAmt *= 2;
	%val = Parent::radiusDamage(%this, %obj, %col, %distanceFactor, %pos, %damageAmt);
	%damageAmt /= 2;
	
	return %val;
}

datablock ItemData(tf2PipeItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./grenadel.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "TF2 Pipe L.";
	iconName = "./icon_pipebomb";
	doColorShift = true;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = tf2PipeImage;
	canDrop = true;
};

datablock ShapeBaseImageData(tf2PipeImage)
{
   // Basic Item properties
   shapeFile = "./grenadel.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 10" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = tf2PipeItem;
   ammo = " ";
   projectile = tf2PipeProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = "1 1 1 1";//"0.400 0.196 0 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "FireCheckA";
	stateAllowImageChange[1]         = true;

	stateName[2]                    = "Fire";
	stateEmitter[2]			= tf2PipeFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateTransitionOnTimeout[2]     = "Reload";
	stateTimeoutValue[2]            = 0.3;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		= true;
	stateSound[2]			= tf2PipeFireSound;

	stateName[3]			= "Reload";
	stateSequence[3]                = "roll";
	stateAllowImageChange[3]        = false;
	stateTimeoutValue[3]            = 0.2;
	stateWaitForTimeout[3]		= true;
	stateTransitionOnTimeout[3]     = "Check";

	stateName[4]			= "Check";
	stateTransitionOnTriggerUp[4]	= "StopFire";
	stateTransitionOnTriggerDown[4]	= "FireCheckA";

	stateName[5]                    = "StopFire";
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 0.2;
	stateAllowImageChange[5]        = false;
	stateWaitForTimeout[5]		= true;
	//stateSequence[5]                = "Reload";
	stateScript[5]                  = "onStopFire";
	
	stateName[6]			= "FireCheckA";
	stateTransitionOnTimeout[6]     = "FireCheckB";
	stateTimeoutValue[6]            = 0.01;
	stateScript[6]			= "onFireCheck";
	
	stateName[7]			= "FireCheckB";
	stateTransitionOnAmmo[7]	= "Fire";
	stateTransitionOnNoAmmo[7]	= "Ready";
};

function tf2PipeImage::onFire(%this,%obj,%slot)
{
	%obj.playThread(2,plant);
	
	%projectile = %this.projectile;
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	
	%p = new (%this.projectileType)()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
	};
	
	if(isObject(%p))
	{
		for(%i=0;%i<4;%i++)
		{
			if(!isObject(%obj.tf2Pipe[%i]))
			{
				%obj.tf2Pipe[%i] = %p;
				break;
			}
		}
		MissionCleanup.add(%p);
	}
	
	return %p;
}


function tf2PipeImage::onFireCheck(%this,%obj,%slot)
{
	for(%i=0;%i<4;%i++)
	{
		if(!isObject(%obj.tf2Pipe[%i]))
		{
			%obj.setImageAmmo(%slot,1);
			return;
		}
	}
	%obj.setImageAmmo(%slot,0);
}
