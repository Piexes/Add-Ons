datablock AudioProfile(TF2StickyBombChargeSound)
{
	filename = "./stickybomb_charge.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock ParticleData(TF2StickyDudExplosionParticle : arrowExplosionParticle)
{
	colors[0]     = "1 1 1 0.9";
	colors[1]     = "1 1 1 0.0";
};

datablock ParticleEmitterData(TF2StickyDudExplosionEmitter : arrowExplosionEmitter)
{
   particles = "TF2StickyDudExplosionParticle";
   uiName = "";
};

datablock ExplosionData(TF2StickyDudExplosion : arrowExplosion)
{
   emitter[0] = TF2StickyDudExplosionEmitter;
   
   // Dynamic light
   lightStartRadius = 1;
   lightEndRadius = 0;
   lightStartColor = "1 1 1";
   lightEndColor = "0 0 0";
};

AddDamageType("StickyBomb",   '<bitmap:add-ons/Weapon_TF2DemoPack/CI_StickyBomb> %1',    '%2 <bitmap:add-ons/Weapon_TF2DemoPack/CI_StickyBomb> %1',0.5,1);
datablock ProjectileData(TF2StickyBombProjectile)
{
   projectileShapeName = "./stickyBombProjectile.dts";

   directDamage        = 0;
   directDamageType    = $DamageType::StickyBomb;

   radiusDamage        = 0;
   damageRadius        = 0;
   radiusDamageType    = $DamageType::StickyBomb;

   explosion             = TF2StickyDudExplosion;
   stickExplosion        = arrowStickExplosion;
   bloodExplosion        = arrowStickExplosion;
   particleEmitter       = arrowTrailEmitter;
   explodeOnPlayerImpact = false;
   explodeOnDeath        = true;  

   armingDelay         = 30000;
   lifetime            = 30000;
   fadeDelay           = 29500;

   isBallistic         = true;
   bounceAngle         = 0; //stick almost all the time
   minStickVelocity    = 0;
   bounceElasticity    = 0.3;
   bounceFriction      = 0.70;   
   gravityMod = 1;

   hasLight    = false;

   muzzleVelocity      = 65;
   velInheritFactor    = 1;

   uiName = "";
};

datablock ExplosionData(tf2StickyBombExplosion : rocketExplosion)
{
   damageRadius = 9;
   radiusDamage = 150;

   impulseRadius = 7;
   impulseForce = 10000;
   
   lightStartRadius = 3;
   lightEndRadius = 10;
   lightStartColor = "1 1 1 1";
   lightEndColor = "0 0 0 0";

};

datablock ProjectileData(tf2StickyBombExplodeProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 0;
   directDamageType = $DamageType::StickyBomb;
   radiusDamageType = $DamageType::StickyBomb;
   impactImpulse       = 0;
   verticalImpulse     = 0;
   explosion           = tf2StickyBombExplosion;
   particleEmitter     = "";
   
   explodeOnDeath = 1;

   brickExplosionRadius = 3;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 30;             
   brickExplosionMaxVolume = 30;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 60;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = "";

   muzzleVelocity      = 1;
   velInheritFactor    = 1.0;

   armingDelay         = 0;
   lifetime            = 10;
   fadeDelay           = 9;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = true;
   lightRadius = 5.0;
   lightColor  = "0.4 0.4 0.9";

   uiName = "Sticky Bomb Explosion";
};

datablock StaticShapeData(TF2StickyBombStatic)
{
	shapeFile = "./stickyBombProjectile.dts";
};

datablock itemData(TF2StickyBombItem)
{
	category = "weapon";
	className = "weapon";
	
	shapeFile = "./stickyLauncher.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	
	uiName = "Stickybomb L.";
	iconName = "./Icon_TF2StickyBomb";
	
	doColorShift = true;
	colorShiftColor = "0.5 0.5 0.5 1.000";
	
	image = TF2StickyBombImage;
	canDrop = true;
};

datablock shapeBaseImageData(TF2StickyBombImage)
{
	className = "weaponImage";
	
	shapeFile = "./stickyLauncher.dts";
	emap = true;
	
	offset = "0 0 0";
	rotation = eulerToMatrix("0 0.01 359.9");
	
	eyeOffset = "0 0 0";
	
	item = TF2StickyBombItem;
	
	doColorShift = true;
	colorShiftColor = "0.5 0.5 0.5 1.000";
	
	projectile = TF2StickyBombProjectile;
	projectileType = projectile;
	
	armReady = true;
	
	// Initial start up state
	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.3;
	stateTransitionOnTimeout[0]	= "Ready";
	stateSequence[0]		= "ready";
	stateSound[0]			= weaponSwitchSound;
	
	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "PreFire";
	stateAllowImageChange[1]	= true;
	
	stateName[2]			= "PreFire";
	stateScript[2]			= "onPreFire";
	stateTimeoutValue[2]		= 0.1;
	stateTransitionOnTimeout[2]	= "Charge";	
	
	stateName[3]                    = "Charge";
	stateTransitionOnTimeout[3]	= "Charge";
	stateTransitionOnAmmo[3]	= "Fire";
	stateTransitionOnTriggerUp[3]	= "Fire";
	stateTimeoutValue[3]            = 0.1;
	stateSequence[3]		= "Charge";
	stateScript[3]			= "onCharge";
	stateWaitForTimeout[3]		= false;
	stateAllowImageChange[3]        = false;
	
	stateName[4]			= "Fire";
	stateTransitionOnTimeout[4]	= "Ready";
	stateTimeoutValue[4]		= 0.5;
	stateFire[4]			= true;
	stateSequence[4]		= "Fire";
	stateScript[4]			= "onFire";
	stateWaitForTimeout[4]		= true;
	stateAllowImageChange[4]	= false;
	stateSound[4]			= BowFireSound;
};

function TF2StickyBombImage::onUnMount(%this,%obj,%slot)
{
	Parent::onUnMount(%this,%obj,%slot);
	%obj.stopAudio(2);
}

function TF2StickyBombImage::onPreFire(%this,%obj,%slot)
{
	%obj.stickyChargeTime = getSimTime();
	%obj.stickyPlaySound = 0;
	%obj.setImageAmmo(%slot,0);
}

function TF2StickyBombImage::onCharge(%this,%obj,%slot)
{
	%time = getSimTime() - %obj.stickyChargeTime;
	
	if(%time >= 200 && !%obj.stickyPlaySound)
	{
		%obj.stickyPlaySound = 1;
		%obj.playAudio(2,TF2StickyBombChargeSound);
	}
	
	if(%time >= 4200)
		%obj.setImageAmmo(%slot,1);
	
	if(%time >= 200 && isObject(%obj.client))
	{
		%a = ((%time - 500) > 4000 ? 4000 : (%time - 500));
		%b = 4000;
		%start = "\c0";
		%sep = "\c3";
		
		%done = (%a >= %b) || (%a == 0);
		%end = (%a / %b) * 15;
		%str = (%a == 0 ? %sep : %start);
		
		for(%i=0;%i<15;%i++)
		{
			if(%i > %end && !%done)
			{
				%str = %str @ %sep;
				%done = 1;
			}
			%str = %str @ "|";
		}
		
		%obj.client.centerPrint("<br><br><br>" @ %str,0.5);
	}
}

function TF2StickyBombImage::onFire(%this,%obj,%slot)
{
	%obj.playAudio(2,BowFireSound);
	
	%time = getSimTime() - %obj.stickyChargeTime - 200;
	if(%time >= 4000)
		%speed = 35;
	else
		%speed = 15 + 20 * %time / 4000;
	
	if(!isObject(%obj.stickyBombSet))
		%obj.stickyBombSet = new SimSet();
	
	while(%obj.stickyBombSet.getCount() >= 8)
	{
		%oldtime = getSimTime();
		%oldest = 0;
		for(%i=0;%i<%obj.stickyBombSet.getCount();%i++)
		{
			%o = %obj.stickyBombSet.getObject(%i);
			if(%o.fireTime < %oldtime)
			{
				%oldtime = %o.fireTime;
				%oldest = %i;
			}
		}
		%o = %obj.stickyBombSet.getObject(%oldest);
		%o.doBombExplode();
		%obj.stickyBombSet.remove(%o);
	}
	
	%projectile = %this.projectile;
	
	%vector = %obj.getMuzzleVector(%slot);
	%objectVelocity = %obj.getVelocity();
	%vector1 = VectorScale(%vector, %speed);
	%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
	%velocity = VectorAdd(%vector1,%vector2);
	
	%p = new Projectile()
	{
		dataBlock = %projectile;
		initialVelocity = %velocity;
		initialPosition = %obj.getMuzzlePoint(%slot);
		sourceObject = %obj;
		sourceSlot = %slot;
		client = %obj.client;
		fireTime = getSimTime();
	};
	MissionCleanup.add(%p);
	%obj.stickyBombSet.add(%p);
	%p.set = %obj.stickyBombSet;
	
	%obj.toolAmmo[%obj.currTool]--;
}

package StickyBombSet
{
   function Projectile::onAdd(%obj,%a,%b)
   {
      Parent::onAdd(%obj,%a,%b);
      if(%obj.dataBlock.getID() == TF2StickyBombProjectile.getID() && isObject(%obj.client.player))
         %obj.client.player.stickyBombSet.add(%obj);
   }
};activatePackage(StickyBombSet);

function TF2StickyBombProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
	Parent::onCollision(%this,%obj,%col,%fade,%pos,%normal);
	
	%obj.schedule(33,spawnStickyBomb,%col,%fade,%pos,%normal);
}

function Projectile::spawnStickyBomb(%obj,%col,%fade,%pos,%normal)
{
	%type = %col.getType();
	if((!(%type & $TypeMasks::fxBrickObjectType) && !(%type & $Typemasks::StaticObjectType) && !(%type & $TypeMasks::TerrainObjectType)))
		return;
	
	if(%col.getType() & $TypeMasks::StaticShapeObjectType && %col.getDatablock() == TF2StickyBombStatic.getID())
		return;
	
	%player = %obj.client.player;
	if(!isObject(%player))
		return;
	
	if(!isObject(%player.stickyBombSet))
		%player.stickyBombSet = new SimSet();
	
	%pos = vectorAdd(%pos,vectorScale(%normal,0.15));
	%rot = rotFromTransform(%obj.getTransform());
	%scaleFactor = getWord(%obj.getScale(),2);
	
	%s = new StaticShape()
	{
		dataBlock = TF2StickyBombStatic;
		position = %pos;
		rotation = %rot;
		normal = %normal;
		
		client = %obj.client;
		sourceObject = %obj.sourceObject;
		fireTime = %obj.fireTime;
	};
	MissionCleanup.add(%s);
	%s.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
	%player.stickyBombSet.add(%s);
	%s.set = %obj.stickyBombSet;
	
	if(isObject(%player.client))
	{
		if(isObject(%player.client.minigame) && %player.client.tdmTeam != -1 && %player.client.tdmTeam !$= "")
			%col = getColorIDTable(%player.client.minigame.teamCol[%player.client.tdmTeam]);
		else
			%col = %player.client.chestColor;
	}
	else
		%col = "1 1 1 1";
	%s.setNodeColor("ALL",%col);
	
	%obj.schedule(33,delete);
}

function StaticShape::doBombExplode(%obj)
{
	if(getSimTime() - %obj.fireTime < 400)
		return;
	
	if(!isObject(%obj.client))
	{
		%obj.doBombDudExplode();
		return;
	}
	
	%scaleFactor = getWord(%obj.getScale(),2) / 2;
	%p = new Projectile()
	{
		dataBlock = TF2StickyBombExplodeProjectile;
		initialVelocity = %obj.normal;
		initialPosition = %obj.getPosition();
		sourceObject = %obj.sourceObject;
		sourceSlot = 0;
		client = %obj.client;
	};
	%p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
	
	%obj.schedule(33,delete);
	if(isObject(%obj.set))
		%obj.set.remove(%obj);
}

function Projectile::doBombExplode(%obj)
{
	StaticShape::doBombExplode(%obj);
}

function StaticShape::doBombDudExplode(%obj)
{
	%scaleFactor = getWord(%obj.getScale(),2);
	%p = new Projectile()
	{
		dataBlock = TF2StickyBombProjectile;
		initialVelocity = "0 0 1";
		initialPosition = %obj.getPosition();
		sourceObject = 0;
		sourceSlot = 0;
		client = 0;
	};
	%p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
	%p.schedule(100,explode);
	
	%obj.schedule(33,delete);
}

function Projectile::doBombDudExplode(%obj)
{
	StaticShape::doBombDudExplode(%obj);
}

package StickyBombL
{
	function armor::onTrigger(%this,%obj,%slot,%val)
	{
		if(%slot == 4)
		{
			if(%val)
			{
				%obj.stickyBombTriggerTime = getSimTime();
			}
			else if(getSimTime() - %obj.stickyBombTriggerTime < 500)
			{
				if(!isObject(%obj.stickyBombSet) || %obj.stickyBombSet.getCount() <= 0)
					return Parent::onTrigger(%this,%obj,%slot,%val);
				
				%obj.playThread(2,leftRecoil);
				%obj.explodeBombs();
				return;				
			}
		}
		return Parent::onTrigger(%this,%obj,%slot,%val);
	}
	
	function Player::explodeBombs(%obj)
	{
		if(%obj.getState() $= "Dead" || !isObject(%obj.stickyBombSet) || %obj.stickyBombSet.getCount() <= 0)
			return;
		
		for(%i=0;%i<%obj.stickyBombSet.getCount();%i++)
		{
			%obj.stickyBombSet.getObject(%i).doBombExplode();
			
			if(%obj.getState() $= "Dead")
				return;
		}
	}
	
	function Armor::onDisabled(%this,%obj)
	{
		if(isObject(%obj.stickyBombSet))
		{
			for(%i=0;%i<%obj.stickyBombSet.getCount();%i++)
				%obj.stickyBombSet.getObject(%i).doBombDudExplode();
			
			%obj.stickyBombSet.delete();
		}
		
		Parent::onDisabled(%this,%obj);
	}
	
	function Armor::onRemove(%this,%obj)
	{
		if(isObject(%obj.stickyBombSet))
		{
			for(%i=0;%i<%obj.stickyBombSet.getCount();%i++)
				%obj.stickyBombSet.getObject(%i).doBombDudExplode();
			
			%obj.stickyBombSet.delete();
		}
		
		Parent::onRemove(%this,%obj);
	}
};activatePackage(StickyBombL);
