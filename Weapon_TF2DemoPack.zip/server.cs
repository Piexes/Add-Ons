%error = forceRequiredAddOn("Weapon_Rocket_Launcher");
%error2 = forceRequiredAddOn("Weapon_Bow");
%error3 = forceRequiredAddOn("Weapon_Spear");
%error4 = forceRequiredAddOn("Sound_Blockland");
%error5 = forceRequiredAddOn("Sound_Synth4");
%error6 = forceRequiredAddOn("Projectile_GravityRocket");
%error7 = forceRequiredAddOn("Emote_Critical");

if(%error == $Error::AddOn_Disabled)
{
   rocketLauncherItem.uiName = "";
}

if(%error2 == $Error::AddOn_Disabled)
{
   bowItem.uiName = "";
}

if(%error3 == $Error::AddOn_Disabled)
{
   spearItem.uiName = "";
}

if(%error4 == $Error::AddOn_NotFound)
{
   datablock AudioProfile(Block_Leave_Sound)
   {
      filename = "base/data/sound/playerLeave.wav";
      description = AudioClosest3d;
      preload = false;
   };
}

if(%error6 == $Error::AddOn_Disabled)
{
   gravityRocketProjectile.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_TF2DemoPack - required add-on Weapon_Rocket_Launcher not found");
}
else if(%error2 == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_TF2DemoPack - required add-on Weapon_Bow not found");
}
else if(%error3 == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_TF2DemoPack - required add-on Weapon_Spear not found");
}
else if(%error5 == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_TF2DemoPack - required add-on Sound_Synth4 not found");
}
else if(%error6 == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_TF2DemoPack - required add-on Projectile_GravityRocket not found");
}
else if(%error76 == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_TF2DemoPack - required add-on Emote_Critical not found");
}
else
{
   exec("./Support_AmmoGuns.cs");
   exec("./Support_AltDatablock.cs");
   exec("./Support_RaycastingWeapons.cs");
   exec("./Weapon_TF2Stickybomb.cs");
   exec("./Weapon_TF2GrenadeL.cs");
   exec("./Weapon_TF2Eyelander.cs");
}
