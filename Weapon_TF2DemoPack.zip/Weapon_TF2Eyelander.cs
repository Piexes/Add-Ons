datablock PlayerData(PlayerTF2DemoWeak : PlayerStandardArmor)
{
	runForce = 44 * 90;
	runEnergyDrain = 0;
	minRunEnergy = 0;
	
	maxForwardSpeed = 6;
	maxBackwardSpeed = 3;
	maxSideSpeed = 5;
	
	maxForwardCrouchSpeed = 2;
	maxBackwardCrouchSpeed = 1;
	maxSideCrouchSpeed = 1;
	
	jumpForce = 9 * 90;
	jumpEnergyDrain = 0;
	minJumpEnergy = 0;
	jumpDelay = 3;
	
	rechargeRate = 0.3;
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	
	showEnergyBar = 1;
	
	uiName = "TF2 Demo Weak";
	
	maxDamage = 120;
};

datablock PlayerData(PlayerTF2DemoCharge : PlayerStandardArmor)
{
	runForce = 22 * 90;
	runEnergyDrain = 1.2;
	minRunEnergy = 3;
	
	maxForwardSpeed = 30;
	maxBackwardSpeed = 1;
	maxSideSpeed = 0;
	
	maxForwardCrouchSpeed = 10;
	maxBackwardCrouchSpeed = 1;
	maxSideCrouchSpeed = 1;
	
	jumpForce = 6 * 90;
	jumpEnergyDrain = 0;
	minJumpEnergy = 0;
	jumpDelay = 3;
	
	rechargeRate = 0;
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
	
	minImpactSpeed = 6;
	uiName = "";
	
	maxDamage = 1000; //health adjusted by datablocks script
};

datablock PlayerData(PlayerTF2DemoBoost1 : PlayerTF2DemoWeak)
{
	maxForwardSpeed = 6 + 1.5;
	maxBackwardSpeed = 3 + 1.5;
	maxSideSpeed = 5 + 1.5;
	
	maxForwardCrouchSpeed = 2 + 1;
	maxBackwardCrouchSpeed = 1 + 1;
	maxSideCrouchSpeed = 1 + 1;
	
	maxDamage = 120 + 15;
	
	uiName = "";
};

datablock PlayerData(PlayerTF2DemoBoost2 : PlayerTF2DemoWeak)
{
	maxForwardSpeed = 6 + 3;
	maxBackwardSpeed = 3 + 3;
	maxSideSpeed = 5 + 3;
	
	maxForwardCrouchSpeed = 2 + 2.0;
	maxBackwardCrouchSpeed = 1 + 2.0;
	maxSideCrouchSpeed = 1 + 2.0;
	
	maxDamage = 120 + 30;
	
	uiName = "";
};

datablock PlayerData(PlayerTF2DemoBoost3 : PlayerTF2DemoWeak)
{
	maxForwardSpeed = 6 + 4.5;
	maxBackwardSpeed = 3 + 4.5;
	maxSideSpeed = 5 + 4.5;
	
	maxForwardCrouchSpeed = 2 + 3.0;
	maxBackwardCrouchSpeed = 1 + 3.0;
	maxSideCrouchSpeed = 1 + 3.0;
	
	maxDamage = 120 + 45;
	
	uiName = "";
};

datablock PlayerData(PlayerTF2DemoBoost4 : PlayerTF2DemoWeak)
{
	maxForwardSpeed = 6 + 6;
	maxBackwardSpeed = 3 + 6;
	maxSideSpeed = 5 + 6;
	
	maxForwardCrouchSpeed = 2 + 4.0;
	maxBackwardCrouchSpeed = 1 + 4.0;
	maxSideCrouchSpeed = 1 + 4.0;
	
	maxDamage = 120 + 60;
	
	uiName = "";
};


datablock AudioProfile(tf2SwordHitSound)
{
   filename    = "./tf2swordhit.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(tf2SwordSwingSound)
{
   filename    = "./tf2swordswing.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock ParticleData(tf2SwordExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   spinRandomMin = -90;
   spinRandomMax = 90;
   lifetimeMS           = 250;
   lifetimeVarianceMS   = 150;
   textureName          = "base/data/particles/chunk";
   colors[0]     = "1.0 0.0 0.0 0.9";
   colors[1]     = "0.9 0.9 0.9 0.0";
   sizes[0]      = 0.5;
   sizes[1]      = 0.25;
};

datablock ParticleEmitterData(tf2SwordExplosionEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 16;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "tf2SwordExplosionParticle";
   
   uiName = "Eyelander Hit";
};

datablock ExplosionData(tf2SwordExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 300;

   soundProfile = tf2SwordHitSound;

   particleEmitter = tf2SwordExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 4;
   lightStartColor = "1.0 0.0 0.0";
   lightEndColor = "0.0 0 0";
};

datablock ParticleData(tf2SwordCritParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 200;
	lifetimeVarianceMS   = 0;
	textureName          = "Add-Ons/Projectile_Radio_Wave/bolt";
	spinSpeed		= 0.0;
	spinRandomMin		= -0.0;
	spinRandomMax		= 0.0;
	
	times[0] = 0;
	times[1] = 0.5;
	times[2] = 1.0;
	
	colors[0]     = "0.9 0 0 1";
	colors[1]     = "0.9 0 0 1";
	colors[2]     = "0.9 0 0 0";
	
	sizes[0]      = 0.5;
	sizes[1]      = 0.25;
	sizes[2]      = 0.0;
};

datablock ParticleEmitterData(tf2SwordCritEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 20;
   velocityVariance = 5.0;
   ejectionOffset   = 0;
   thetaMin         = 265;
   thetaMax         = 275;
   phiReferenceVel  = 00;
   phiVariance      = 5;
   overrideAdvance = false;
   particles = "tf2SwordCritParticle";

   useEmitterColors = false;

   uiName = "";
};

AddDamageType("Eyelander",   '<bitmap:add-ons/Weapon_Sword/ci_sword> %1',    '%2 <bitmap:add-ons/Weapon_Sword/ci_sword> %1',0.75,1);
datablock ProjectileData(tf2SwordProjectile)
{
   directDamage        = 35;
   directDamageType  = $DamageType::Eyelander;
   radiusDamageType  = $DamageType::Eyelander;
   explosion           = tf2SwordExplosion;
   //particleEmitter     = as;

   muzzleVelocity      = 50;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 130;
   fadeDelay           = 70;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   //uiName = "";
};

function tf2SwordProjectile::damage(%this,%obj,%col,%fade,%pos,%normal)
{
   if(%this.directDamage <= 0)
      return;

   %damageType = $DamageType::Direct;
   if(%this.DirectDamageType)
      %damageType = %this.DirectDamageType;

   %scale = getWord(%obj.getScale(), 2);
   %directDamage = mClampF(%this.directDamage, -100, 100) * %scale;

   if(%col.getType() & $TypeMasks::PlayerObjectType)
   {
      %oldclient = %col.client;
      if(%obj.fireCrit)
      {
         %directDamage *= 3;
         if(isObject(%col.client))
            %col.client.play2d(critRecieveSound);
         if(isObject(%obj.client))
            %obj.client.play2d(critHitSound);
         %col.emote(CritProjectile);
      }
      %col.damage(%obj, %pos, %directDamage, %damageType);
      if(%col.getState() $= "Dead")
      {
         if(fileName(%col.dataBlock.shapeFile) $= "m.dts")
         {
            %col.spawnExplosion(VehicleExplosionProjectile,getWord(%col.getScale(),2)*0.5);
            %col.hideNode("headSkin");
            for(%i=0;$hat[%i] !$= "";%i++){%col.hideNode($hat[%i]);}
            for(%i=0;$accent[%i] !$= "";%i++){%col.hideNode($accent[%i]);}
            
            %bot = new AIPlayer()
            {
               dataBlock = %col.dataBlock;
            };MissionCleanup.add(%bot);
            
            if(%obj.fireCrit)
               %v = 10;
            else
               %v = 4;
            %bot.setTransform(%col.getTransform());
            %bot.setVelocity(vectorAdd(%col.getVelocity(),vectorAdd(vectorScale(vectorNormalize(%obj.getVelocity()),%v*2),"0 0" SPC %v)));
            %bot.schedule(5000,removeBody);
            if(isObject(%oldclient))
            {
               %p = %oldclient.player;
               %oldclient.player = %bot;
               %oldclient.applyBodyParts();
               %oldclient.applyBodyColors();
               %oldclient.player = %p;
            }
            for(%i=0;$chest[%i] !$= "";%i++){%bot.hideNode($chest[%i]);}
            for(%i=0;$larm[%i] !$= "";%i++){%bot.hideNode($larm[%i]);}
            for(%i=0;$rarm[%i] !$= "";%i++){%bot.hideNode($rarm[%i]);}
            for(%i=0;$lhand[%i] !$= "";%i++){%bot.hideNode($lhand[%i]);}
            for(%i=0;$rhand[%i] !$= "";%i++){%bot.hideNode($rhand[%i]);}
            for(%i=0;$lleg[%i] !$= "";%i++){%bot.hideNode($lleg[%i]);}
            for(%i=0;$rleg[%i] !$= "";%i++){%bot.hideNode($rleg[%i]);}
            for(%i=0;$lshoe[%i] !$= "";%i++){%bot.hideNode($lshoe[%i]);}
            for(%i=0;$rshoe[%i] !$= "";%i++){%bot.hideNode($rshoe[%i]);}
            for(%i=0;$hip[%i] !$= "";%i++){%bot.hideNode($hip[%i]);}
            for(%i=0;$pack[%i] !$= "";%i++){%bot.hideNode($pack[%i]);}
            for(%i=0;$secondpack[%i] !$= "";%i++){%bot.hideNode($secondpack[%i]);}
            %bot.hideNode("skirtTrimLeft");
            %bot.hideNode("skirtTrimRight");
            %bot.hideNode("lski");
            %bot.hideNode("rski");
            %bot.unHideNode("headSkin");
            %bot.kill();
         }
         
         %source = %obj.sourceObject;
         if(isObject(%source) && (%source.getType() & $TypeMasks::PlayerObjectType) && %source.getFirstDatablock().getID() == PlayerTF2DemoWeak.getID())
         {
            %source.tf2SwordHeads++;
            //%source.playSound
            %num = (%source.tf2SwordHeads < 4 ? %source.tf2SwordHeads : 4);
            %source.popDatablock(PlayerTF2DemoBoost1);
            %source.popDatablock(PlayerTF2DemoBoost2);
            %source.popDatablock(PlayerTF2DemoBoost3);
            %source.popDatablock(PlayerTF2DemoBoost4);
            %source.pushDatablock(("PlayerTF2DemoBoost" @ %num).getID());
            %source.addHealth(15);
         }
      }
   }
   else
   {
      %col.damage(%obj, %pos, %directDamage, %damageType);
   }	
}

datablock ItemData(tf2SwordItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Eyelander.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "The Eyelander";
	iconName = "./icon_eyelander";
	doColorShift = true;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = tf2SwordImage;
	canDrop = true;
};

datablock ShapeBaseImageData(tf2SwordImage)
{
   // Basic Item properties
   shapeFile = "./Eyelander.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = ".2 -.5 0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   eyeOffset = "0 0 0";

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = tf2SwordItem;
   ammo = " ";
   projectile = tf2SwordProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "1 1 1 1.000";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.5;
	stateTransitionOnTimeout[0]      = "Ready";
	stateSound[0]                    = SwordDrawSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;
	stateTransitionOnAmmo[1]	= "CritReady";

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.3;
	stateTransitionOnTimeout[2]     = "Fire";
	stateTransitionOnAmmo[2]	= "CritPreFire";

	stateName[3]                    = "Fire";
	stateTransitionOnTimeout[3]     = "CheckFire";
	stateSound[3]			= tf2SwordSwingSound;
	stateTimeoutValue[3]            = 0.6;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSequence[3]                = "Slash";
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]		= true;

	stateName[4]			= "CheckFire";
	stateTransitionOnTriggerUp[4]	= "StopFire";
	stateTransitionOnTriggerDown[4]	= "PreFire";

	
	stateName[5]                    = "StopFire";
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 0.2;
	stateAllowImageChange[5]        = false;
	stateWaitForTimeout[5]		= true;
	stateSequence[5]                = "StopFire";
	stateScript[5]                  = "onStopFire";
	
	stateName[6]                     = "CritReady";
	stateTransitionOnTriggerDown[6]  = "CritPreFire";
	stateAllowImageChange[6]         = true;
	stateTimeoutValue[6]             = 0.5;
	stateWaitForTimeout[6]           = false;
        stateTransitionOnTimeout[6]      = "Ready";
	stateEmitter[6]			= tf2SwordCritEmitter;
	stateEmitterNode[6]		= "muzzleNode";
	stateEmitterTime[6]		= 1;
	
	stateName[7]			= "CritPreFire";
	stateScript[7]                  = "onCritPreFire";
	stateAllowImageChange[7]        = false;
	stateTimeoutValue[7]            = 0.3;
	stateTransitionOnTimeout[7]     = "CritFire";
	stateEmitter[7]			= tf2SwordCritEmitter;
	stateEmitterNode[7]		= "muzzleNode";
	stateEmitterTime[7]		= 1;
	
	stateName[8]                    = "CritFire";
	stateTransitionOnTimeout[8]     = "CheckFire";
	stateSound[8]			= tf2SwordSwingSound;
	stateTimeoutValue[8]            = 0.6;
	stateFire[8]                    = true;
	stateAllowImageChange[8]        = false;
	stateSequence[8]                = "Slash";
	stateScript[8]                  = "onCritFire";
	stateWaitForTimeout[8]		= true;
	stateEmitter[8]			= tf2SwordCritEmitter;
	stateEmitterNode[8]		= "muzzleNode";
	stateEmitterTime[8]		= 1;
};

function tf2SwordImage::onMount(%this, %obj, %slot)
{	
	%obj.hidenode("RHand");
        %obj.hidenode("LHand");
	%obj.hidenode("RHook");
        %obj.hidenode("LHook");
	%obj.setImageAmmo(%slot,0);
}


function tf2SwordImage::onUnMount(%this, %obj, %slot)
{	
	%obj.tf2SwordUnmount = 1;
	if(isObject(%obj.client))
	{
		%obj.client.applyBodyParts();
		%obj.client.applyBodyColors();
	}
	else
	{
		%obj.unhidenode("RHand");
        	%obj.unhidenode("LHand");
	}
	%obj.tf2SwordUnmount = "";
}

function tf2SwordImage::onCritPreFire(%this, %obj, %slot)
{	
	%obj.playThread(2,activate);
	%obj.playAudio(2,critFireSound);
}

function tf2SwordImage::onCritFire(%this, %obj, %slot)
{	
	%p = Parent::onFire(%this,%obj,%slot);
	%p.firecrit = 1;
	%obj.setImageAmmo(%slot,0);
	%obj.setImageTrigger(0,0);
}

function PlayerTF2DemoCharge::onImpact(%this, %obj, %col, %pos, %vel)
{
	if(%vel > 7.5)
	{
		if(miniGameCanDamage(%obj, %col) == 1 && %col.getType() & ($TypeMasks::PlayerObjectType | $TypeMasks::VehicleObjectType))
		{
			%damage = %vel*2/3;
			%col.damage(%obj, %start, %damage, $DamageType::Vehicle);
			%col.addVelocity(vectorAdd(vectorScale(%obj.getForwardVector(),%vel/3),"0 0" SPC %vel/4));
			%obj.setEnergyLevel(%obj.getEnergyLevel() - %vel);
			
			%obj.popDatablock(PlayerTF2DemoCharge);
			%obj.setEnergyLevel(0);
			%obj.stopAudio(2);
			if(isObject(skiImpactAProjectile))
				%obj.spawnExplosion(skiImpactAProjectile,getWord(%obj.getScale(),2));
			
			if(isObject(%obj.tf2SwordConn))
			{
				%obj.unMountImage(3);
				if(isObject(%obj.client))
					%obj.client.resetControlObject();
				%obj.tf2SwordConn.schedule(0,delete);
			}
			
			if(%vel > 26 && %obj.getMountedImage(0) == tf2SwordImage.getID())
			{
				%obj.setImageAmmo(0,1);
				%obj.setImageTrigger(0,1);
			}
		}
	}
	%vel = mAbs(getWord(%obj.getVelocity(),2));
	return Parent::onImpact(%this, %obj, %col, %pos, %vel);
}

function PlayerTF2DemoCharge::onCollision(%this, %obj, %col, %pos, %vel)
{
	return Parent::onCollision(%this, %obj, %col, %pos, %vel);
}

package EyelanderCharge
{
	function armor::onTrigger(%this,%player,%slot,%val)
	{
		if(!%val)
			return Parent::onTrigger(%this, %player, %slot, %val);
		
		if(%slot != 4)
			return Parent::onTrigger(%this, %player, %slot, %val);
		
		if(%player.getMountedImage(0) !$= tf2SwordImage.getID())
			return Parent::onTrigger(%this, %player, %slot, %val);
		
		if(%player.isCrouched())
			return Parent::onTrigger(%this, %player, %slot, %val);
		
		%energy = %player.getEnergyLevel();
		if(%energy < 99)
			return Parent::onTrigger(%this, %player, %slot, %val);	
		
		%start = %player.getPosition();
		%end = vectorSub(%start, "0 0 1");
		%masks = ($TypeMasks::FxBrickObjectType | $TypeMasks::PlayerObjectType | $TypeMasks::StaticObjectType | $TypeMasks::TerrainObjectType | $TypeMasks::VehicleObjectType);
		
		%ground = containerRayCast(%start, %end, %masks, %obj);
		if(!isObject(%ground))
			return Parent::onTrigger(%this, %player, %slot, %val);
		
		%player.pushDatablock(PlayerTF2DemoCharge);
		if(isObject(%player.client))
		{		
			if(isObject(%player.client.camera))
			{
				%transform = %player.getTransform();
				%player.client.camera.setOrbitMode(%player, %transform, 0.5, 8, 8, 1);
				%player.client.camera.mode = "Orbit";
				%player.client.setControlObject(%player.client.camera);
			}
			else
				return;
		}
		
		%conn = new AIConnection()
		{
			bl_id = 1337;
			connected = 1;
			hasSpawnedOnce = 0;
			isTF2SwordChargeAI = 1;
		};
		MissionCleanup.add(%conn);
		%conn.tf2SwordCheck = %conn.schedule(500,tf2SwordStopCheck,%player);
		%conn.setControlObject(%player);
		%conn.setMove("y",1);
		%player.tf2SwordConn = %conn;
		if(isObject(whistleLoopSound))
			%player.playAudio(2,whistleLoopSound);
	}
	
	function AIConnection::onDrop(%client, %reason)
	{
		if(%client.isTF2SwordChargeAI)
		{
			%client.onClientLeaveGame();
			removeFromServerGuidList( %client.guid );
			removeTaggedString(%client.name);
			return;
		}
		return Parent::onDrop(%client, %reason);
	}
	
	function messageClient(%client, %msgType, %msgString, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8, %a9, %a10, %a11, %a12, %a13)
	{
		if(isObject(%client) && %client.getClassName() $= "AIConnection")
			return;
		
		return Parent::messageClient(%client, %msgType, %msgString, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8, %a9, %a10, %a11, %a12, %a13);
	}
	
	function AIConnection::tf2SwordStopCheck(%this,%obj)
	{
		if(!isObject(%obj))
		{
			%this.delete();
			return;
		}
		
		if(!isObject(%obj) || %this.getControlObject() != %obj || %obj.getState() $= "Dead")
		{
			%obj.stopAudio(2);
			%this.delete();
			return;
		}
		
		%vel = vectorLen(%obj.getVelocity());
		if(%vel <= 1)
		{
			%obj.playThread(3,undo);
			%obj.popDatablock(PlayerTF2DemoCharge);
			%this.schedule(500,delete);
			%obj.setEnergyLevel(0);
			%obj.stopAudio(2);
			if(isObject(%obj.client))
				%obj.client.schedule(500,resetControlObject);
			if(isObject(skiImpactAProjectile))
				%obj.spawnExplosion(skiImpactAProjectile,getWord(%obj.getScale(),2));
			
			%this.setMove("y",0);
			return;
		}
		else if(%vel > 26)
		{
			%obj.unMountImage(3);
			%obj.schedule(10,mountImage,playerTeleportImage,3);
		}
		
		%this.chargingCheck = %this.schedule(500,tf2SwordStopCheck,%obj);
	}
	
	function GameConnection::resetControlObject(%this)
	{
		if(isObject(%this.player))
			%this.setControlObject(%this.player);
	}
	
	function Observer::onTrigger(%this,%obj,%trigger,%state)
	{
		if(!isObject(%obj.getControllingClient()))
			return Parent::onTrigger(%this,%obj,%trigger,%state);
		%client = %obj.getControllingClient();
		
		if(!isObject(%client.player.tf2SwordConn))
			return Parent::onTrigger(%this,%obj,%trigger,%state);
		
		switch(%trigger)
		{
			case 0:
				if(%state)
				{
					%player = %client.player;
					%player.popDatablock(PlayerTF2DemoCharge);
					%player.tf2SwordConn.schedule(0,delete);
					%player.setEnergyLevel(0);
					%player.stopAudio(2);
					%player.unMountImage(3);
					%client.resetControlObject();
					if(vectorLen(%player.getVelocity()) > 26 && %player.getMountedImage(0) == tf2SwordImage.getID())
						%player.setImageAmmo(0,1);
				}
		}
		
		return Parent::onTrigger(%this,%obj,%trigger,%state);
	}
	
	function ShapeBase::unHideNode(%this,%node)
	{
		if(%this.getMountedImage(0) == tf2SwordImage.getID() && !%this.tf2SwordUnmount && (strStr(strLwr(%node),"hand") != -1 || strStr(strLwr(%node),"hook") != -1))
			return;
		
		Parent::unHideNode(%this,%node);
	}
	
	function ProjectileData::radiusDamage(%this, %obj, %col, %distanceFactor, %pos, %damageAmt)
	{
		if(%col.getType() & $TypeMasks::PlayerObjectType)
		{
			for(%i=0;%i<%col.dataBlock.maxTools;%i++)
			{
				if(isObject(%col.tool[%i]) && %col.tool[%i].getID() == tf2SwordItem.getID())
				{
					%damageAmt /= 2;
					break;
				}
			}
		}
		Parent::radiusDamage(%this, %obj, %col, %distanceFactor, %pos, %damageAmt);
	}
};activatePackage(EyelanderCharge);
