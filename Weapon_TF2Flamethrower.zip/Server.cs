//Decals
datablock DecalData(TF2flamerCI)
{
   textureName = "./CI_flamerkill";
};   

datablock DecalData(TF2flamerIcon)
{
   textureName = "./icon_flamer";
};   

datablock ParticleData(flamerParticle)
{
	dragCoefficient      = 2.9;
	gravityCoefficient   = 0.1;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 75;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.000000 0.000000 1.000000 1.000000";
	colors[1]     = "1.000000 0.496063 0.000000 0.000000";
   	colors[2]     = "1.000000 1.000000 1.000000 1.000000";
   	colors[3]     = "1.000000 1.000000 1.000000 1.000000";

	sizes[0]      = 0.0946103;
	sizes[1]      = 0.897272;
 	sizes[2]      = 1;
 	sizes[3]      = 1;

   	times[0] = 0;
   	times[1] = 1;
   	times[2] = 2;
  	times[3] = 2;

	useInvAlpha = false;
};

datablock ParticleEmitterData(flamerEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 20;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 5;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientOnVelocity = true;
   particles = "flamerParticle";
};

datablock ParticleData(flamerairParticle)
{
	dragCoefficient      = 2.9;
	gravityCoefficient   = 0.1;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 500;
	lifetimeVarianceMS   = 75;
	textureName          = "base/data/particles/chunk";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.800000 0.800000 0.800000 1.000000";
	colors[1]     = "0.680000 0.726063 0.700000 0.000000";
   	colors[2]     = "1.00000 1.000000 1.000000 1.000000";
   	colors[3]     = "1.000000 1.000000 1.000000 1.000000";

	sizes[0]      = 0.0946103;
	sizes[1]      = 0.897272;
 	sizes[2]      = 1;
 	sizes[3]      = 1;

   	times[0] = 0;
   	times[1] = 1;
   	times[2] = 2;
  	times[3] = 2;

	useInvAlpha = false;
};

datablock ParticleEmitterData(flamerairEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 00;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 5;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientOnVelocity = true;
   particles = "flamerairParticle";
};

datablock ParticleData(flamerGasParticle)
{
	dragCoefficient      = 0.0;
	gravityCoefficient   = -1;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 75;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.000000 0.000000 1.000000 0.500000";
	colors[1]     = "0.000000 0.496063 1.000000 0.000000";

	sizes[0]      = 0.04;
	sizes[1]      = 0.01;

   	times[0] = 0;
   	times[1] = 1;

	useInvAlpha = false;
};

datablock ParticleEmitterData(flamerGasEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 5;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientOnVelocity = true;
   particles = "flamerGasParticle";
};


datablock ParticleData(flamerExplosionParticle)
{
	dragCoefficient      = 2;
	gravityCoefficient   = 0.0;
	windCoefficient	   = 1;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.0;
	lifetimeMS           = 600;
	lifetimeVarianceMS   = 200;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 100.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "1.000000 0.496063 0.000000 0.496063";
	colors[1]     = "1.000000 0.496063 0.000000 0.000000";
	colors[2]     = "1.000000 1.000000 1.000000 1.000000";
	colors[3]     = "1.000000 1.000000 1.000000 1.000000";
	sizes[0]      = 0.799609;
	sizes[1]      = 1.19636;
	sizes[2]      = 1;
	sizes[3]      = 1;
	times[0]	  = 0;
	times[1]	  = 1;
	times[2]	  = 2;
	times[3]	  = 2;

	useInvAlpha = false;
};
datablock ParticleEmitterData(flamerExplosionEmitter)
{
   ejectionPeriodMS = 40;
   periodVarianceMS = 0;
   ejectionVelocity = 3.5;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 35;
   thetaMax         = 85;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientOnVelocity = true;
   particles = "flamerExplosionParticle";
};

datablock ExplosionData(flamerExplosion)
{
   lifeTimeMS = 128;

   particleEmitter = flamerExplosionEmitter;
   particleDensity = 10;
   particleRadius = 1;
   explosionScale = "1 1 1";
   
   damageRadius = 1;
   radiusDamage = 1;
   
   playerBurnTime = 8000;
   

};


AddDamageType("flamerDirect",   '<bitmap:add-ons/weapon_TF2flamethrower/CI_flamerkill> %1',    '%2 <bitmap:add-ons/weapon_TF2flamethrower/CI_flamerkill> %1',1,1);
datablock ProjectileData(flamerProjectile)
{
   directDamage        = 12;
   directDamageType = $DamageType::flamerDirect;
   explosion           = flamerExplosion;

   muzzleVelocity      = 25;
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 300;
   fadeDelay           = 0;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0;
};

datablock ProjectileData(flamerAirProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 0;
   directDamageType = $DamageType::flamerDirect;

   muzzleVelocity      = 10;
   velInheritFactor    = 1;
   
   sound = sprayFireSound;
   particleEmitter     = flamerairEmitter;
   
   impactImpulse	     = 2000;
   verticalImpulse	   = 1000;

   armingDelay         = 0;
   lifetime            = 300;
   fadeDelay           = 0;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;
};


//////////
// item //
//////////
datablock ItemData(flamerItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./flamer.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "TF2 Flamethrower";
	iconName = "./icon_flamer";
	doColorShift = true;
	colorShiftColor = "1 1 1 1.000";

	 // Dynamic properties defined by the scripts
	image = FlamerImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(FlamerImage)
{
   // Basic Item properties
   shapeFile = "./Flamer.dts";
   emap = true;

   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0;
   rotation = "1 0 0 0";
   correctMuzzleVector = true;
   className = "WeaponImage";

   // Projectile && Ammo.
   item = flamerItem;
   ammo = " ";
   projectile = flamerProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doRetraction = false;

   doColorShift = true;
   colorShiftColor = "0.15 0.15 0.15 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTransitionOnTriggerDown[0]  = "Fire";
	stateAllowImageChange[0]	   = true;
	stateSound[0]			   = sprayActivateSound;
	stateTransitionOnTimeout[0]	   = "Ready";
	stateTimeoutValue[0]		   = 0.01;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Fire";
	stateTimeoutValue[1]		   = 0.04;
	stateTransitionOnTimeout[1]	   = "Ready";
	stateWaitForTimeout[1]		   = true;
	stateAllowImageChange[1]	   = true;
	stateEmitter[1]			   = flamerGasEmitter;
	stateEmitterTime[1]		   = 0.07;

	stateName[2]                     = "Fire";
	stateTransitionOnTriggerUp[2]	   = "StopFire";
	stateTransitionOnTimeout[2]	   = "Fire";
	stateTimeoutValue[2]		   = 0.04;
	stateWaitForTimeout[2]		   = true;
	stateFire[2]			   = true;
	stateAllowImageChange[2]	   = true;
	stateSound[2]			   = sprayFireSound;
	stateScript[2]			   = "onFire";
	stateEmitter[2]       = flamerEmitter;
	stateEmitterTime[2]		   = 0.07;
	stateSequence[2]			   = "fire";

	stateName[3] 			   = "StopFire";
	stateTransitionOnTimeout[3]	   = "Ready";
	stateWaitForTimeout[3]		   = true;
	stateAllowImageChange[3]	   = true;
	stateSequence[3]			   = "stopfire";
};

package flameraltFire
{

	function Armor::onTrigger(%this, %player, %slot, %val)
	{
		if(%player.getMountedImage(0) $= FlamerImage.getID() && %slot $= 4 && %val)
		{
			%projectile = flamerAirProjectile;
			%vector = %player.getMuzzleVector(0);
			%objectVelocity = %player.getVelocity();
			%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
			%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
			%velocity = VectorAdd(%vector1,%vector2);
			%p = new Projectile()
			{
				dataBlock = %projectile;
				initialVelocity = %velocity;
				initialPosition = %player.getMuzzlePoint(0);
				sourceObject = %player;
				sourceSlot = 0;
				client = %player.client;
			};
			MissionCleanup.add(%p);
			return %p;
		}     
		Parent::onTrigger(%this, %player, %slot, %val);
	}
	
};
activatePackage(flameraltFire);
