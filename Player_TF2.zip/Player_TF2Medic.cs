datablock PlayerData(PlayerTF2Medic : PlayerStandardArmor)
{
		firstPersonOnly = $PlayerTF2::FirstPersonOnly;

		runForce = 51 * 90;
		runEnergyDrain = 0;
		minRunEnergy = 0;

		maxForwardSpeed = 7;
		maxBackwardSpeed = 4;
		maxSideSpeed = 6;

		maxForwardCrouchSpeed = 3;
		maxBackwardCrouchSpeed = 2;
		maxSideCrouchSpeed = 2;

		jumpForce = 9 * 90;
		jumpEnergyDrain = 0;
		minJumpEnergy = 0;
		jumpDelay = 3;

		minJetEnergy = 0;
		jetEnergyDrain = 0;
		canJet = 0;

		uiName = "TF2 Medic";
		showEnergyBar = true;

		maxDamage = 125;
};

//Script by Space Guy (130)
function PlayerTF2Medic::onAdd(%this,%obj)
{
	Parent::onAdd(%this,%obj);
	%obj.setRepairRate(1/32);
}

function PlayerTF2Medic::onDamage(%this,%obj,%delta)
{
	Parent::onDamage(%this,%obj,%delta);
	if(%delta > 0)
	{
		if(isEventPending(%obj.medicRepairSched1))
			cancel(%obj.medicRepairSched1);
		
		if(isEventPending(%obj.medicRepairSched2))
			cancel(%obj.medicRepairSched2);
		
		%obj.setRepairRate(1/32);
		
		if(%obj.getState() !$= "Dead")
		{
			%obj.medicRepairSched1 = %obj.schedule(5000,setRepairRate,2/32);
			%obj.medicRepairSched2 = %obj.schedule(10000,setRepairRate,3/32);
		}
	}
}