datablock PlayerData(PlayerTF2Pyro : PlayerStandardArmor)
{
		firstPersonOnly = $PlayerTF2::FirstPersonOnly;

		runForce = 48 * 90;
		runEnergyDrain = 0;
		minRunEnergy = 0;

		maxForwardSpeed = 7;
		maxBackwardSpeed = 4;
		maxSideSpeed = 6;

		maxForwardCrouchSpeed = 3;
		maxBackwardCrouchSpeed = 2;
		maxSideCrouchSpeed = 2;

		jumpForce = 8 * 90;
		jumpEnergyDrain = 0;
		minJumpEnergy = 0;
		jumpDelay = 3;

		minJetEnergy = 0;
		jetEnergyDrain = 0;
		canJet = 0;

		uiName = "TF2 Pyro";
		showEnergyBar = true;

		maxDamage = 200;
};