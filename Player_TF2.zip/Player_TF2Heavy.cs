datablock PlayerData(PlayerTF2Heavy : PlayerStandardArmor)
{
		firstPersonOnly = $PlayerTF2::FirstPersonOnly;

		runForce = 37 * 90;
		runEnergyDrain = 0;
		minRunEnergy = 0;

		maxForwardSpeed = 5;
		maxBackwardSpeed = 3;
		maxSideSpeed = 5;

		maxForwardCrouchSpeed = 2;
		maxBackwardCrouchSpeed = 1;
		maxSideCrouchSpeed = 1;

		jumpForce = 7 * 90;
		jumpEnergyDrain = 0;
		minJumpEnergy = 0;
		jumpDelay = 3;

		minJetEnergy = 0;
		jetEnergyDrain = 0;
		canJet = 0;

		uiName = "TF2 Heavy";
		showEnergyBar = true;

		maxDamage = 275;
};