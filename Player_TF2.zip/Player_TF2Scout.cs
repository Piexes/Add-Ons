datablock PlayerData(PlayerTF2Scout : PlayerStandardArmor)
{
		firstPersonOnly = $PlayerTF2::FirstPersonOnly;

		runForce = 64 * 90;
		runEnergyDrain = 0;
		minRunEnergy = 0;

		maxForwardSpeed = 14;
		maxBackwardSpeed = 8;
		maxSideSpeed = 12;

		maxForwardCrouchSpeed = 4;
		maxBackwardCrouchSpeed = 3;
		maxSideCrouchSpeed = 3;

		jumpForce = 11 * 90;
		jumpEnergyDrain = 0;
		minJumpEnergy = 0;
		jumpDelay = 3;

		minJetEnergy = 0;
		jetEnergyDrain = 0;
		canJet = 0;

		uiName = "TF2 Scout";
		showEnergyBar = true;

		maxDamage = 100;
};