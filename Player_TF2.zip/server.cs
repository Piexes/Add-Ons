RTB_registerPref("Force 1st person", "Team Fortress 2 Player Types", "$PlayerTF2::FirstPersonOnly", "bool", "Player_TF2", false, true, false, "");

exec("./Player_TF2Demoman.cs");
exec("./Player_TF2Engineer.cs");
exec("./Player_TF2Heavy.cs");
exec("./Player_TF2Medic.cs");
exec("./Player_TF2Pyro.cs");
exec("./Player_TF2Scout.cs");
exec("./Player_TF2Sniper.cs");
exec("./Player_TF2Soldier.cs");
exec("./Player_TF2Spy.cs");