datablock PlayerData(PlayerBatJumpArmor : PlayerStandardArmor)
{
   maxDamage = 1000;
   runForce = PlayerStandardArmor.runForce * 8;
   minRunEnergy = 0;
   maxForwardSpeed = 15;
   maxBackwardSpeed = 15;
   maxSideSpeed = 15;

   maxForwardCrouchSpeed = 7;
   maxBackwardCrouchSpeed = 7;
   maxSideCrouchSpeed = 7;
   airControl = PlayerStandardArmor.airControl * 8;
   
   minJetEnergy = 0;
   jumpForce = 5 * 90;
   jetEnergyDrain = 0;
   canJet = 0;
   
   uiName = "";
   showEnergyBar = false;
};

datablock PlayerData(PlayerDoubleJumpArmor : PlayerStandardArmor)
{
		runForce = 100 * 90;
		runEnergyDrain = 0;
		minRunEnergy = 0;

		maxForwardSpeed = 15;
		maxBackwardSpeed = 13;
		maxSideSpeed = 13;

		maxForwardCrouchSpeed = 4;
		maxBackwardCrouchSpeed = 3;
		maxSideCrouchSpeed = 3;

		jumpForce = 9 * 90;
		jumpEnergyDrain = 0;
		minJumpEnergy = 0;
		jumpDelay = 3;

		minJetEnergy = 0;
		jetEnergyDrain = 0;
		canJet = 0;

		uiName = "Double-Jump Player";
		maxDamage = 100;
		canDoubleJump = 1;
};

datablock PlayerData(PlayerDoubleJumpWeakArmor : PlayerDoubleJumpArmor)
{
		uiName = "Double-Jump Weak";
		maxDamage = 75;
};

datablock ShapeBaseImageData(DoubleJumpCheckImage)
{
	shapeFile = "base/data/shapes/empty.dts";
	emap = false;

	mountPoint = $HeadSlot;

	stateName[0]				= "Ready";
	stateTransitionOnTimeout[0]		= "FireA";
	stateTimeoutValue[0]			= 0.01;

	stateName[1]				= "FireA";
	stateScript[1]				= "onCheck";
	stateTransitionOnTimeout[1]		= "FireA";
	stateWaitForTimeout[1]			= True;
	stateTimeoutValue[1]			= 0.02;
};

function DoubleJumpCheckImage::onCheck(%this,%obj,%slot)
{
	%pos = %obj.getPosition();
	%targets = $TypeMasks::FxBrickAlwaysObjectType | $TypeMasks::PlayerObjectType | $TypeMasks::StaticObjectType | $TypeMasks::TerrainObjectType | $TypeMasks::VehicleObjectType;
	%ray = ContainerRayCast(%pos, vectorAdd(%pos,"0 0 -0.3"), %targets, %obj);
	%col = getWord(%ray,0);
        
	if(!isObject(%col))
		return;
	if(%col.getType() & $TypeMasks::FxBrickAlwaysObjectType && !%col.isColliding())
		return;
	
	%obj.unMountImage(%slot);
}

package DoubleJumpingBat
{
   function Armor::onTrigger(%this,%obj,%slot,%on)
   {
      %r = Parent::onTrigger(%this,%obj,%slot,%on);
      if(%slot == 2 && %on)
      {
         %bat = 0;
         for(%i=0;%i<%this.maxTools;%i++)
         {
            if(%obj.tool[%i] == TF2BatItem.getID())
            {
               %bat = 1;
               break;
            }
         }
         
         if(!%this.canDoubleJump && !(%bat && $TF2Scout::BatJumpOn))
            return %r;
         
         if(%obj.getMountedImage(2) == DoubleJumpCheckImage.getID())
            return %r;
         
         %pos = %obj.getPosition();
         %targets = $TypeMasks::FxBrickAlwaysObjectType | $TypeMasks::PlayerObjectType | $TypeMasks::StaticObjectType | $TypeMasks::TerrainObjectType | $TypeMasks::VehicleObjectType;
         %ray = ContainerRayCast(%pos, vectorAdd(%pos,"0 0 -0.3"), %targets, %obj);
         %col = getWord(%ray,0);
         
         if(isObject(%col) && (!(%col.getType() & $TypeMasks::FxBrickAlwaysObjectType) || %col.isColliding()))
            return %r;
         
         %obj.mountImage(DoubleJumpCheckImage,2);
         %obj.setVelocity("0 0 0");
         %obj.applyImpulse("0 0 0","0 0" SPC %obj.dataBlock.jumpForce);
         %obj.playThread(3,jump);
         
         %scaleFactor = getWord(%obj.getScale(), 2);
         %data = pushBroomProjectile;
         %p = new Projectile()
         {
            dataBlock = %data;
            initialPosition = %pos;
            initialVelocity = "0 0 -1";
            sourceObject = %obj;
            client = %obj.client;
            sourceSlot = 0;
            originPoint = %pos;
         };
         %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
         %p.explode();
         
         //Only change if you're a 'standard' player type and not already using a different datablock
         if(fileName(%obj.dataBlock.shapeFile) $= "m.dts" && %obj.dataBlock.getID() != PlayerBatJumpArmor.getID() && %obj.getState() !$= "Dead" && %obj.altDataNum <= 1)
         {
            %health = %obj.dataBlock.maxDamage - %obj.getDamageLevel();
            %flash = %obj.getDamageFlash();
            %obj.pushDatablock(PlayerBatJumpArmor.getID());
            %obj.resetTF2Data = %obj.schedule(200,popDatablock,PlayerBatJumpArmor.getID());
         }
      }
      return %r;
   }
};activatePackage(DoubleJumpingBat);
