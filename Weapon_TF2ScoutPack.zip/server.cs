%error = ForceRequiredAddOn("Weapon_Gun");
%error2 = ForceRequiredAddOn("Weapon_Push_Broom");
%error3 = ForceRequiredAddOn("Weapon_Spear"); //Sandman taunt

if(%error == $Error::AddOn_Disabled)
{
   GunItem.uiName = "";
}

if(%error2 == $Error::AddOn_Disabled)
{
   pushBroomItem.uiName = "";
}

if(%error3 == $Error::AddOn_Disabled)
{
   spearItem.uiName = "";
}

if(%error == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_TF2ScoutPack - required add-on Weapon_Gun not found");
}
else if(%error2 == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_TF2ScoutPack - required add-on Weapon_Push_Broom not found");
}
else if(%error3 == $Error::AddOn_NotFound)
{
   error("ERROR: Weapon_TF2ScoutPack - required add-on Weapon_Spear not found");
}
else
{
   exec("./Support_AltDatablock.cs");
   exec("./Support_RaycastingWeapons.cs");
   exec("./Support_AmmoGuns.cs");
   exec("./Support_TF2BasicMelee.cs");
   exec("./Weapon_TF2Bat.cs");
   exec("./Weapon_TF2Sandman.cs");
   exec("./Weapon_TF2ForceANature.cs");
   exec("./Player_DoubleJump.cs");
}

if(isFile("Add-Ons/System_ReturnToBlockland/server.cs"))
{
	if(!$RTB::RTBR_ServerControl_Hook)
	{
		exec("Add-Ons/System_ReturnToBlockland/RTBR_ServerControl_Hook.cs");
	}
	
	// Description, ModName, Variable, Properties, Mod, Default value, Requires Restart, Super-Admin Only
	RTB_registerPref("Bat Enables Double Jump", "TF2 Scout Pack", "$TF2Scout::BatJumpOn", "bool", "Weapon_TF2ScoutPack", 1, 0, 0);
}
else
{
	$TF2Scout::BatJumpOn = 1;
}
