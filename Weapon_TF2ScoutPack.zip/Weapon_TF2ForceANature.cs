datablock AudioProfile(TF2ForceShotSound)
{
   filename    = "./scatterDoubleFire.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(TF2ForceOpenSound : TF2ForceShotSound)
{
   filename    = "./scatterDoubleOpen.wav";
};

datablock AudioProfile(TF2ForceCloseSound : TF2ForceShotSound)
{
   filename    = "./scatterDoubleClose.wav";
};

datablock AudioProfile(TF2ForceAmmoOutSound : TF2ForceShotSound)
{
   filename    = "./scatterDoubleAmmoOut.wav";
};

datablock AudioProfile(TF2ForceAmmoInSound : TF2ForceShotSound)
{
   filename    = "./scatterDoubleAmmoIn.wav";
};

AddDamageType("TF2Force",   '<bitmap:Add-Ons/Weapon_TF2ScoutPack/ci_fan> %1',    '%2 <bitmap:Add-Ons/Weapon_TF2ScoutPack/ci_fan> %1',0.75,1);
datablock ProjectileData(TF2ForceTrailProjectile)
{
   projectileShapeName = "add-ons/Weapon_Gun/bullet.dts";
   directDamage        = 0;
   directDamageType    = $DamageType::TF2Force;
   radiusDamageType    = $DamageType::TF2Force;

   explosion           = "";
   particleEmitter     = "";
   explodeOnDeath = false;

   brickExplosionRadius = 0;
   brickExplosionImpact = 0;             //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   collideWithPlayers = true;

   muzzleVelocity      = 200;
   velInheritFactor    = 1.0;

   armingDelay         = 0;
   lifetime            = 800;
   fadeDelay           = 750;
   bounceElasticity    = 0;
   bounceFriction      = 0.00;
   isBallistic         = true;
   gravityMod          = 0.0;

   hasLight    = false;
   lightRadius = 1.0;
   lightColor  = "1 1 0";
   
   uiName = "TF2 Force-A-Nature Trail";
};

datablock DebrisData(TF2ForceShellDebris)
{
	shapeFile = "./FANShell.dts";
	lifetime = 3.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.6;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};

//////////
// item //
//////////
datablock ItemData(TF2ForceItem)
{
   category = "Weapon";  // Mission editor category
   className = "Weapon"; // For inventory system
   
   // Basic Item Properties
   shapeFile = "./ForceANature.dts";
   rotate = false;
   mass = 1;
   density = 0.2;
   elasticity = 0.2;
   friction = 0.6;
   emap = true;
   
   //gui stuff
   uiName = "The Force-A-Nature";
   iconName = "./Icon_TF2Force";
   doColorShift = true;
   colorShiftColor = "1 1 1 1";
   
    // Dynamic properties defined by the scripts
   image = TF2ForceImage;
   canDrop = true;
      
   //Ammo Guns Parameters
   maxAmmo = 2;
   canReload = 1;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(TF2ForceImage)
{
   // Basic Item properties
   shapeFile = "./ForceANature.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0.2 0.1";
   eyeOffset = "0 0 0";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile and Ammo (ammo guns stored by item)
   item = TF2ForceItem;
   ammo = " ";
   projectile = TF2ForceTrailProjectile;
   projectileType = Projectile;

   casing = TF2ForceShellDebris;
   shellExitDir        = "1.0 0.1 1.0";
   shellExitOffset     = "0 0 0";
   shellExitVariance   = 10.0;
   shellVelocity       = 5.0;
   
   raycastWeaponRange = 1000;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastWeaponPierceTargets = "";				//Gun cannot pierce
   raycastExplosionProjectile = gunprojectile;
   raycastExplosionSound = ""; //sound played by exploding gunprojectile
   raycastDirectDamage = 4.5;
   raycastDirectDamageType = $DamageType::TF2Force;
   raycastSpreadCount = 12;
   raycastSpreadAmt = 0.0035;
   raycastTracerProjectile = TF2ForceTrailProjectile;
   raycastImpactImpulse = 150;
   raycastVerticalImpulse = 140;
   
   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;
   minShotTime = 100;

   doColorShift = true;
   colorShiftColor = TF2ForceItem.colorShiftColor;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateSequence[0]                = "Ready";
	stateTimeoutValue[0]            = 0.2;
	stateWaitForTimeout[0]		= true;
	stateTransitionOnTimeout[0]	= "LoadCheckA";
	stateSound[0]			= weaponSwitchSound;
	
	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Fire";
	stateAllowImageChange[1]        = true;
	stateTimeoutValue[1]		= 0.01;
	stateTransitionOnNoAmmo[1]	= "Reload";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.2;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]		= true;
	stateEmitter[2]			= gunFlashEmitter;
	stateEmitterTime[2]		= 0.05;
	stateEmitterNode[2]		= "muzzleNode";
	stateSound[2]			= TF2ForceShotSound;

	stateName[3] 			= "Smoke";
	stateEmitter[3]			= gunSmokeEmitter;
	stateEmitterTime[3]		= 0.1;
	stateEmitterNode[3]		= "muzzleNode";
	stateTimeoutValue[3]		= 0.1;
	stateWaitForTimeout[3]		= true;
	stateTransitionOnTimeout[3]	= "LoadCheckA";
	
	//Torque switches states instantly if there is an ammo/noammo state, regardless of stateWaitForTimeout
	stateName[4]			= "LoadCheckA";
	stateScript[4]			= "onLoadCheck";
	stateTimeoutValue[4]		= 0.01;
	stateTransitionOnTimeout[4]	= "LoadCheckB";
	
	stateName[5]			= "LoadCheckB";
	stateTransitionOnAmmo[5]	= "Ready";
	stateTransitionOnNoAmmo[5]	= "Reload";

	stateName[6]			= "Reload";
	stateTimeoutValue[6]		= 0.3;
	stateSequence[6]		= "open";
	stateTransitionOnTimeout[6]	= "ReloadWait";
	stateWaitForTimeout[6]		= true;
	stateSound[6]			= TF2ForceOpenSound;
	
	stateName[7]			= "shell";
	stateTimeoutValue[7]		= 0.1;
	stateEjectShell[7]       	= true;
	stateSequence[7]		= "ShellsOut";
	stateTransitionOnTimeout[7]	= "shell2";
	stateWaitForTimeout[7]		= true;
	stateSound[7]			= TF2ForceAmmoOutSound;
	
	stateName[8]			= "shell2";
	stateTimeoutValue[8]		= 0.4;
	stateEjectShell[8]		= true;
	stateTransitionOnTimeout[8]	= "ShellsIn";
	
	stateName[9]			= "ShellsIn";
	stateSequence[9]		= "ShellsIn";
	stateTimeoutValue[9]		= 0.3;
	stateTransitionOnTimeout[9]	= "Close";
	stateWaitForTimeout[9]		= true;
	stateSound[9]			= TF2ForceAmmoInSound;
	
	stateName[10]			= "Close";
	stateSequence[10]		= "Close";
	stateTimeoutValue[10]		= 0.3;
	stateTransitionOnTimeout[10]	= "Wait";
	stateWaitForTimeout[10]		= true;
	stateSound[10]			= TF2ForceCloseSound;
	
	stateName[11]			= "Wait";
	stateTimeoutValue[11]		= 0.2;
	stateScript[11]			= "onReloaded";
	stateTransitionOnTimeout[11]	= "Ready";
	
	stateName[12]			= "ReloadWait";
	stateTimeoutValue[12]		= 0.3;
	stateTransitionOnTimeout[12]	= "shell";
	stateWaitForTimeout[612]	= true;
};

function TF2ForceImage::onFire(%this,%obj,%slot)
{
         %fvec = %obj.getForwardVector();
         %fX = getWord(%fvec,0);
         %fY = getWord(%fvec,1);
         
         %evec = %obj.getEyeVector();
         %eX = getWord(%evec,0);
         %eY = getWord(%evec,1);
         %eZ = getWord(%evec,2);
         
         %eXY = mSqrt(%eX*%eX+%eY*%eY);
         
         %aimVec = %fX*%eXY SPC %fY*%eXY SPC %eZ;
         
         %vel = %obj.getVelocity();
         %zspd = getWord(%vel,2);
         if(%eZ < -0.5 && %zspd < 0)
            %vel = getWord(%vel,0) SPC getWord(%vel,1) SPC (%zspd + 5 >= 0 ? 0 : %zspd + 5);
         
         %obj.setVelocity(vectorAdd(%vel,%fX*%eXY*-6 SPC %fY*%eXY*-6 SPC %eZ*-5));

         Parent::onFire(%this,%obj,%slot);
         %obj.toolAmmo[%obj.currTool]--;
         
         %obj.playThread(2,plant);
}

function TF2Forceimage::onReloaded(%this,%obj,%slot)
{
	%obj.toolAmmo[%obj.currTool] = %this.item.maxAmmo;
	%obj.setImageAmmo(%slot,1);
}
