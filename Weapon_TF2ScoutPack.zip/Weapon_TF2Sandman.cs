AddDamageType("TF2WoodBat",   '<bitmap:Add-Ons/Weapon_TF2ScoutPack/ci_woodbat> %1',    '%2 <bitmap:Add-Ons/Weapon_TF2ScoutPack/ci_woodbat> %1',0.75,1);
AddDamageType("TF2BatTaunt",   '<bitmap:Add-Ons/Weapon_TF2ScoutPack/ci_woodbat> <bitmap:base/client/ui/ci/splat> %1',    '%2 <bitmap:Add-Ons/Weapon_TF2ScoutPack/ci_woodbat> <bitmap:base/client/ui/ci/splat> %1',1,1);
AddDamageType("TF2StunBall",   '<bitmap:Add-Ons/Weapon_TF2ScoutPack/ci_stunball> %1',    '%2 <bitmap:Add-Ons/Weapon_TF2ScoutPack/ci_stunball> %1',0.75,1);

datablock AudioProfile(batWoodHitSound)
{
   filename    = "./batWoodHit.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(batWoodBallSwingSound)
{
   filename    = "./batWoodBallSwing.wav";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(batWoodBallStunSound)
{
   filename    = "./batWoodBallStun.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(batWoodBallStun2dSound)
{
   filename    = "./batWoodBallStun.wav";
   description = Audio2d;
   preload = true;
};

datablock ParticleData(StunRingParticle)
{
   dragCoefficient      = 8;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 100;
   lifetimeVarianceMS   = 0;
   textureName          = "base/data/particles/star1";
   spinSpeed      = 500.0;
   spinRandomMin      = -500.0;
   spinRandomMax      = 500.0;
   colors[0]     = "1 1 0.0 0.9";
   colors[1]     = "0.9 0.0 0.0 0.0";
   sizes[0]      = 0.2;
   sizes[1]      = 0;

   useInvAlpha = false;
};

datablock ParticleEmitterData(StunEmitter)
{
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.5;
   thetaMin         = 90;
   thetaMax         = 90.1;
   phiVariance      = 0;
   overrideAdvance = false;
   particles = "StunRingParticle";

   ejectionPeriodMS = 3;
   phiReferenceVel  = 60480;
   
   uiName = "Emote - Stun";
};

datablock ShapeBaseImageData(StunImage)
{
   shapeFile = "base/data/shapes/empty.dts";
   emap = false;

   mountPoint = $HeadSlot;
   rotation = "1 0 0 -90";
   offset = "0 0 0.5";

   stateName[0]               = "Ready";
   stateTransitionOnTimeout[0]      = "FireA";
   stateTimeoutValue[0]         = 0.01;

   stateName[1]               = "FireA";
   stateTransitionOnTimeout[1]      = "FireA";
   stateWaitForTimeout[1]         = True;
   stateTimeoutValue[1]         = 10000;
   stateEmitter[1]               = StunEmitter;
   stateEmitterTime[1]            = 10000;
};

//trail
datablock ParticleData(stunballTrailParticle)
 {
   dragCoefficient      = 3;
   gravityCoefficient   = -0.0;
   inheritedVelFactor   = 0.15;
   constantAcceleration = 0.0;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 0;
   textureName          = "base/data/particles/dot";
   spinSpeed         = 0.0;
   spinRandomMin      = 0.0;
   spinRandomMax      = 0.0;
   colors[0]     = "0.4 0.4 0.9 0.5";
   colors[1]     = "0.4 0.4 0.9 0.0";

   sizes[0]      = 0.2;
   sizes[1]      = 0.0;

   times[0] = 0.0;
   times[1] = 1.0;

   useInvAlpha = false;
};
datablock ParticleEmitterData(stunballTrailEmitter)
{
   ejectionPeriodMS = 15;
   periodVarianceMS = 1;
   ejectionVelocity = 0.25;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "stunballTrailParticle";

   uiName = "Sandman Ball Trail";
};

datablock ProjectileData(stunballProjectile)
{
   projectileShapeName = "./ball.dts";
   explosion           = "";
   bounceExplosion     = "";
   particleEmitter     = stunballTrailEmitter;
   explodeOnDeath = true;
   
   directDamage        = 5;
   directDamageType    = $DamageType::TF2StunBall;
   radiusDamageType    = $DamageType::TF2StunBall;
   
   brickExplosionRadius = 0;
   brickExplosionImpact = 0;             //destroy a brick if we hit it directly?
   brickExplosionForce  = 0;             
   brickExplosionMaxVolume = 0;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 0;  //max volume of bricks that we can destroy if they aren't connected to the ground (should always be >= brickExplosionMaxVolume)

   sound = "";

   muzzleVelocity      = 65;
   velInheritFactor    = 1.0;

   armingDelay         = 15000;
   lifetime            = 15000;
   fadeDelay           = 14500;
   bounceElasticity    = 0.30;
   bounceFriction      = 0.30;
   isBallistic         = true;
   gravityMod          = 1.0;

   hasLight    = false;

   uiName = "Sandman Ball"; 
};

datablock ShapeBaseImageData(StunBallImage)
{
   shapeFile = "./ball.dts";
   emap = false;

   mountPoint = 1;
   rotation = "0 0 1 0";
   offset = "0 0 0.2";

   stateName[0]            = "Ready";
   stateTransitionOnTimeout[0]      = "Ready";
   stateTimeoutValue[0]         = 1;
   
   armReady = true;
};

datablock ItemData(StunBallItem)
{
   category = "Weapon";  // Mission editor category
   className = "Weapon"; // For inventory system

    // Basic Item Properties
   shapeFile = "base/data/shapes/empty.dts";
   mass = 1;
   density = 0.2;
   elasticity = 0.2;
   friction = 0.6;
   emap = true;

   //gui stuff
   uiName = "";
   iconName = "./icon_woodbat";
   doColorShift = true;
   colorShiftColor = "0.9 0.8 0.5 1.0";

    // Dynamic properties defined by the scripts
   image = stunBallImage;
   canDrop = true;
};

//////////
// item //
//////////
datablock ItemData(tf2stunbatItem)
{
   category = "Weapon";  // Mission editor category
   className = "Weapon"; // For inventory system

    // Basic Item Properties
   shapeFile = "./crackedbat.dts";
   mass = 1;
   density = 0.2;
   elasticity = 0.2;
   friction = 0.6;
   emap = true;

   //gui stuff
   uiName = "The Sandman";
   iconName = "./icon_woodbat";
   doColorShift = true;
   colorShiftColor = "1 1 1 1";

    // Dynamic properties defined by the scripts
   image = tf2StunBatImage;
   canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(tf2StunBatImage)
{
   // Basic Item properties
   shapeFile = "./crackedbat.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = "0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = tf2stunbatItem;
   ammo = " ";
   projectile = stunballProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = "1 1 1 1";
   
   raycastWeaponRange = 3;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |   //Targets the weapon can hit: Raycasting Bricks
               $TypeMasks::PlayerObjectType |   //AI/Players
               $TypeMasks::StaticObjectType |   //Static Shapes
               $TypeMasks::TerrainObjectType |   //Terrain
               $TypeMasks::VehicleObjectType;   //Vehicles
   raycastExplosionProjectile = hammerProjectile;
   raycastExplosionSound = batWoodHitSound;
   raycastDirectDamage = 28;
   raycastDirectDamageType = $DamageType::TF2WoodBat;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.3;
	stateSequence[0]                 = "Activate";
	stateTransitionOnTimeout[0]      = "Ready";
	stateSound[0]                    = weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.05;
	stateTransitionOnTimeout[2]     = "FireA";
	
	stateName[3]                    = "FireA";
	stateTransitionOnTimeout[3]     = "FireB";
	stateTimeoutValue[3]            = 0.10;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSound[3]			= tf2MeleeSwingSound;
	stateWaitForTimeout[3]		= true;

	stateName[4]                    = "FireB";
	stateTransitionOnTimeout[4]     = "Wait";
	stateTimeoutValue[4]            = 0.15;
	stateFire[4]                    = true;
	stateAllowImageChange[4]        = false;
	stateScript[4]                  = "onFire";
	stateWaitForTimeout[4]		= true;
	
	stateName[5]			= "Wait";
	stateTransitionOnTimeout[5]	= "CheckFire";
	stateTimeoutValue[5]		= 0.25;
	stateScript[5]			= "onStopFire";
	stateAllowImageChange[5]	= false;
	stateWaitForTimeout[5]		= true;

	stateName[6]			= "CheckFire";
	stateTransitionOnTriggerUp[6]	= "StopFire";
	stateTransitionOnTriggerDown[6]	= "PreFire";
	
	stateName[7]                    = "StopFire";
	stateTransitionOnTimeout[7]     = "Ready";
	stateTimeoutValue[7]            = 0.2;
	stateAllowImageChange[7]        = false;
	stateWaitForTimeout[7]		= true;
	stateSequence[7]                = "StopFire";
	stateScript[7]                  = "onStopFire";
};

function tf2StunBatImage::onMount(%this,%obj,%slot)
{
   Parent::onMount(%this,%obj,%slot);
   %obj.fireStun = "";
   if(!%obj.usedStunBall)
   {
      %obj.mountImage(stunBallImage,1);
      fixArmReady(%obj);
   }
}

function tf2stunbatImage::onUnMount(%this, %obj, %slot)
{
	Parent::onUnMount(%this, %obj, %slot);
	%obj.playThread(2,root);
	%obj.fireStun = "";
	if(%obj.getMountedImage(1) == StunBallImage.getID())
	{
		%obj.unmountImage(1);
		fixArmReady(%obj);
	}
}

function tf2stunbatImage::onPreFire(%this, %obj, %slot)
{
	%obj.playthread(2, armattack);
	if(%obj.getMountedImage(1) == StunBallImage.getID())
	{
		%obj.fireStun = 1;
		%obj.playThread(3,leftRecoil);
	}
	else
		%obj.fireStun = "";
}

function tf2stunbatImage::onFire(%this, %obj, %slot)
{
	if(%obj.getMountedImage(1) == StunBallImage.getID() && %obj.fireStun)
	{
		//Fire stun ball
		%this.raycastWeaponRange = 0;
		%obj.unMountImage(1);
		fixArmReady(%obj);
		%obj.usedStunBall = 1;
		%obj.stunBallReturn = %obj.schedule(15000,getStunBall);
		serverPlay3d(batWoodBallSwingSound,%obj.getHackPosition());
	}
	else
	{
		//Hit with bat
		%this.raycastWeaponRange = 3;
		if(%obj.stunTauntReady)
			%this.raycastExplosionSound = batWoodBallStunSound;
		else
			%this.raycastExplosionSound = batWoodHitSound;
	}
	%obj.fireStun = "";
	Parent::onFire(%this, %obj, %slot);
}

function tf2stunbatImage::onStopFire(%this, %obj, %slot)
{	
	%obj.playthread(2, root);
}

function tf2StunBatImage::onRaycastDamage(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit)
{
   %damageType = $DamageType::Direct;
   if(%this.raycastDirectDamageType)
      %damageType = %this.raycastDirectDamageType;
   
   %scale = getWord(%obj.getScale(), 2);
   %directDamage = mClampF(%this.raycastDirectDamage, -100, 100) * %scale;
   
   if(%obj.stunTauntReady)
   {
      %directDamage = getWord(%col.getScale(),2) * 360; //450 damage 125 HP in TF2 = 100 in Blockland
      %damageType = $DamageType::TF2BatTaunt;
      
      %obj.schedule(300,emote,winStarProjectile,1);
      if(isObject(%obj.client))
         %obj.client.schedule(300,play2d,rewardSound);
      %col.setVelocity(vectorAdd(%col.getVelocity(),vectorAdd(vectorScale(%obj.getForwardVector(),50),"0 0 20")));
   }
   else if(%crit)
   {
      if(%this.raycastCritDirectDamageType)
         %damageType = %this.raycastCritDirectDamageType;
      
      %directDamage = %directDamage * 3;
      
      %colscale = getWord(%col.getScale(),2);
      %col.spawnExplosion(critProjectile,%colscale);
      if(isObject(%col.client))
         %col.client.play2d(critRecieveSound);
   }
   
   if(%this.raycastImpactImpulse > 0)
      %col.applyImpulse(%pos,vectorScale(%shotVec,%this.raycastImpactImpulse));
   
   if(%this.raycastVerticalImpulse > 0)
      %col.applyImpulse(%pos,vectorScale("0 0 1",%this.raycastVerticalImpulse));
   
   %col.schedule(0,damage,%obj, %pos, %directDamage, %damageType);
}


function tf2StunBatImage::isRaycastCritical(%this,%obj,%slot,%col,%pos,%normal,%hit)
{
	return tf2MeleeWeaponImage::isRaycastCritical(%this,%obj,%slot,%col,%pos,%normal,%hit);
}

function StunBallProjectile::onCollision(%this,%obj,%col,%fade,%pos,%norm)
{
   Parent::onCollision(%this,%obj,%col,%fade,%pos,%norm);
   
   %obj.noStun = 1;
   %obj.numBounces++;
   if(vectorLen(%obj.getVelocity()) < 2)
   {
      if(!isObject(%obj.item))
         %obj.item = new Item()
         {
            dataBlock = StunBallItem;
            canPickup = 1;
            static = 0;
            sourceObject = %obj;
         };MissionCleanup.add(%obj.item);
      
      %obj.item.setTransform(vectorAdd(%obj.getPosition(),"0 0 0.5") SPC "0 0 1 0");
   }
}

function StunBallProjectile::onRemove(%this,%obj)
{
   if(isObject(%obj.item))
      %obj.item.delete();
   Parent::onRemove(%this,%obj);
}

function StunBallProjectile::onExplode(%this,%obj)
{
   if(isObject(%obj.item))
      %obj.item.delete();
   Parent::onExplode(%this,%obj);
}

function StunBallItem::onPickup(%this,%obj,%user,%amt)
{
   if(!isObject(%obj.sourceObject) || !miniGameCanDamage(%obj.sourceObject,%user) || !%user.usedStunBall)
      return;
   
   %user.getStunBall();
   %obj.sourceObject.explode();
}

function StunBallProjectile::damage(%this,%obj,%col,%fade,%pos,%norm)
{
   %colType = %col.getType();
   Parent::damage(%this,%obj,%col,%fade,%pos,%norm);
   
   if(!(%colType & $TypeMasks::PlayerObjectType))
      return;
   
   %dist = vectorDist(%obj.originPoint,%pos);
   
   if(%obj.noStun || %dist < 10)
      return;
   
   if(%col.isBatStunned)
   {
      %obj.noStun = 1;
      return;
   }
   
   if(%col.getType() & $TypeMasks::CorpseObjectType)
   {
      serverPlay3d(batWoodBallStunSound,%pos);
      return;
   }
   
   %col.mountImage(StunImage,2);
   if(%dist > 50)
   {
      if(%obj.client != %col.client)
      {
         if(isObject(%obj.client.player) && %obj.client.player.getState() !$= "Dead")
            %obj.client.player.schedule(1000,emote,winStarProjectile);
         
         if(isObject(%obj.client))
            %obj.client.schedule(1000,play2d,rewardSound);
      }
      
      %time = 5000;
   }
   else
      %time = 100*%dist;
   
   if(isObject(%obj.client) && (!isObject(%obj.client.getControlObject()) || vectorDist(%obj.client.getControlObject().getPosition(),%pos) > 20))
      %obj.client.play2d(batWoodBallStun2dSound);
   
   serverPlay3d(batWoodBallStunSound,%pos);
   
   if(isObject(%col.client))
   {
      %transform = %col.getTransform();
      %col.client.camera.setOrbitMode(%col, %transform, 0.5, 8, 8, 1);
      %col.client.camera.mode = "Orbit";
      %col.client.setControlObject(%col.client.camera);
   }
   
   %col.unMountImage(0);
   %col.isBatStunned = 1;
   %col.schedule(%time,unStun);
   cancel(%col.nextBatTaunt);
   %col.stunTaunting = 0;
}

function Player::unStun(%this)
{
   if(%this.getState() $= "Dead")
      return;
   
   if(%this.getMountedImage(2) == StunImage.getID())
      %this.unMountImage(2);
   
   %this.playThread(2,undo);
   
   %this.schedule(500,unStun2);
}

function Player::unStun2(%this)
{
   %this.isBatStunned = 0;
   if(isObject(%this.client) && %this.getState() !$= "Dead")
   {
      %this.client.setcontrolobject(%this);
      if(%this.currTool != -1)
         servercmdUseTool(%this.client,%this.currTool);
   }
}

function Player::getStunBall(%this)
{
   %this.usedStunBall = "";
   
   cancel(%this.stunBallReturn);
   %this.stunBallReturn = "";
   
   if(%this.stunTaunting)
      return;
   
   if(isObject(%this.client))
      %this.client.play2d(weaponSwitchSound);
   if(%this.getMountedImage(0) == tf2StunBatImage.getID())
   {
      %this.mountImage(stunBallImage,1);
      fixArmReady(%this);
   }
}

function Player::doStunBatTaunt(%this)
{
   if(%this.stunTaunting)
      return;
   
   %this.stunTaunting = 1;
   %this.playThread(2,activate2);
   %this.schedule(50,stopThread,2);
   
   if(%this.getMountedImage(1) == StunBallImage.getID())
   {
      %this.unMountImage(1);
      fixArmReady(%this);
   }
   
   if(isObject(%this.client))
   {
      %transform = %this.getTransform();
      %this.client.camera.setOrbitMode(%this, %transform, 0.5, 8, 8, 1);
      %this.client.camera.mode = "Orbit";
      %this.client.setControlObject(%this.client.camera);
   }
   
   %this.nextBatTaunt = %this.schedule(500,doStunBatTaunt2,6);
}

function Player::doStunBatTaunt2(%this,%count)
{
   if(%this.getState() $= "Dead")
      return;
   
   %this.playThread(3,rotCW);
   %count--;
   if(%count > 0)
      %this.nextBatTaunt = %this.schedule(200,doStunBatTaunt2,%count);
   else
      %this.nextBatTaunt = %this.schedule(200,doStunBatTaunt3);
}

function Player::doStunBatTaunt3(%this)
{
   if(%this.getState() $= "Dead")
      return;
   
   %this.playThread(2,spearThrow);
   serverPlay3d(spearFireSound,%this.getHackPosition());
   %this.nextBatTaunt = %this.schedule(100,doStunBatTaunt4);
}

function Player::doStunBatTaunt4(%this)
{
   if(%this.getState() $= "Dead")
      return;
   
   %this.stunTauntReady = 1;
   tf2StunBatImage.onFire(%this,0);
   %this.nextBatTaunt = %this.schedule(500,doStunBatTaunt5);
}

function Player::doStunBatTaunt5(%this)
{
   if(%this.getState() $= "Dead")
      return;
   
   %this.stunTauntReady = "";
   %this.stunTaunting = 0;
   %this.client.setcontrolobject(%this);
   if(isObject(%this.client))
   {
      if(%this.currTool != -1)
      {
         if(%this.tool[%this.currTool] == tf2StunBatItem.getID())
         {
            if(!%this.usedStunBall)
            {
               %this.client.play2d(weaponSwitchSound);
               %this.mountImage(stunBallImage,1);
               fixArmReady(%this);
            }
            return;
         }
         servercmdUseTool(%this.client,%this.currTool);
      }
      else
         servercmdUnUseTool(%this.client);
   }
}

package StunDamage
{
   function Armor::Damage(%this,%obj,%source,%pos,%amm,%type)
   {
      //Instant kills are not reduced
      if(%obj.isBatStunned && %type != $DamageType::Suicide && %amm < %obj.dataBlock.maxDamage*getWord(%obj.getScale(),2))
         %amm *= 0.5;
      
      Parent::Damage(%this,%obj,%source,%pos,%amm,%type);
   }
   
   function Armor::onDisabled(%this,%obj)
   {
      if(%obj.getMountedImage(3) == StunImage.getID())
         %obj.unMountImage(3);
      
      Parent::onDisabled(%this,%obj);
   }
   
   function armor::onTrigger(%this,%player,%slot,%val)
   {
      if(%slot $= 4 && %player.getMountedImage(0) $= tf2StunBatImage.getID())
      {
         if(%val)
         {
            %player.stunTauntTrigEnable = getSimTime();
         }
         else
         {
            if((getSimTime() - %player.stunTauntTrigEnable) < 500)
            {
               %player.doStunBatTaunt();
            }
         }
      }
      else
         Parent::onTrigger(%this,%player,%slot,%val);
   }
   
   function servercmdusetool(%client,%slot)
   {
      if(%client.player.stunTaunting || %client.player.isBatStunned)
      {
         %client.player.currTool = %slot;
         return;
      }
      Parent::servercmdusetool(%client,%slot);
   }
   
   function servercmdunusetool(%client)
   {
      if(%client.player.stunTaunting || %client.player.isBatStunned)
         return;
      Parent::servercmdunusetool(%client);
   }
};activatePackage(StunDamage);
