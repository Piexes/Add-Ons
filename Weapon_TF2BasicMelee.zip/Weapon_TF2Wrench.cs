AddDamageType("TF2Wrench",   '<bitmap:Add-Ons/Weapon_TF2BasicMelee/ci_wrench> %1',    '%2 <bitmap:Add-Ons/Weapon_TF2BasicMelee/ci_wrench> %1',0.75,1);

//////////
// item //
//////////
datablock ItemData(tf2WrenchItem : wrenchItem)
{
	uiName = "TF2 Wrench";
	colorShiftColor = vectorScale(wrenchItem.colorShiftColor,0.5) SPC 1;
	image = tf2WrenchImage;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(tf2WrenchImage : wrenchImage)
{
   item = tf2WrenchItem;
   ammo = " ";
   projectile = wrenchProjectile;
   projectileType = Projectile;
   
   showBricks = 0;
   
   doColorShift = true;
   colorShiftColor = tf2WrenchItem.colorShiftColor;
   
   raycastWeaponRange = 3;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastExplosionProjectile = wrenchProjectile;
   raycastDirectDamage = 35;
   raycastDirectDamageType = $DamageType::TF2Wrench;
   
   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.3;
	stateSequence[0]                 = "Activate";
	stateTransitionOnTimeout[0]      = "Ready";
	stateSound[0]                    = weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateSequence[1]                 = "Ready";
	stateTransitionOnTriggerDown[1]  = "FireA";
	stateAllowImageChange[1]         = true;
	
	stateName[2]			= "FireA";
	stateSequence[2]		= "Fire";
	stateTransitionOnTimeout[2]	= "FireB";
	stateTimeoutValue[2]		= 0.5;
	stateScript[2]			= "onFire";
	stateAllowImageChange[2]	= false;
	stateWaitForTimeout[2]		= true;
	
	stateName[3]			= "FireB";
	stateSequence[3]                 = "Ready";
	stateTransitionOnTimeout[3]	= "CheckFire";
	stateScript[3]			= "";
	stateTimeoutValue[3]		= 0.3;
	stateAllowImageChange[3]	= true;
	stateWaitForTimeout[3]		= true;

	stateName[4]			= "CheckFire";
	stateTransitionOnTriggerUp[4]	= "StopFire";
	stateTransitionOnTriggerDown[4]	= "FireA";
	
	stateName[5]                    = "StopFire";
	stateTransitionOnTimeout[5]     = "Ready";
	stateTimeoutValue[5]            = 0.2;
	stateAllowImageChange[5]        = false;
	stateWaitForTimeout[5]		= true;
	stateSequence[5]                = "StopFire";
	stateScript[5]                  = "onStopFire";


};

function tf2WrenchImage::onFire(%this, %obj, %slot)
{
	Parent::onFire(%this, %obj, %slot);
	%obj.playThread(2,wrench);
}

function tf2WrenchImage::onHitObject(%this,%obj,%slot,%col,%pos,%normal,%shotVec,%crit)
{
   if(!isObject(%col))
      return;
   
   %colType = %col.getType(); //%col changes to CorpseObjectType if you kill a player 
   
   if(!isObject(CritProjectile))
      %crit = 0;
   
   if(%colType & $TypeMasks::fxBrickObjectType && isObject(%obj.client))
   {
      %event = 0;
      for(%i=0;%i<%col.numEvents;%i++)
      {
         if(%col.eventInput[%i] $= "onWrenchHit" && %col.eventEnabled[%i])
         {
            %event = 1;
            break;
         }
      }
      
      if(%event)
         %col.onWrenchHit(%obj.client);
   }
   else if(%this.raycastDirectDamage > 0 && %colType & ($TypeMasks::PlayerObjectType | $TypeMasks::VehicleObjectType))
   {
      if(isObject(%col.spawnBrick) && %col.spawnBrick.getGroup().client == %obj.client)
         %dmg = 1;
      if(miniGameCanDamage(%obj,%col) == 1 || %dmg)
         %this.onRaycastDamage(%obj,%slot,%col,%pos,%normal,%shotVec,%crit);
   }
   
   if(isObject(%this.raycastExplosionProjectile))
   {
      %scaleFactor = getWord(%obj.getScale(), 2);
      %p = new Projectile()
      {
         dataBlock = %this.raycastExplosionProjectile;
         initialPosition = %pos;
         initialVelocity = %normal;
         sourceObject = %obj;
         client = %obj.client;
         sourceSlot = 0;
         originPoint = %pos;
      };
      MissionCleanup.add(%p);
      %p.setScale(%scaleFactor SPC %scaleFactor SPC %scaleFactor);
      %p.explode();
   }
   
   if(%event)
      serverplay3d(wrenchHitSound,%pos);
   else
      serverplay3d(wrenchMissSound,%pos);
}

function tf2WrenchImage::isRaycastCritical(%this,%obj,%slot,%col,%pos,%normal,%hit)
{
   if(isObject(%col) && %col.getType() & $TypeMasks::PlayerObjectType)
   {
      for(%i=0;%i<%col.dataBlock.maxTools;%i++)
      {
         if(%col.tool[%i].image.isCloakWatch)
            return 1;
      }
   }
   return tf2MeleeWeaponImage::isRaycastCritical(%this,%obj,%slot,%col,%pos,%normal,%hit);
}

registerInputEvent("fxDTSBrick","onWrenchHit","Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection" TAB "MiniGame MiniGame" TAB "Owner(Player) Player" TAB "Owner(Client) GameConnection",1);
function fxDTSBrick::onWrenchHit(%obj,%client)
{
	$InputTarget_["Self"] = %obj;
	$InputTarget_["Player"] = %client.Player;
	$InputTarget_["Client"] = %client;
	
	if(%client.minigame == %obj.getGroup().client.minigame)
	{
		$InputTarget_["MiniGame"] = %obj.getGroup().client.minigame;
	}
	
	$InputTarget_["Owner(Player)"] = %obj.getGroup().client.Player;
	$InputTarget_["Owner(Client)"] = %obj.getGroup().client;
	%obj.processInputEvent("onWrenchHit",%client);
}
