AddDamageType("TF2Kukri",   '<bitmap:Add-Ons/Weapon_TF2BasicMelee/ci_tf2Kukri> %1',    '%2 <bitmap:Add-Ons/Weapon_TF2BasicMelee/ci_tf2Kukri> %1',0.75,1);

//////////
// item //
//////////
datablock ItemData(tf2KukriItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Kukri.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Kukri";
	iconName = "./icon_tf2Kukri";
	doColorShift = true;
	colorShiftColor = "0.5 0.5 0.5 1.000";

	 // Dynamic properties defined by the scripts
	image = tf2KukriImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(tf2KukriImage)
{
   // Basic Item properties
   shapeFile = "./Kukri.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0.1";
   eyeOffset = "0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   className = "TF2MeleeWeaponImage";

   // Projectile && Ammo.
   item = tf2KukriItem;
   ammo = " ";
   projectile = hammerProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = tf2KukriItem.colorShiftColor;
   
   raycastWeaponRange = 3;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastExplosionProjectile = hammerProjectile;
   raycastExplosionBrickSound = swordHitSound;
   raycastExplosionPlayerSound = tf2MeleeHitBrickSoundA;
   raycastDirectDamage = 35;
   raycastDirectDamageType = $DamageType::TF2Kukri;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.3;
	stateSequence[0]                 = "Activate";
	stateTransitionOnTimeout[0]      = "Ready";
	stateSound[0]                    = swordDrawSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "PreFire";
	stateAllowImageChange[1]         = true;

	stateName[2]			= "PreFire";
	stateScript[2]                  = "onPreFire";
	stateAllowImageChange[2]        = false;
	stateTimeoutValue[2]            = 0.05;
	stateTransitionOnTimeout[2]     = "FireA";
	
	stateName[3]                    = "FireA";
	stateTransitionOnTimeout[3]     = "FireB";
	stateTimeoutValue[3]            = 0.10;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateSound[3]			= tf2MeleeSwingSound;
	stateWaitForTimeout[3]		= true;

	stateName[4]                    = "FireB";
	stateTransitionOnTimeout[4]     = "Wait";
	stateTimeoutValue[4]            = 0.15;
	stateFire[4]                    = true;
	stateAllowImageChange[4]        = false;
	stateScript[4]                  = "onFire";
	stateWaitForTimeout[4]		= true;
	
	stateName[5]			= "Wait";
	stateTransitionOnTimeout[5]	= "CheckFire";
	stateTimeoutValue[5]		= 0.5;
	stateScript[5]			= "onStopFire";
	stateAllowImageChange[5]	= false;
	stateWaitForTimeout[5]		= true;

	stateName[6]			= "CheckFire";
	stateTransitionOnTriggerUp[6]	= "StopFire";
	stateTransitionOnTriggerDown[6]	= "PreFire";
	
	stateName[7]                    = "StopFire";
	stateTransitionOnTimeout[7]     = "Ready";
	stateTimeoutValue[7]            = 0.2;
	stateAllowImageChange[7]        = false;
	stateWaitForTimeout[7]		= true;
	stateSequence[7]                = "StopFire";
	stateScript[7]                  = "onStopFire";


};

function tf2KukriImage::onFire(%this, %obj, %slot)
{
	if(getRandom(0,1))
		%this.raycastExplosionBrickSound = tf2MeleeHitBrickSoundA;
	else
		%this.raycastExplosionBrickSound = tf2MeleeHitBrickSoundB;
	
	Parent::onFire(%this, %obj, %slot);
}
