//TF2sniper.cs

//Decals
datablock DecalData(TF2sniperCI)
{
   textureName = "./CI_Sniperkill";
};   

datablock DecalData(TF2sniperIcon)
{
   textureName = "./icon_TF2sniper";
};   

//sounds
datablock AudioProfile(TF2sniperReloadSound)
{
   filename    = "./SniperReload.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(TF2sniperShot1Sound)
{
   filename    = "./SniperShot1.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(TF2sniperShotChargedSound)
{
   filename    = "./SniperShotCharged.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(bulletHitSound)
{
   filename    = "./bulletHit.wav";
   description = AudioClose3d;
   preload = true;
};


//shell
datablock DebrisData(TF2sniperShellDebris)
{
	shapeFile = "add-ons/weapon_gun/gunShell.dts";
	lifetime = 2.0;
	minSpinSpeed = -400.0;
	maxSpinSpeed = 200.0;
	elasticity = 0.5;
	friction = 0.2;
	numBounces = 3;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 2;
};


//muzzle flash effects
datablock ParticleData(TF2sniperFlashParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 25;
	lifetimeVarianceMS   = 15;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.9 0.9 0.0 0.9";
	colors[1]     = "0.9 0.5 0.0 0.0";
	sizes[0]      = 0.5;
	sizes[1]      = 1.0;

	useInvAlpha = false;
};

datablock ParticleEmitterData(TF2sniperFlashEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TF2sniperFlashParticle";
};

datablock ParticleData(TF2sniperSmokeParticle)
{
	dragCoefficient      = 3;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 525;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.5 0.5 0.5 0.9";
	colors[1]     = "0.5 0.5 0.5 0.0";
	sizes[0]      = 0.15;
	sizes[1]      = 0.15;

	useInvAlpha = false;
};

datablock ParticleEmitterData(TF2sniperSmokeEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TF2sniperSmokeParticle";
};


datablock ParticleData(TF2sniperExplosionParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = 1;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 700;
	lifetimeVarianceMS   = 400;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.9 0.9 0.9 0.3";
	colors[1]     = "0.9 0.5 0.6 0.0";
	sizes[0]      = 0.25;
	sizes[1]      = 0.75;

	useInvAlpha = true;
};

datablock ParticleEmitterData(TF2sniperExplosionEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 2;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TF2sniperExplosionParticle";
};

datablock ParticleData(TF2sniperExplosionRingParticle)
{
	dragCoefficient      = 8;
	gravityCoefficient   = -0.5;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 50;
	lifetimeVarianceMS   = 35;
	textureName          = "base/data/particles/star1";
	spinSpeed		= 500.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "1 1 0.0 0.9";
	colors[1]     = "0.9 0.0 0.0 0.0";
	sizes[0]      = 1;
	sizes[1]      = 0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(TF2sniperExplosionRingEmitter)
{
	lifeTimeMS = 50;

   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 89;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TF2sniperExplosionRingParticle";
};

datablock ExplosionData(TF2sniperExplosion)
{
   //explosionShape = "";
	soundProfile = bulletHitSound;

   lifeTimeMS = 150;

   particleEmitter = TF2sniperExplosionEmitter;
   particleDensity = 5;
   particleRadius = 0.2;

   emitter[0] = TF2sniperExplosionRingEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0.3 0.6 0.7";
   lightEndColor = "0 0 0";
};


AddDamageType("TF2sniper",   '<bitmap:add-ons/Weapon_TF2sniper/CI_Sniperkill> %1',    '%2 <bitmap:add-ons/Weapon_TF2sniper/CI_Sniperkill> %1',0.2,1);
datablock ProjectileData(TF2sniperProjectile)
{
   projectileShapeName = "add-ons/weapon_gun/bullet.dts";
   directDamage        = 45;
   directDamageType    = $DamageType::TF2sniper;
   radiusDamageType    = $DamageType::TF2sniper;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 400;
   verticalImpulse	  = 400;
   explosion           = TF2sniperExplosion;
   particleEmitter     = ""; //bulletTrailEmitter;

   muzzleVelocity      = 600;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "TF2sniper Bullet";
};

datablock ProjectileData(TF2sniperProjectileCharged)
{
   projectileShapeName = "add-ons/weapon_gun/bullet.dts";
   directDamage        = 300;
   directDamageType    = $DamageType::TF2sniper;
   radiusDamageType    = $DamageType::TF2sniper;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 400;
   verticalImpulse	  = 400;
   explosion           = TF2sniperExplosion;
   particleEmitter     = ""; //bulletTrailEmitter;

   muzzleVelocity      = 600;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "TF2sniper BulletCharged";
};


//////////
// item //
//////////
datablock ItemData(TF2sniperItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Sniper.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "TF2Sniper";
	iconName = "./icon_TF2sniper";
	doColorShift = false;
	colorShiftColor = "0.175 0.175 0.175 1.000";

	 // Dynamic properties defined by the scripts
	image = TF2sniperImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(TF2sniperImage)
{
   // Basic Item properties
   shapeFile = "./Sniper.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = 0; //"0.7 1.2 -0.5";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = TF2sniperProjectile;
   projectileType = Projectile;

	casing = TF2sniperShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = "0.15 0.15 0.15 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                     = "Activate";
	stateTimeoutValue[0]             = 0.15;
	stateTransitionOnTimeout[0]       = "Ready";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]                     = "Ready";
	stateTransitionOnTriggerDown[1]  = "Charging";
	stateAllowImageChange[1]         = true;
	stateSequence[1]	= "Ready";

	stateName[2]                    = "Fire";
	stateTransitionOnTimeout[2]     = "Smoke";
	stateTimeoutValue[2]            = 0.14;
	stateFire[2]                    = true;
	stateAllowImageChange[2]        = false;
	stateSequence[2]                = "Fire";
	stateScript[2]                  = "onFire";
	stateWaitForTimeout[2]			= true;
	stateEmitter[2]					= TF2sniperFlashEmitter;
	stateEmitterTime[2]				= 0.05;
	stateEmitterNode[2]				= "muzzleNode";
	stateSound[2]					= TF2sniperShot1Sound;
	stateEjectShell[2]       = true;

	stateName[3] = "Smoke";
	stateEmitter[3]					= TF2sniperSmokeEmitter;
	stateSound[3]					= TF2sniperReloadSound;
	stateEmitterTime[3]				= 0.05;
	stateEmitterNode[3]				= "muzzleNode";
	stateTimeoutValue[3]            = 0.5;
	stateSequence[3]                = "Reload";
	stateTransitionOnTimeout[3]     = "ready";

	stateName[4]			= "Reload";
	stateSequence[4]                = "Reload";
	stateTransitionOnTriggerUp[4]     = "Ready";

	stateName[5]                    = "Charging";
	stateTransitionOnTimeout[5]     = "Charged";
  stateTransitionOnTriggerUp[5]   = "Fire";
	stateTimeoutValue[5]            = 5;
	stateAllowImageChange[5]        = false;
	stateSequence[5]                = "Charging";
	stateScript[5]                  = "onCharge";
	stateWaitForTimeout[5]			    = false;
	
	stateName[6]                    = "Charged";
  stateTransitionOnTriggerUp[6]   = "FireCharged";
	stateAllowImageChange[6]        = false;
	stateSequence[6]                = "Charged";
	stateScript[6]                  = "onCharged";
	stateWaitForTimeout[6]			    = true;
	
	stateName[7]                    = "FireCharged";
	stateTransitionOnTimeout[7]     = "Smoke";
	stateTimeoutValue[7]            = 0.14;
	stateFire[7]                    = true;
	stateAllowImageChange[7]        = false;
	stateSequence[7]                = "FireCharged";
	stateScript[7]                  = "onFireCharged";
	stateWaitForTimeout[7]			= true;
	stateEmitter[7]					= TF2sniperFlashEmitter;
	stateEmitterTime[7]				= 0.05;
	stateEmitterNode[7]				= "muzzleNode";
	stateSound[7]					= TF2sniperShotChargedSound;
	stateEjectShell[7]       = true;
	
};

function TF2sniperImage::onFirecharged(%this,%obj,%slot)
{

	

	%projectile = TF2sniperprojectilecharged;
	%spread = 0.00;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}

