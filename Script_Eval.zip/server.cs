//Uploaded by mldn
//Script_EvalBuilderMode
//By Mold
//Alot of comments and stretched script to make easy understandable

package EvalScriptBuilder_Commands
{
function serverCmdEnterBuilderMode(%client)
{
    if(%client.isSuperAdmin) //Is the buddy Super Admin?
    {
        if(!%client.isBuilderMode) //Is the buddy already using Builder Mode?
        {
            messageClient(%client,'',"\c6You entered the Builder Mode.");
            %client.isBuilderMode = 1;
            messageAll('',"\c3" @ %client.name @ " \c6has entered the Builder Mode.");
        }
        else
        {
            messageClient(%client,'',"\c6You are already using the Builder Mode!");
        }           
    }
    else
    {
        messageClient(%client,'',"\c6Only Super Admins can use the Builder Mode!");
    }
}

function serverCmdLeaveBuilderMode(%client)
{   //No ifSuperAdmin needed because only Super Admins can be using it
    if(%client.isBuilderMode) //Is the buddy using Builder Mode?
    {
        messageClient(%client,'',"\c6You left the Builder Mode.");
        %client.isBuilderMode = 0;
        messageAll('',"\c3" @ %client.name @ " \c6has left the Builder Mode.");
    }
    else
    {
        messageClient(%client,'',"\c6You are not using the Builder Mode!");
    }
}

function serverCmdResetBuilderCode(%client)
{
    if(%client.BuilderCode !$= "") //Did the buddy code anything?
    {
        messageClient(%client,'',"\c6You reset your Builder Mode code.");
        %client.BuilderCode = ""; //Reset the code
        %client.isBuilderMode = 0; //Makes buddy leave the Builder Mode
        messageAll('',"\c3" @ %client.name @ " \c6reset his Builder Mode code.");
    }
    else
    {
    messageClient(%client,'',"You didn't code anything to reset!");
    }
}

function serverCmdHelpBuilderMode(%client)
{
    messageClient(%client,'',"\c6Welcome to the Help section of the Builder Mode!");
    messageClient(%client,'',"\c6The Builder Mode is a multi-line scripting tool for Super Admins, like advanced eval.");
    messageClient(%client,'',"\c6You have a few commands for this Tool:");
    messageClient(%client,'',"\c3/HelpBuilderMode \c6-- Shows this help.");
    messageClient(%client,'',"\c3/EnterBuilderMode \c6-- Enter the Builder Mode. All your chat will be added to your code then.");
    messageClient(%client,'',"\c3/LeaveBuilderMode \c6-- Leave the Builder Mode. Your chat turns normal and your code won't be changed.");
    messageClient(%client,'',"\c6You can add more to your code by using \c3/EnterBuilderMode \c6again.");
    messageClient(%client,'',"\c3/UndoLine \c6-- Made a mistake? No problem. use this to undo your last added line.");
    messageClient(%client,'',"\c3/EvalBuiltCode \c6-- Final stage. Evaluates your code and resets it afterwards.");
    messageClient(%client,'',"\c6Or if you only have one line use the normal eval by starting your chat with $.");
    messageClient(%client,'',"\c6Note: All IF things have to use {}, no matter whether they'r just a single line.");
    messageClient(%client,'',"\c6Or if you only have one line use the normal eval by starting your chat with $.");
    messageClient(%client,'',"\c6Happy scripting!");
}

function serverCmdEvalBuiltCode(%client)
{
    if(%client.BuilderCode !$= "") //Did the buddy code anything?
    {
        $BuilderNoError = 0; //Set this to 0, set it to 1 with the code that the buddy evaluates
        %client.BuilderCode = %client.BuilderCode SPC "$BuilderNoError = 1;";
        eval(%client.BuilderCode); //If the code contained syntax errors, it does not change to 1
        %client.BuilderCode = ""; //Reset the code
        %client.isBuilderMode = 0; //Make buddy leave Builder Mode
        if($BuilderNoError) //Did the code contain a syntax error?
        {
            messageClient(%client,'',"\c6Your code was successfully evaled.");
            messageAll('',"\c3" @ %client.name @ " \c6evaluated his Builder Code.");
        }
        else
        {
            messageClient(%client,'',"\c6Your code contained a Syntax Error and failed to evaluate.");
            messageAll('',"\c3" @ %client.name @ "\c6 tried to evaluate his Builder Code but it contained a Syntax error and failed to evaluate.");
        }
    }
    else
    {
    messageClient(%client,'',"\c6You didn't code anything to evaluate!");
    }
}

function serverCmdUndoLine(%client)
{
    if(%client.BuilderCode !$= "") //Did the buddy code anything?
    {
        if(%client.lastaddedcode !$= "")
		{
			%client.buildercode = strReplace(%client.buildercode,%client.lastaddedcode,0);
            messageClient(%client,'',"\c6You removed the line.");
			messageAll('',"\c3" @ %client.name @ " \c6removed \c4" @ %client.lastaddedcode @ " \c6from his Builder Mode code.");
			%client.lastaddedcode = "";
		}
        else
        {
            messageClient(%client,'',"\c6There is nothing to undo!");
        }
    }
    else
    {
    messageClient(%client,'',"\c6There is nothing to undo!");
    }
}
};

package BuilderMode_AddLineOrEval
{
function serverCmdmessageSent(%client, %msg)
{
    if(%client.isBuilderMode) //Is the buddy in Builder Mode?
    {
        %client.BuilderCode = %client.BuilderCode NL %msg;
		%client.lastaddedcode = %msg;
        messageAll('',"\c3" @ %client.name @ " \c6added \c4" @ %msg @ " \c6to his Builder Mode code.");
		return; //If buddy is in Builder Mode, don't return the parent
    } //If buddy isn't in Builder Mode, return the parent or use eval
	if(%client.isSuperAdmin && getSubStr(%msg, 0, 1) $= "$")
	{
		%col = "\c6";
		$evalNoError = 1;
		for(%a = 0; %a < getWordCount(%msg); %a++)
			%command = %command SPC getWord(getSubStr(%msg, 1, strLen(%msg) - 1), %a);
		//%command = getWord(getSubStr(%msg, 1, strLen(%msg) - 1), 0);
		eval(%command @" $evalNoError = 0;");
		if($evalNoError){%col = "\c0";}		    
			announce("\c3" @ %client.name @ "\c6 -->" @ %col @ %command);
		return;
    }
    parent::serverCmdMessageSent(%client, %msg); 
}
};

activatePackage(EvalScriptBuilder_Commands);
activatePackage(BuilderMode_AddLineOrEval);
