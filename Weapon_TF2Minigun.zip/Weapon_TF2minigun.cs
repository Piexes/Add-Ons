datablock DecalData(TF2MinigunCI)
{
   textureName = "./CI_Minigun";
};   

datablock DecalData(TF2minigunicon)
{
   textureName = "./icon_TF2minigun";
};   

datablock ParticleData(TF2MinigunSmokeParticle)
{
	dragCoefficient      = 4;
	gravityCoefficient   = -1.0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 425;
	lifetimeVarianceMS   = 55;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;
	colors[0]     = "0.5 0.5 0.5 0.7";
	colors[1]     = "0.5 0.5 0.5 0.0";
	sizes[0]      = 0.05;
	sizes[1]      = 0.25;

	useInvAlpha = false;
};
datablock ParticleEmitterData(TF2MinigunSmokeEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 1.0;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TF2MinigunSmokeParticle";
};

AddDamageType("TF2Minigun",   '<bitmap:add-ons/Weapon_TF2Minigun/CI_Minigun> %1',    '%2 <bitmap:add-ons/Weapon_TF2Minigun/CI_Minigun> %1',0.5,1);
datablock ProjectileData(TF2MinigunProjectile)
{
   projectileShapeName = "./bullet.dts";
   directDamage        = 15;
   directDamageType    = $DamageType::TF2Minigun;
   radiusDamageType    = $DamageType::TF2Minigun;

   brickExplosionRadius = 0;
   brickExplosionImpact = true;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 15;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 20;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 100;
   verticalImpulse	  = 50;
   explosion           = GunExplosion;

   muzzleVelocity      = 180;
   velInheritFactor    = 1;

   armingDelay         = 00;
   lifetime            = 4000;
   fadeDelay           = 3500;
   bounceElasticity    = 0.5;
   bounceFriction      = 0.20;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
   
   uiName = "TF2 Bullet";
};

//////////
// item //
//////////
datablock ItemData(TF2MinigunItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./Minigun.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "TF2 Minigun";
	iconName = "./icon_TF2Minigun";
	doColorShift = true;
	colorShiftColor = "1 1 1 1";

	 // Dynamic properties defined by the scripts
	image = TF2MinigunImage;
	canDrop = true;
};


////////////////
//weapon image//
////////////////
datablock ShapeBaseImageData(TF2MinigunImage)
{
   // Basic Item properties
   shapeFile = "./Minigun.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = "0 0 0";
   rotation = eulerToMatrix( "0 0 0" );

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = true;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = BowItem;
   ammo = " ";
   projectile = TF2MinigunProjectile;
   projectileType = Projectile;

	casing = GunShellDebris;
	shellExitDir        = "1.0 -1.3 1.0";
	shellExitOffset     = "0 0 0";
	shellExitVariance   = 15.0;	
	shellVelocity       = 7.0;

   //melee particles shoot from eye node for consistancy
   melee = false;
   //raise your arm up or not
   armReady = true;

   doColorShift = true;
   colorShiftColor = "0.1 0.1 0.1 1.000";

   //casing = " ";

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]                    = "Activate";
	stateTimeoutValue[0]            = 0.15;
	stateTransitionOnTimeout[0]     = "Ready";
	stateSequence[0]				= "root";
	stateSound[0]					= weaponSwitchSound;
	
	stateName[1]                    = "Ready";
	stateTransitionOnTriggerDown[1] = "Spinup";
	stateSequence[1]				= "root";
	stateAllowImageChange[1]        = true;

	stateName[2]                    = "Spinup";
	stateAllowImageChange[2]        = false;
	stateTransitionOnTimeout[2]     = "Fire";
	stateTimeoutValue[2]            = 1.00;
	stateWaitForTimeout[2]			= true;
	//stateSound[2]					= TF2MinigunShot1Sound;
	stateSequence[2]				= "Spin";
	stateTransitionOnTriggerUp[2]   = "Ready";
	//stateSequenceOnTimeout[2]	= "Spin";
	
	stateName[3]                    = "Fire";
	stateSequence[3]				= "Spin";
	stateTransitionOnTimeout[3]     = "Smoke";
	stateTimeoutValue[3]            = 0.01;
	stateFire[3]                    = true;
	stateAllowImageChange[3]        = false;
	stateScript[3]                  = "onFire";
	stateWaitForTimeout[3]			= true;
	stateEmitter[3]					= gunFlashEmitter;
	stateEmitterTime[3]				= 0.01;
	stateEmitterNode[3]				= "muzzleNode";
	stateSound[3]					= gunShot1Sound;
	stateEjectShell[3]       		= true;

	stateName[4] 					= "Smoke";
	stateEmitter[4]					= TF2MinigunSmokeEmitter;
	stateEmitterTime[4]				= 0.05;
	stateEmitterNode[4]				= "muzzleNode";
	stateTimeoutValue[4]            = 0.01;
	stateTransitionOnTimeout[4]     = "Check";

	stateName[5]					= "Check";
	stateTransitionOnTriggerUp[5]   = "Slow";
	stateTransitionOnTriggerDown[5] = "Fire";
	
	stateName[6]					= "Slow";
	stateTransitionOnTriggerDown[6] = "Fire";
	stateSequence[6]                = "spin";
	stateEmitter[6]					= TF2MinigunSmokeEmitter;
	stateEmitterTime[6]				= 1.00;
	stateEmitterNode[6]				= "muzzleNode";
	stateAllowImageChange[6]        = false;
	stateTransitionOnTimeout[6]     = "Ready";
	stateTimeoutValue[6]            = 1.00;
	stateWaitForTimeout[6]			= true;

};

function TF2MinigunImage::onFire(%this,%obj,%slot)
{

	%projectile = TF2MinigunProjectile;
	%spread = 0.04;
	%shellcount = 1;

	for(%shell=0; %shell<%shellcount; %shell++)
	{
		%vector = %obj.getMuzzleVector(%slot);
		%objectVelocity = %obj.getVelocity();
		%vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
		%vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
		%velocity = VectorAdd(%vector1,%vector2);
		%x = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%y = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%z = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
		%mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);
		%velocity = MatrixMulVector(%mat, %velocity);

		%p = new (%this.projectileType)()
		{
			dataBlock = %projectile;
			initialVelocity = %velocity;
			initialPosition = %obj.getMuzzlePoint(%slot);
			sourceObject = %obj;
			sourceSlot = %slot;
			client = %obj.client;
		};
		MissionCleanup.add(%p);
	}
	return %p;
}	
