//quakePlayer.cs

//a new player datablock with quake-like movement



datablock PlayerData(PlayerTF2HeavyArmor : PlayerStandardArmor)
{
   runForce = 100 * 90;
   runEnergyDrain = 0;
   minRunEnergy = 0;
   maxForwardSpeed = 5;
   maxDamage = 175;
   maxBackwardSpeed = 5;
   maxSideSpeed = 5;

   maxForwardCrouchSpeed = 3;
   maxBackwardCrouchSpeed = 3;
   maxSideCrouchSpeed = 3;

	minJetEnergy = 0;
	jumpForce = 5 * 90;
	jetEnergyDrain = 0;
	canJet = 0;

	uiName = "TF2Heavy Player";
	showEnergyBar = false;

   runSurfaceAngle  = 55;
   jumpSurfaceAngle = 55;
};